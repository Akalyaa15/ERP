-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `project_comments`
--

DROP TABLE IF EXISTS `project_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_by` int NOT NULL,
  `created_at` datetime NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `project_id` int NOT NULL DEFAULT '0',
  `comment_id` int NOT NULL DEFAULT '0',
  `task_id` int NOT NULL DEFAULT '0',
  `file_id` int NOT NULL DEFAULT '0',
  `customer_feedback_id` int NOT NULL DEFAULT '0',
  `files` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_comments`
--

LOCK TABLES `project_comments` WRITE;
/*!40000 ALTER TABLE `project_comments` DISABLE KEYS */;
INSERT INTO `project_comments` VALUES (1,962,'2020-04-25 13:11:14','',2,0,2,0,0,'a:2:{i:0;a:2:{s:9:\"file_name\";s:43:\"project_comment_file5ea3e99a02cd9-TN-CM.jpg\";s:9:\"file_size\";s:5:\"15929\";}i:1;a:2:{s:9:\"file_name\";s:46:\"project_comment_file5ea3e99a03d24-Wildlife.mp4\";s:9:\"file_size\";s:8:\"26246026\";}}',0),(2,247,'2020-04-30 18:57:47','Taking training From 6:00 pm',1,0,3,0,0,'a:0:{}',0),(3,247,'2020-04-30 18:59:32','training Details',1,0,3,0,0,'a:1:{i:0;a:2:{s:9:\"file_name\";s:113:\"project_comment_file5eaad2bc25690-Gemicates_Technologies-Gemicates_Technologies_Private_Limited-Invoice-3--1-.pdf\";s:9:\"file_size\";s:6:\"109866\";}}',0),(4,247,'2020-04-30 19:30:36','task trained',1,0,3,0,0,'a:0:{}',0),(5,621,'2020-05-09 14:50:18',' Shanthi mam added today\n',5,0,4,0,0,'a:0:{}',0),(6,621,'2020-05-19 14:36:07','CHECKING -DATE IS NOT CHANGING',13,0,11,0,0,'a:0:{}',0),(7,969,'2020-10-20 06:27:25','write',7,0,0,0,7,'a:0:{}',1),(8,1,'2024-02-26 20:13:58','Driver is not working',51,0,65,0,0,'a:0:{}',0),(9,1,'2024-05-17 07:16:36','completed',20,0,27,0,0,'a:0:{}',0),(10,1,'2024-05-25 12:48:58','HI',0,0,67,0,0,'a:2:{i:0;a:2:{s:9:\"file_name\";s:60:\"project_comment_file6651de3a58b74-Gems-Manager-Gemicates.pdf\";s:9:\"file_size\";s:5:\"23625\";}i:1;a:2:{s:9:\"file_name\";b:0;s:9:\"file_size\";s:5:\"23625\";}}',0),(11,1,'2024-06-01 09:47:30','JI',0,0,70,0,0,'a:0:{}',0),(12,1,'2024-06-04 10:04:54','Testing',0,0,71,0,0,'a:0:{}',0),(13,1,'2024-06-04 10:15:44','hai',58,0,0,0,0,'a:1:{i:0;a:2:{s:9:\"file_name\";s:64:\"project_comment_file665ee950bdc3d-Gems-Manager-Gemicates-1-.xlsx\";s:9:\"file_size\";s:5:\"13900\";}}',0),(14,1,'2024-06-04 10:16:35','Hai',58,0,0,0,58,'a:1:{i:0;a:2:{s:9:\"file_name\";s:64:\"project_comment_file665ee983610a6-Gems-Manager-Gemicates-1-.xlsx\";s:9:\"file_size\";s:5:\"13900\";}}',0),(15,1,'2024-06-04 12:24:26','hai',25,0,75,0,0,'a:0:{}',0),(16,1,'2024-06-08 11:17:11','Hai',42,0,76,0,0,'a:0:{}',0),(17,1,'2024-06-10 07:52:29','Testing',11,0,77,0,0,'a:0:{}',0),(18,1,'2024-06-21 06:01:23','Testing',10,0,79,0,0,'a:0:{}',0),(19,1,'2024-06-21 08:24:52','testing',19,0,80,0,0,'a:0:{}',0),(20,1,'2024-06-21 08:43:00','ji',15,0,81,0,0,'a:1:{i:0;a:2:{s:9:\"file_name\";b:0;s:9:\"file_size\";s:9:\"937280178\";}}',0),(21,1,'2024-06-21 08:49:56','ji',10,0,82,0,0,'a:0:{}',0),(22,1,'2024-06-21 11:28:43','y',42,0,83,0,0,'a:0:{}',0),(23,1,'2024-06-25 12:15:13','Testing',10,0,86,0,0,'a:0:{}',0);
/*!40000 ALTER TABLE `project_comments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
