-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `expense_date` date NOT NULL,
  `category_id` int NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `amount` double NOT NULL,
  `files` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `project_id` int DEFAULT '0',
  `user_id` int NOT NULL DEFAULT '0',
  `tax_id` int NOT NULL DEFAULT '0',
  `tax_id2` int NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `sgst_tax` double NOT NULL DEFAULT '0',
  `igst_tax` double NOT NULL DEFAULT '0',
  `cgst_tax` double NOT NULL DEFAULT '0',
  `total` double NOT NULL,
  `voucher_no` int NOT NULL DEFAULT '0',
  `with_gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `gst_number` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `with_inclusive_tax` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `hsn_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `gst` double NOT NULL,
  `hsn_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `member_type` varchar(45) CHARACTER SET big5 COLLATE big5_chinese_ci DEFAULT NULL,
  `phone` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `company` int DEFAULT '0',
  `vendor_company` int DEFAULT '0',
  `payment_status` int DEFAULT '0',
  `last_activity` datetime DEFAULT NULL,
  `last_activity_user` int DEFAULT NULL,
  `currency_symbol` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `currency` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `payslip_no` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES (1,'2020-04-17',7,'Amount paid\n',15000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:122:\"expense_file5e9a937339cf5-Pelikan_Office_Automation_Pvt._Ltd.-Gemicates_Technologies_Private_Limited-Purchase_Orders-1.pdf\";s:9:\"file_size\";s:6:\"101835\";}}','asa',0,0,0,0,0,0,0,0,15000,5,'no','0','no','-',0,'-','tm','0',0,0,0,NULL,NULL,'','',NULL),(2,'2020-04-17',6,'A4 sheet purchased',100,'a:1:{i:0;a:2:{s:9:\"file_name\";s:106:\"expense_file5eb9494537514-Akasaka_Electronics_Ltd-Gemicates_Technologies_Private_Limited-Work_Orders-5.pdf\";s:9:\"file_size\";s:5:\"98175\";}}','purchase stationery',6,247,0,0,0,0,0,0,100,4,'no','0','no','-',0,'-','tm','0',0,0,0,NULL,NULL,'','',NULL),(3,'2020-05-05',6,'hiii',190.47619047619,'a:1:{i:0;a:2:{s:9:\"file_name\";s:44:\"expense_file5ee73523433bd-Screenshot--2-.png\";s:9:\"file_size\";s:6:\"152376\";}}','text',2,5,0,0,0,4.7619047619048,0,4.7619047619048,200,11,'yes','33','yes','8544',5,'Solar Water 365','tm','0',0,0,0,NULL,NULL,'','',NULL),(4,'2020-06-22',6,'abc',1000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:79:\"expense_file5ef0df2261d4d-Gemicates_Technologies_Private_Limited-Voucher-16.pdf\";s:9:\"file_size\";s:5:\"91306\";}}','expense',11,5,0,0,0,0,0,0,1000,16,'no','0','no','-',0,'-','tm','0',0,0,5,'2020-10-06 12:30:07',1,'','',NULL),(5,'2020-04-17',7,'Amount paid\n',15000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:41:\"expense_file5f00677982dc5-Logo_Name_H.png\";s:9:\"file_size\";s:5:\"49554\";}}','exp',0,1,0,0,0,0,0,0,15000,5,'no','0','no','-',0,'-','tm','0',0,0,0,NULL,NULL,'','',NULL),(6,'2020-05-13',1,'for the development& saving into run away method',15000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:41:\"expense_file5f006897c6c5e-Logo_Name_H.png\";s:9:\"file_size\";s:5:\"49554\";}}','123',7,1,0,0,0,0,0,0,15000,14,'no','0','no','-',0,'-','tm','0',0,0,0,NULL,NULL,'','',NULL),(7,'2020-07-04',6,'123',1000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:41:\"expense_file5f006baf127f3-Logo_Name_H.png\";s:9:\"file_size\";s:5:\"49554\";}}','test expens',7,1,0,0,0,0,0,0,1000,20,'no','0','no','-',0,'-','tm','0',0,0,0,NULL,NULL,'','',NULL),(8,'2020-07-04',6,'123',1000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:82:\"expense_file5f006baf2e069-Gemicates_Technologies_Private_Limited-Voucher-5--5-.pdf\";s:9:\"file_size\";s:5:\"91454\";}}','wqqw',3,1,0,0,0,0,0,0,1000,20,'no','0','no','-',0,'-','tm','0',0,0,0,NULL,NULL,'','',NULL),(9,'2020-07-15',6,'uyuyuy',2333,'a:1:{i:0;a:2:{s:9:\"file_name\";s:44:\"expense_file5f0eb2da3218d-Screenshot--4-.png\";s:9:\"file_size\";s:6:\"148654\";}}','food expense',18,4,0,0,0,0,0,0,2333,26,'no','0','no','-',0,'-','tm','0',0,0,2,NULL,NULL,'','',NULL),(10,'2020-07-19',6,'wew',77,'a:1:{i:0;a:2:{s:9:\"file_name\";s:83:\"expense_file5f140983acb33-Gemicates_Technologies_Private_Limited-Voucher-31--1-.pdf\";s:9:\"file_size\";s:6:\"112979\";}}','ret',7,1,0,0,0,0,0,0,77,31,'no','0','no','-',0,'-','tm','0',0,0,1,NULL,NULL,'','',NULL),(11,'2020-07-19',6,'testing ',2000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:83:\"expense_file5f1410e31bc24-Gemicates_Technologies_Private_Limited-Voucher-31--1-.pdf\";s:9:\"file_size\";s:6:\"112979\";}}','FOOD',18,957,0,0,0,0,0,0,2000,32,'no','0','no','-',0,'-','tm','0',0,0,5,NULL,NULL,'','',NULL),(12,'2020-07-15',6,'sa',3000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:44:\"expense_file5f7c63db899ba-Screenshot--1-.png\";s:9:\"file_size\";s:5:\"12123\";}}','Axis Bank',17,1,0,0,0,0,0,0,3000,25,'no','0','no','-',0,'-','tm','0',0,0,5,'2020-10-06 12:32:27',1,'₹','INR',NULL),(13,'2020-07-19',6,'iioiioi',3333,'a:1:{i:0;a:2:{s:9:\"file_name\";s:79:\"expense_file5f83e7c83bac6-Gemicates_Technologies_Private_Limited-Voucher-30.pdf\";s:9:\"file_size\";s:6:\"115321\";}}','Chennai',7,1,0,0,0,0,0,0,3333,30,'no','0','no','-',0,'-','tm','0',0,0,5,'2020-10-12 05:21:12',1,'BHD','BHD',NULL),(14,'2020-10-01',6,'Danway Payment - EWA',500,'a:2:{i:0;a:2:{s:9:\"file_name\";s:38:\"expense_file5f8f3378c1570-IMG_2527.jpg\";s:9:\"file_size\";s:7:\"2120167\";}i:1;a:2:{s:9:\"file_name\";s:49:\"expense_file5f8f3378c21ab-Employee_Payslip-82.pdf\";s:9:\"file_size\";s:5:\"91354\";}}','HTS-29',31,999,0,0,0,0,0,0,500,51,'no','0','no','-',0,'-','tm','0',0,0,1,'2020-10-20 18:59:04',957,'BHD','BHD',NULL),(15,'2020-10-01',6,'Danway Payment - EWA',500,'a:1:{i:0;a:2:{s:9:\"file_name\";s:79:\"expense_file5f8f3379ae9f4-Gemicates_Technologies_Private_Limited-Voucher-51.pdf\";s:9:\"file_size\";s:6:\"121779\";}}','expense',31,999,0,0,0,0,0,0,500,51,'no','0','no','-',0,'-','tm','0',0,0,5,'2020-10-20 18:59:05',1,'BHD','BHD',NULL),(16,'2020-07-18',6,'nmnmnm',898,'a:1:{i:0;a:2:{s:9:\"file_name\";s:96:\"expense_file5f93b53135f3e-Emirates-Gemicates_Technologies_Private_Limited-Purchase_Orders-12.pdf\";s:9:\"file_size\";s:5:\"98341\";}}','testing',18,957,0,0,0,0,0,0,898,29,'no','0','no','-',0,'-','tm','0',0,0,5,'2020-10-24 05:01:37',247,'BHD','BHD',NULL);
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
