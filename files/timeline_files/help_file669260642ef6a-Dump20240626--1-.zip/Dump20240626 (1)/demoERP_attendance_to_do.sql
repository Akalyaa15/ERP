-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attendance_to_do`
--

DROP TABLE IF EXISTS `attendance_to_do`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_to_do` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `todo_id` int NOT NULL,
  `user_id` int NOT NULL,
  `start_date` date DEFAULT NULL,
  `status` enum('to_do','done') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'to_do',
  `description` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `is_checked` int NOT NULL DEFAULT '0',
  `task_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_to_do`
--

LOCK TABLES `attendance_to_do` WRITE;
/*!40000 ALTER TABLE `attendance_to_do` DISABLE KEYS */;
INSERT INTO `attendance_to_do` VALUES (1,'To attend meeting',0,2,506,'2020-04-18','done',NULL,0,0),(2,'Testing and Web development ',0,4,497,'2020-04-20','done',NULL,0,0),(3,'training Session',0,6,247,'2020-04-30','done',NULL,0,0),(4,'portal testing',0,7,621,'2020-05-09','done',NULL,0,0),(5,'Portal screen recording',0,8,621,'2020-05-11','to_do',NULL,0,0),(6,'Portal documentation',0,9,621,'2020-05-12','done',NULL,0,0),(7,'testing',0,10,1,'2020-05-12','to_do',NULL,0,0),(8,'tes1',0,10,1,'2020-05-12','to_do',NULL,0,0),(9,'portal documentation',0,11,621,'2020-05-13','done',NULL,0,0),(10,'sai',0,12,12,'2020-05-14','to_do',NULL,0,0),(11,'task checking',0,14,621,'2020-05-19','done',NULL,0,0),(12,'projects checking',0,17,621,'2020-05-19','done',NULL,0,0),(13,'payslip generation',0,18,621,'2020-05-28','to_do',NULL,0,0),(14,'upadate live server',1,3059,1,'2020-06-15','to_do',NULL,0,0),(15,'update',0,3060,5,'2020-06-16','done',NULL,0,0),(16,'To chcek the bugs',0,3061,621,'2020-07-06','done',NULL,0,0),(17,'task 2',1,3062,504,'2020-07-07','to_do',NULL,0,0),(18,'TO DO-01',0,3062,504,'2020-07-07','done','',0,0),(19,'TO DO-02',1,3062,504,'2020-07-07','to_do',NULL,0,0),(20,' To bugs  & checking  ',0,3064,621,'2020-07-07','done',NULL,0,0),(21,'erp bugs checking',0,3066,621,'2020-07-11','done',NULL,0,0),(22,'nnn',0,3070,5,'2020-07-28','done',NULL,0,0),(23,'n',0,3071,5,'2020-07-29','done',NULL,0,0),(24,'b',0,3072,5,'2020-08-07','done',NULL,0,13),(25,'update live server.',0,3059,1,'2020-08-07','done',NULL,0,27),(26,'some to do list details, instead of this some task details',0,3073,1,'2020-08-14','done','',0,27),(27,'some todo',0,3074,1,'2020-08-14','to_do',NULL,0,27),(28,'fsdcs',0,3075,247,'2020-08-15','done',NULL,0,4),(29,'to assign tasks',0,3057,506,'2020-08-15','done',NULL,0,28),(30,'d',0,3076,12,'2020-08-17','done',NULL,0,13),(31,'dd',0,3077,12,'2020-08-17','to_do',NULL,0,13),(32,'test',0,3063,504,'2020-08-21','done',NULL,0,18),(33,'demo',0,3079,1,'2020-08-21','done',NULL,0,27),(34,'check',0,3080,1,'2020-08-21','done',NULL,0,27),(35,'hjhjh',0,3063,504,'2020-08-26','done',NULL,0,19),(36,'check',0,3081,1,'2020-09-04','done',NULL,0,27),(37,'testing',0,3082,247,'2020-09-12','done',NULL,0,4),(38,'gems manager testing',0,3085,1,'2020-09-13','done',NULL,0,40),(39,'testing 100 bugs',0,3083,1004,'2020-09-13','to_do',NULL,0,48),(40,'test',0,3086,504,'2020-09-14','done',NULL,0,18),(41,'test-01',0,3087,504,'2020-09-14','done',NULL,0,18),(42,'done',0,3085,1,'2020-09-17','done',NULL,0,27),(43,'test',0,3089,1,'2020-09-17','done',NULL,0,40),(44,'Testing',0,3090,5,'2020-09-19','done',NULL,0,13),(45,'k,',0,3091,1,'2020-09-19','done',NULL,0,27),(46,'jj',0,3091,1,'2020-09-19','done',NULL,0,40),(47,'test',0,3088,504,'2020-09-19','done',NULL,0,19),(48,'test',0,3088,504,'2020-09-19','done',NULL,0,50),(49,'tesy',0,3091,1,'2020-09-20','done',NULL,0,43),(50,'tesy',0,3091,1,'2020-09-20','done',NULL,0,46),(51,'test tz',0,3092,1,'2020-09-20','done',NULL,0,27),(52,'ss',0,3093,1,'2020-09-25','done',NULL,0,27),(53,'testing',0,3093,1,'2020-09-29','done',NULL,0,40),(54,'to install motion sensor',0,3095,1,'2020-10-03','done',NULL,0,43),(55,'test',0,3096,504,'2020-10-05','done',NULL,0,18),(56,'vcvcv',0,3096,504,'2020-10-05','done',NULL,0,19),(57,'today task',0,3097,1,'2020-10-11','done',NULL,0,27),(58,'test',0,3098,1000,'2020-10-10','done',NULL,0,53),(59,'test',0,3098,1000,'2020-10-10','done',NULL,0,56),(60,'test1',0,3099,1000,'2020-10-10','done',NULL,0,53),(61,'check',0,3097,1,'2020-10-12','done',NULL,0,40),(62,'test',0,3100,1,'2020-10-12','done',NULL,0,27),(63,'test',0,3101,1008,'2020-10-12','to_do',NULL,0,56),(64,'Complete the first part',0,3103,1000,'2020-10-13','done',NULL,0,53),(65,'purchase',0,3105,1022,'2020-10-20','to_do',NULL,0,58),(66,'To complete',0,3106,506,'2020-10-24','to_do',NULL,0,28),(67,'testing',0,3107,247,'2020-10-24','done',NULL,0,48),(68,'sa',0,3102,1,'2020-10-27','done',NULL,0,27),(69,'http://web.whatsapp.com',0,3102,1,'2020-11-02','done',NULL,0,40),(70,'sasa',0,3108,1,'2020-11-02','done','csxcbs. xnbx \n\n\njdgchabdkhjcbdakjbc',0,40),(71,'testing',0,3110,247,'2020-11-06','to_do',NULL,0,48),(72,'Testing the ERP poryal',0,3112,5,'2020-11-27','done',NULL,0,13),(73,'Testing',0,3114,5,'2020-11-30','done',NULL,0,34),(74,'Test',0,3114,5,'2020-11-30','done',NULL,0,41),(75,'n',0,3115,5,'2020-12-07','done',NULL,0,13),(76,'check all the modules',0,3069,621,'2020-12-18','done',NULL,0,37),(77,'discussio',0,3116,621,'2020-12-19','done',NULL,0,37),(78,'erp demo checking',0,3116,621,'2020-12-23','done',NULL,0,36),(79,'f',0,3117,5,'2020-12-26','done',NULL,0,13),(80,'portal checking',0,3118,621,'2021-01-21','done',NULL,0,36),(81,'learn about registration process',0,3119,1032,'2021-03-25','done',NULL,0,62),(82,'teaching all the modules',0,3120,621,'2021-04-01','done',NULL,0,36),(83,'teaching',0,3121,621,'2021-04-02','to_do',NULL,0,37),(84,'client visit',0,3130,1,'2024-02-27','done',NULL,0,60),(85,'Bug cleared',0,3130,1,'2024-03-08','done','',0,40),(86,'bug fixing',0,3131,1,'2024-05-14','done',NULL,0,40),(87,'done',0,3134,1,'2024-06-06','to_do',NULL,0,48),(88,'process',0,3134,1,'2024-06-06','to_do',NULL,0,27),(89,'done',0,3134,1,'2024-06-06','to_do',NULL,0,43),(90,'done',0,3134,1,'2024-06-06','to_do',NULL,0,65),(91,'done',0,3134,1,'2024-06-06','to_do',NULL,0,40),(92,'Hai',0,3134,1,'2024-06-11','to_do',NULL,0,60),(93,'1',0,3134,1,'2024-06-13','to_do',NULL,0,73),(94,'1',0,3134,1,'2024-06-13','done',NULL,0,72),(95,'15',0,3134,1,'2024-06-14','done',NULL,0,46),(96,'2',0,3134,1,'2024-06-15','to_do',NULL,0,74);
/*!40000 ALTER TABLE `attendance_to_do` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:14
