-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `delivery`
--

DROP TABLE IF EXISTS `delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `estimate_date` date NOT NULL,
  `valid_until` date NOT NULL,
  `note` mediumtext CHARACTER SET ucs2 COLLATE ucs2_general_ci,
  `last_email_sent_date` date DEFAULT NULL,
  `status` enum('draft','sold','given','received','ret_sold','approve_ret_sold','invoice_created') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'draft',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `delivered_date` date DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `import_from` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `invoice_no` int DEFAULT NULL,
  `proformainvoice_no` int DEFAULT NULL,
  `f_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `l_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `address` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `phone` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `member_type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `invoice_for_dc` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `dc_type_id` int NOT NULL,
  `buyers_order_no` varchar(50) CHARACTER SET ucs2 COLLATE ucs2_general_ci DEFAULT NULL,
  `buyers_order_date` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `dispatched_through` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `dispatch_date` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `demo_period` mediumtext CHARACTER SET ucs2 COLLATE ucs2_general_ci,
  `lc_no` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `lc_date` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `dispatch_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `dispatch_docket` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `waybill_no` varchar(45) CHARACTER SET dec8 COLLATE dec8_swedish_ci DEFAULT NULL,
  `state` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `zip` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `country` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `invoice_client_id` int DEFAULT NULL,
  `dispatch_by` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `delivery_address_company_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `delivery_address_city` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `delivery_address_state` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `delivery_address_country` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `delivery_address_zip` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `delivery_address` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `invoice_delivery_address` tinyint NOT NULL DEFAULT '0',
  `delivery_address_phone` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `invoice_date` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `dc_no` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery`
--

LOCK TABLES `delivery` WRITE;
/*!40000 ALTER TABLE `delivery` DISABLE KEYS */;
INSERT INTO `delivery` VALUES (1,547,'2020-04-04','2020-05-05','',NULL,'',0,'2020-04-17','2020-04-17','-',0,0,NULL,NULL,NULL,NULL,'tm','18140119',1,'','2020-04-17','2','2020-04-17','','','2020-04-17','','',NULL,'',NULL,NULL,NULL,1,NULL,'','','','','','',0,NULL,'2020-04-17',''),(2,6,'2020-05-12','2020-06-12','',NULL,'given',0,'2020-05-12',NULL,'-',0,0,NULL,NULL,NULL,NULL,'tm','18140119',1,'','2020-05-12','2','2020-05-12','','','2020-05-12','','2500000-1 Testing',NULL,'',NULL,NULL,NULL,10,NULL,'','','','','','',0,NULL,'2020-05-12',''),(3,5,'2020-06-16','2020-06-28','',NULL,'draft',0,NULL,NULL,'inv',3,0,NULL,NULL,NULL,NULL,'tm','45',1,'g','2020-06-15','3','2020-06-15','','77','2020-06-15','n','n',NULL,'',NULL,NULL,NULL,2,NULL,'','','','','','',0,NULL,'2020-06-15','DELIVERy3'),(4,0,'2020-08-01','2020-08-01','',NULL,'received',0,'2020-08-28','2020-08-28','pi',NULL,1,'Mr.','kumar','Chennai','','others','',1,'','2020-08-01','4','2020-08-01','','','2020-08-01','','',NULL,'','','','',13,NULL,'','','','','','',0,NULL,'2020-08-01','DELIVERY CHALLAN #4'),(5,356,'2020-08-15','2020-09-01','',NULL,'invoice_created',0,'2020-08-28','2020-08-28','-',0,0,NULL,NULL,NULL,NULL,'tm','32',1,'','2020-08-28','4','2020-08-28','','','2020-08-28','','',NULL,'',NULL,NULL,NULL,165,NULL,'','','','','','',0,NULL,'2020-08-28','DELIVERY CHALLAN #5'),(6,356,'2020-09-22','2020-09-23','',NULL,'received',0,'2020-09-22','2020-09-22','pi',0,2,NULL,NULL,NULL,NULL,'tm','',1,'','2020-09-22','3','2020-09-22','','','2020-09-22','','',NULL,'',NULL,NULL,NULL,4,NULL,'','','','','','',0,NULL,'2020-09-22','DELIVERY NOTE #6'),(7,0,'2020-10-27','2020-10-28','',NULL,'received',0,'2020-10-27','2020-10-27','-',0,0,'kumar','swamy','chn','','others','',1,'','2020-10-27','2','2020-10-27','','','2020-10-27','','',NULL,'','tamil Nadu','','india',8,NULL,'','','','','','',0,NULL,'2020-10-27','DELIVERY NOTE #7'),(8,0,'2020-10-27','2020-10-28','',NULL,'invoice_created',0,'2020-10-27','2020-10-27','-',0,0,'k','m','chn','','others','31',1,'','2020-10-27','2','2020-10-27','','','2020-10-27','','',NULL,'','tamilnadu','','india',8,NULL,'','','','','','',0,NULL,'2020-10-27','DELIVERY NOTE #8'),(9,627,'2020-11-09','2020-11-09','',NULL,'sold',0,'2020-11-09','2020-11-09','-',0,0,'','',NULL,NULL,'tm','30',1,'','2020-11-09','4','2020-11-09',NULL,'','2020-11-09','','',NULL,'',NULL,NULL,NULL,8,NULL,'XYZ Ltd','Kanchipuram','Tamil Nadu','99','602105','419, Mambakkam,\nChennai Bangalore Highway,\nSriperumbudur',0,'09443354888','2020-11-09',''),(10,418,'2020-11-04','2020-11-11','',NULL,'received',0,'2020-11-09','2020-11-09','-',0,0,NULL,NULL,NULL,NULL,'tm','',1,'','2020-11-09','1','2020-11-09','','','2020-11-09','','',NULL,'',NULL,NULL,NULL,156,NULL,'','','','','','',0,NULL,'2020-11-09','DELIVERY NOTE #10'),(11,1028,'2020-11-30','2020-12-01','',NULL,'draft',0,NULL,NULL,'pi',NULL,5,NULL,NULL,NULL,NULL,'tm','DC001',1,'SEDC01','2020-11-29','4','','','','','','',NULL,'',NULL,NULL,NULL,181,NULL,'','','','','','',0,NULL,'2020-11-30','DELIVERY NOTE #11'),(12,5,'2020-12-04','2020-12-04','',NULL,'draft',0,NULL,NULL,'-',0,0,NULL,NULL,NULL,NULL,'tm','',1,'','','1','','','','','','',NULL,'',NULL,NULL,NULL,10,NULL,'','','','','','',0,NULL,'','DELIVERY NOTE #12'),(13,418,'2021-06-26','2021-07-03','',NULL,'sold',0,'2021-06-26','2021-06-26','-',0,0,NULL,NULL,NULL,NULL,'tm','',1,'','','4','','','','','','',NULL,'',NULL,NULL,NULL,163,NULL,'','','','','','',0,NULL,'','DELIVERY NOTE #13'),(14,418,'2021-07-16','2021-07-23','',NULL,'',0,'2021-07-16','2021-07-16','inv',14,NULL,NULL,NULL,NULL,NULL,'tm','',1,'','','1','','','','','','',NULL,'',NULL,NULL,NULL,10,NULL,'','','','','','',0,NULL,'','DELIVERY NOTE #14'),(15,537,'2021-07-16','2021-07-23','',NULL,'invoice_created',0,'2021-07-16','2021-07-16','-',0,0,NULL,NULL,NULL,NULL,'tm','40',1,'','','1','','','','','','',NULL,'',NULL,NULL,NULL,163,NULL,'','','','','','',0,NULL,'','DELIVERY NOTE #15'),(16,4,'2021-06-23','2021-06-23','',NULL,'draft',0,NULL,NULL,'-',0,0,'','',NULL,NULL,'tm','37',1,'','2021-06-23','2','2021-06-23',NULL,'','2021-06-23','','',NULL,'',NULL,NULL,NULL,163,NULL,'ABC PVT LTD','','Albalam','99','','Gurgagon',0,'','2021-06-23',''),(17,418,'2024-06-01','2024-06-07','',NULL,'draft',0,NULL,NULL,'inv',14,NULL,NULL,NULL,NULL,NULL,'tm','8',1,'8','2024-06-27','3','','','778989808998','2024-07-02','','UI',NULL,'',NULL,NULL,NULL,160,NULL,'','','','','','',0,NULL,'2024-06-27','DELIVERY NOTE #17'),(18,418,'2024-06-07','2024-06-22','',NULL,'draft',0,NULL,NULL,'inv',14,NULL,NULL,NULL,NULL,NULL,'tm','8',1,'1','2024-06-21','2','2024-06-20','`','`','2024-05-31','`','`',NULL,'5',NULL,NULL,NULL,160,NULL,'`','','','','','16',1,NULL,'2024-06-14','DELIVERY NOTE #18'),(19,985,'2024-06-07','2024-06-07','',NULL,'draft',0,NULL,NULL,'inv',14,NULL,NULL,NULL,NULL,NULL,'tm','1',1,'1234','2024-06-15','3','2024-06-06','1','1','2024-06-07','1','11',NULL,'1',NULL,NULL,NULL,10,NULL,'1','','','','','',1,NULL,'2024-06-07','DELIVERY NOTE #19'),(20,537,'2024-06-12','2024-06-12','2',NULL,'draft',0,NULL,NULL,'pi',NULL,11,NULL,NULL,NULL,NULL,'tm','2',1,'2','2024-06-19','1','2024-06-12','2','2','2024-06-12','2','2',NULL,'222',NULL,NULL,NULL,10,NULL,'2','','','','','',1,NULL,'2024-06-12','DELIVERY NOTE #20'),(21,985,'2024-06-13','2024-06-20','',NULL,'draft',0,NULL,NULL,'inv',0,NULL,NULL,NULL,NULL,NULL,'tm','',1,'','','3','','','','','','',NULL,'',NULL,NULL,NULL,10,NULL,'','','','','','',0,NULL,'','DELIVERY NOTE #21'),(22,1039,'2024-06-21','2024-06-30','',NULL,'draft',0,NULL,NULL,'inv',3,NULL,NULL,NULL,NULL,NULL,'om','',1,'','2024-07-06','1','','','','','','',NULL,'',NULL,NULL,NULL,10,NULL,'','','','','','',0,NULL,'','DELIVERY NOTE #22'),(23,537,'2024-06-05','2024-06-28','',NULL,'draft',0,NULL,NULL,'inv',14,NULL,NULL,NULL,NULL,NULL,'tm','2',1,'1234','2024-06-06','4','','','778989808998','2024-06-07','','1',NULL,'',NULL,NULL,NULL,9,NULL,'','','','','','',0,NULL,'2024-07-03','DELIVERY NOTE #23'),(24,418,'2024-06-06','2024-06-08','',NULL,'draft',0,NULL,NULL,'inv',14,NULL,NULL,NULL,NULL,NULL,'tm','1234',1,'123415','2024-06-26','1','2024-06-26','1','1234567890','2024-06-26','1','1',NULL,'1',NULL,NULL,NULL,173,NULL,'1','','','','','',1,NULL,'2024-06-28','DELIVERY NOTE #24'),(25,985,'2024-06-05','2024-06-27','1',NULL,'draft',0,NULL,NULL,'inv',14,NULL,NULL,NULL,NULL,NULL,'tm','123456',1,'1234','2024-06-22','4','2024-07-03','1','','2024-06-25','','1',NULL,'1',NULL,NULL,NULL,9,NULL,'','','','','','',0,NULL,'2024-06-21','DELIVERY NOTE #25'),(26,1042,'2024-06-21','2024-07-06','3',NULL,'draft',0,NULL,NULL,'inv',14,NULL,NULL,NULL,NULL,NULL,'om','123454',1,'123456','2024-06-28','2','2024-06-22','3','456','2024-06-06','3','3',NULL,'3',NULL,NULL,NULL,11,NULL,'34','','','','','',1,NULL,'2024-07-05','DELIVERY NOTE #26'),(27,418,'2024-06-06','2024-06-14','1',NULL,'draft',0,NULL,NULL,'inv',14,NULL,NULL,NULL,NULL,NULL,'tm','123456',1,'123456','2024-06-20','4','2024-06-28','1','1','2024-06-22','','1',NULL,'1',NULL,NULL,NULL,163,NULL,'','','','','','',0,NULL,'2024-06-22','DELIVERY NOTE #27'),(28,985,'2024-06-05','2024-06-29','123',NULL,'draft',0,NULL,NULL,'inv',14,NULL,NULL,NULL,NULL,NULL,'tm','3',1,'3','2024-06-21','3','2024-06-27','3','3','2024-06-27','3','3',NULL,'3',NULL,NULL,NULL,9,NULL,'11','1','2','2','629502','16',1,NULL,'2024-06-13','DELIVERY NOTE #28'),(29,985,'2024-06-05','2024-07-13','1',NULL,'draft',0,NULL,NULL,'inv',14,NULL,NULL,NULL,NULL,NULL,'tm','1123',1,'123415','2024-06-22','1','2024-07-03','1','1234567890','2024-06-22','1','1',NULL,'1',NULL,NULL,NULL,163,NULL,'111','1','1','1','1','1',1,NULL,'2024-07-04','DELIVERY NOTE #29'),(30,1040,'2024-06-22','2024-06-22','',NULL,'draft',0,NULL,NULL,'inv',14,NULL,NULL,NULL,NULL,NULL,'om','123454',1,'1234','2024-06-27','1','2024-06-24','1','1234567890','2024-06-24','1','1',NULL,'1',NULL,NULL,NULL,9,NULL,'123456','','','','','',1,NULL,'2024-06-22','DELIVERY NOTE #30'),(31,985,'2024-06-05','2024-10-18','',NULL,'draft',0,NULL,NULL,'inv',14,NULL,NULL,NULL,NULL,NULL,'tm','1234',1,'123415','2024-06-27','3','2024-06-27','1','1','2024-06-26','1','123',NULL,'1',NULL,NULL,NULL,10,NULL,'','','','','','',0,NULL,'2024-07-05','DELIVERY NOTE #31');
/*!40000 ALTER TABLE `delivery` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:14
