-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `part_no_generation`
--

DROP TABLE IF EXISTS `part_no_generation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `part_no_generation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `unit_type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '',
  `rate` double NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `category` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `make` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `hsn_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `hsn_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `stock` double NOT NULL,
  `vendor_id` varchar(45) DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_activity_user` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title_UNIQUE` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `part_no_generation`
--

LOCK TABLES `part_no_generation` WRITE;
/*!40000 ALTER TABLE `part_no_generation` DISABLE KEYS */;
INSERT INTO `part_no_generation` VALUES (1,'DS-2CE1AD0T-IRPF','2MP Camera\n','NOS',150,0,'','','8525','18','CCTV camera HSN',1,'6,4',NULL,NULL),(2,'1lH1SCA3-090B','Cable','Meters',18,1,'','','8471','18','Cables',10,'1,3','2021-04-01 04:58:20',1),(3,'GC-BNC-001','BNC Pin','NOS',10,1,'Camera accessories','','8571','18','Camera Accessories',10,'4,1','2021-04-01 04:58:48',1),(4,'GC-DC-001','DC Pin','NOS',20,0,'Camera accessories','','8571','18','Camera Accessories',10,'5',NULL,NULL),(5,'DS-7A08HQHI-K1','DVR','NOS',6850,0,'DVR','','8521','18','DVR/NVR/XVR',1,'4',NULL,NULL),(6,'alkflksjfbjlfbz','','',500,1,'','','','','',1,'1','2021-04-01 04:58:23',1),(7,'nnbnstnhj','nhnf\nfaedef\ndfgfeg\n','',55,1,'','','','','',0,'1','2021-04-01 04:58:52',1),(8,'DS-2cead0t-IRP/eco','camera\n2mp\neco','',1000,0,'','','','','',0,NULL,NULL,NULL),(9,'DS-2CE1AC0T-IRP','2MP DOME CAMERA','NOS',1250,0,'CAMERA','HIKVISION','8525','18','CCTV camera HSN',10,'6,4',NULL,NULL),(10,'gct-001','camera accessories','NOS',25000,0,'','','8521','18','DVR/NVR/XVR',25,'4',NULL,NULL),(11,'example part1','m','NOS',10000,0,'solar','1','8544','5','Solar Water 365',1,'217',NULL,NULL),(12,'abc123','ws','Meters',1,0,'s','2','8898','28','camera gst',21,'3',NULL,NULL),(13,'DS-123456-S','Camera','PCS',3500,0,'Camera','1','8525','18','CCTV camera HSN',165,'6,4,5',NULL,NULL),(14,'123','Cotton ','NOS',10,0,'Wear','2','8543','18','',1000,'3','2020-09-18 07:28:34',1),(15,'com1','comadsa','NOS',1000,0,'monitor','4','8517','18','Video Door Phone',1,'2','2020-09-21 11:15:35',1),(16,'com2','asddsf','NOS',2000,0,'CPU','1','8504','18','Power Adapter',1,'3','2020-09-21 11:16:37',1),(17,'DS-7A08HQHI-K1 DVR','GGG','NOS',7800,0,'DVR','3','8521','','',0,NULL,NULL,NULL),(18,'2','OFFICE REQUIRED','PCS',9,0,'OFFICE','7','8525','18','CCTV camera HSN',2,'230','2020-11-06 12:31:58',1024),(19,'GM-1001','Camera accessories ','PCS',2500,0,'1','3','8898','28','camera gst',10,'3','2020-11-28 06:15:12',1028),(20,'1','1','BOX',1200,0,'2','12','8521','18','DVR/NVR/XVR',1,'48','2024-06-10 12:29:41',1),(21,'Testing','1','PCS',1,0,'2','1','8545','18','feight',1,'219','2024-06-12 05:48:04',1),(22,'Testing1','1','Meters',1200,0,'2','3','8544','5','Solar Water 365',1,'233','2024-06-12 08:26:06',1);
/*!40000 ALTER TABLE `part_no_generation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:16
