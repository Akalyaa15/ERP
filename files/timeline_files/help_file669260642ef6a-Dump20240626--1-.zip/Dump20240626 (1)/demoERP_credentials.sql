-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `credentials`
--

DROP TABLE IF EXISTS `credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credentials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_date` datetime NOT NULL,
  `title` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `description` mediumtext,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `labels` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `url` varchar(300) DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_activity_user` int DEFAULT NULL,
  `files` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credentials`
--

LOCK TABLES `credentials` WRITE;
/*!40000 ALTER TABLE `credentials` DISABLE KEYS */;
INSERT INTO `credentials` VALUES (1,'2020-05-11 16:03:47','COMPUTER','System','System#123','user system 1',0,'Important','',NULL,NULL,''),(2,'2020-05-12 14:19:20','Instagram','123@gmail.com','123@123','Company Instagram Page',0,'Social Media','www.instaram.com',NULL,NULL,''),(3,'2020-08-28 10:54:19','Facebook','123@ac.com','123456','Faccebook Page',0,'social Media','',NULL,NULL,''),(4,'2021-04-03 10:17:18','gemicates','info.gemicates','123456','gemicates',1,'','','2021-04-07 09:30:23',1035,''),(5,'2021-04-07 09:33:31','twitter','Twitter page','123456','company twitter page',0,'','','2021-04-07 09:33:31',1035,''),(6,'2024-05-30 11:43:28','Akalyaa','D','Akalyaa15#09','18/49-1,Paramanvillai',0,'Important','web.iitm.ac.in','2024-05-30 11:43:28',1,'a:0:{}'),(7,'2024-06-01 10:02:07','Akalyaa','D','G','G',0,'','G','2024-06-01 10:02:07',1,'a:0:{}'),(8,'2024-06-01 10:02:07','Akalyaa','D','G','G',0,'','G','2024-06-01 10:02:07',1,'a:0:{}'),(9,'2024-06-03 11:50:19','Testing','Akalyaa','Akalya15#09','Testing',0,'Important','web.iitm.ac.in','2024-06-03 11:50:19',1,'a:0:{}'),(10,'2024-06-15 08:40:31','1','1','1','1',0,'','1','2024-06-15 08:40:31',1,'a:0:{}'),(11,'2024-06-26 06:11:54','Testing','TEsting1234','12345','1234',0,'1234','Testing','2024-06-26 06:11:54',1,'a:1:{i:0;a:2:{s:9:\"file_name\";s:61:\"credentials_file667bb12a199f6-LAMP-Installation-Procedure.txt\";s:9:\"file_size\";s:4:\"5128\";}}');
/*!40000 ALTER TABLE `credentials` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
