-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `partners`
--

DROP TABLE IF EXISTS `partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partners` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `address` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `city` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `state` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `zip` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `country` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_date` date NOT NULL,
  `website` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `phone` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `currency_symbol` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `starred_by` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `group_ids` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `vat_number` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `currency` varchar(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `disable_online_payment` tinyint(1) NOT NULL DEFAULT '0',
  `gstin_number_first_two_digits` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `gst_number` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `client_id` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `state_mandatory` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partners`
--

LOCK TABLES `partners` WRITE;
/*!40000 ALTER TABLE `partners` DISABLE KEYS */;
INSERT INTO `partners` VALUES (1,'SD Traders','NO.735G1/22, M.Lakshmanaraj Complex, Opp. To Bus Stand, Near Karuppasamy Temple, Thiruthangal â€“ 626 130.                  ','Viruthunagar','32',' 626 130.                  ','99','2019-12-12','','9750126120','â‚¹','','',0,NULL,'INR',0,'','','2575',NULL),(2,'Roop Automotive Ltd','Plot No G31 & H22, 9th Cross Street,\n\nSipcot Industrial Park Vallam Vadagal\nPalnallur Village, Echoor Post, Sriperumbudur â€“ 631 604.','CHENNAI','32','631 604','99','2020-03-30','','','â‚¹','','',0,NULL,'INR',0,'','','2903',NULL),(3,'Repl-  ALTORIO TECHNOLOGY SOLUTIONS LLP','#359, 9th Cross, M.S. Ramaiah Enclave  \n\n8th Mile, T. Dasarahalli, Bangalore â€“ 58\n\n ','bangalore','18','600 058','99','2020-04-14','sales@altorio.in','9606222413','â‚¹','','',0,NULL,'INR',0,'29','29ABQFA7710G1Z7','2905',NULL),(4,'Gemicates Technologies','Chennai','Chennai','32','600027','99','2020-04-18','','9677221397','₹','','',0,NULL,'INR',0,'','','4',NULL),(5,'Gems Technologies','Chennai','Chennai','32','600018','99','2020-04-23','','9876543311','₹','','1000',0,NULL,'INR',1,'33','GSTN1234V','6','yes'),(6,'ABC g pvt ltd','saidapet, chennai-16','Chennai','','600016','99','2020-05-11','','09790808689','₹','','',0,NULL,'INR',1,'33','33BBEPA7824A9Z5 ','10',NULL),(7,'gemicates- testing','saidapet, chennai-16','Chennai','','600016','99','2020-05-12','','09790808689','₹','','1001',0,NULL,'INR',0,'33','33BBEPA7824A9Z5 ','11',NULL),(8,'Dacom Infotech','1st street , saidapet','Chennai','44','600015','99','2020-05-15','','044-43587457','₹','','1001',0,NULL,'INR',0,'33','33AEFA3452P1Z0','13',NULL),(9,'example vendor','','','','','99','2020-06-15','','','₹','','',0,NULL,'INR',0,'','','159',NULL),(10,'123','419, Mambakkam,\nChennai Bangalore Highway,\nSriperumbudur','Kanchipuram','','602105','2','2020-07-07','','09443354888','','','',0,NULL,'',0,'','','164',NULL),(11,'Shree Chakra Impex -testing','no:52, 1 st nagar chennai','Chennai','44','600 006.','242','2020-07-07','afnoman@gmail.com','9585 773 771 ','₹','','',0,NULL,'INR',0,'33','33AGEPR7096K1ZU','166',NULL),(12,'gems service mart-testing','56, vetri nagar','chennai','32','600 445','99','2020-07-10','','','₹','','',0,NULL,'INR',0,'33','33ardgftyrhg','168',NULL),(13,'bnf company','saudi arabia','saudi arbia','','365121','224','2020-07-10','','8954545785225','AED','','',0,NULL,'DHI',0,'','','170',NULL),(14,'Partner test10','add','CHENNAI','44','600091','99','2020-09-08','','44666666','₹','','',0,NULL,'INR',0,'','','172','yes'),(15,'Yarunara','Mumbai','','','','225','2020-09-12','','','$','','',0,NULL,'USD',0,'','','174','no'),(16,'aaa','','','','','38','2020-09-12','','','$','','',0,NULL,'US ',0,'','','175','no'),(17,'Altarawat','Oman','','','','161','2020-09-19','','','OMR','','',0,NULL,'RIY',0,'','','176','no'),(18,'Partner test10','add66','CHENNAI','','600091','2','2020-10-01','','44666666','L','','',0,NULL,'ALL',0,'','','179','no'),(19,'Partner test10','add','CHENNAI','44','600091','99','2020-10-01','www.cango.com','44666666','₹','','1001',0,NULL,'INR',0,'','','180','yes'),(20,'Partner11','add partner','city','','76767676','17','2020-10-13','www.cango.com','33703300','BHD','','1001',0,NULL,'BHD',0,'28','Vat','183','no'),(21,'karthi','no 11 pilliyar street chennai-24','Chennai','32','600032','99','2020-11-06','www.karthi.com','+91 80 6752-128','₹','','',0,NULL,'INR',0,'','','184','yes'),(22,'technopath','','','','','2','2020-11-06','','','L','','',0,NULL,'ALL',0,'','','186','no'),(23,'Gemicates Technologies Pvt Ltd','11/6, Sundareshwarer Koil Street,\nSaidapet, Chennai','Chennai','32','600033','99','2020-11-06','','+91 80 6752-128','₹','','',0,NULL,'INR',0,'','','190','yes'),(24,'Akalyaa','18/49-1,Paramanvillai,Azhickal post','chennai','44','600043','99','2024-05-30','web.iitm.ac.in','9003612377','₹','','1001',0,NULL,'INR',0,'12','gst','196','yes');
/*!40000 ALTER TABLE `partners` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:14
