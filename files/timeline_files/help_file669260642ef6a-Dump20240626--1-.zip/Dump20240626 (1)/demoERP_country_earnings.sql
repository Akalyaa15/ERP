-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `country_earnings`
--

DROP TABLE IF EXISTS `country_earnings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country_earnings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `percentage` double DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `key_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `country_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country_earnings`
--

LOCK TABLES `country_earnings` WRITE;
/*!40000 ALTER TABLE `country_earnings` DISABLE KEYS */;
INSERT INTO `country_earnings` VALUES (1,'Basic Salary','40% From total salary per month','active',40,0,'basic_salary',99),(2,'Conveyance','','active',50,0,'',99),(3,'HRA','','active',60,0,'',99),(4,'Medical Allowance','','active',10,0,'',99),(5,'Misc.Reimbursement','','active',25,0,'',99),(6,'Spl.Allowance','','active',5,0,'',99),(7,'Basic Salary','-','active',40,0,'basic_salary',224),(8,'Basic Salary','Monthly Basic','active',40,0,'basic_salary',17),(9,'Basic Salary','-','active',40,0,'basic_salary',1),(10,'Basic Salary','-','active',40,0,'basic_salary',2),(11,'Site allowance ','OT & HH','active',50,1,'',17),(12,'Transportation','Local Transport','active',80,0,'',17),(13,'Housing','Housing Allowance ','active',70,0,'',17),(14,'Basic Salary','-','active',40,0,'basic_salary',245),(15,'Basic Salary','-','active',40,0,'basic_salary',3),(16,'Basic Salary','-','active',40,0,'basic_salary',38),(17,'Basic Salary','-','active',40,0,'basic_salary',9),(18,'Basic Salary','-','active',40,0,'basic_salary',7),(19,'Basic Salary','-','active',40,0,'basic_salary',8),(20,'Basic Salary','-','active',40,0,'basic_salary',10),(21,'HRA','','active',100,0,'',10),(22,'special','','active',50,0,'',10),(23,'Basic Salary','-','active',40,0,'basic_salary',33),(24,'Basic Salary','-','active',40,0,'basic_salary',11),(25,'Basic Salary','-','active',40,0,'basic_salary',246),(26,'Basic Salary','-','active',40,0,'basic_salary',12),(27,'Basic Salary','-','active',40,0,'basic_salary',226),(28,'Basic Salary','-','active',40,0,'basic_salary',13),(29,'Basic Salary','-','active',40,0,'basic_salary',247),(30,'Basic Salary','-','active',40,0,'basic_salary',14),(31,'Basic Salary','-','active',40,0,'basic_salary',248),(32,'Basic Salary','-','active',40,0,'basic_salary',249),(33,'Basic Salary','-','active',40,0,'basic_salary',15),(34,'Basic Salary','-','active',40,0,'basic_salary',16);
/*!40000 ALTER TABLE `country_earnings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:16
