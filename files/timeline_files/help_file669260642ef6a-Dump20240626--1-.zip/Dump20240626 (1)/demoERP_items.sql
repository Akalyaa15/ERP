-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `unit_type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '',
  `rate` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `category` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `make` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `hsn_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `gst` double NOT NULL,
  `hsn_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `stock` double NOT NULL,
  `profit_percentage` double NOT NULL,
  `actual_value` double NOT NULL,
  `MRP` double NOT NULL,
  `associated_with_part_no` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `profit_value` varchar(45) DEFAULT NULL,
  `installation_hsn_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `installation_gst` double DEFAULT NULL,
  `installation_profit_percentage` double DEFAULT NULL,
  `installation_actual_value` double DEFAULT NULL,
  `installation_profit_value` varchar(45) DEFAULT NULL,
  `installation_hsn_description` varchar(45) DEFAULT NULL,
  `installation_rate` varchar(50) DEFAULT NULL,
  `product_generation_id` int DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_activity_user` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,'DS-2CE1AD0T-IRPF','Camera','NOS','1',0,'','','',0,'',0,0,0,0,'',NULL,'',0,0,NULL,NULL,'','500',1,NULL,NULL),(2,'GC-CA-001','Camera Accessories','NOS','3,4',0,'','','',0,'',-1,0,0,0,'',NULL,'',0,0,NULL,NULL,'','10',2,NULL,NULL),(3,'1lH1SCA3-090B','3+1 cables','Meters','2',0,'','','',0,'',90,0,0,0,'',NULL,'',0,0,NULL,NULL,'','520',3,NULL,NULL),(4,'GC-BNC-001','BNC','','3',0,'','','',0,'',0,0,0,0,'',NULL,'',0,0,NULL,NULL,'','54',5,NULL,NULL),(5,'DS-7A08HQHI-K1','DVR\n','NOS','5',0,'','','',0,'',10,0,0,0,'',NULL,'',0,0,NULL,NULL,'','520',4,NULL,NULL),(6,'DS-2CE1AC0T-IRP','2MP Dome Camera','NOS','9',0,'Camera','4','8525',18,'CCTV camera HSN',14,20,0,0,'',NULL,'9987',18,10,NULL,NULL,'Services','500',6,'2020-10-01 09:32:07',1),(7,'exampleid123','solar','NOS','2,11,4',0,'solaruuu','1','8544',5,'Solar Water 365',1,1,0,0,'',NULL,'8525',18,2,NULL,NULL,'CCTV camera HSN','700',8,NULL,NULL),(8,'bnnnn','vvhh','Meters','2,4',1,'solarvbb','','8541',5,'solar street light',3,3,0,0,'',NULL,'8525',18,5,NULL,NULL,'CCTV camera HSN','5',9,NULL,NULL),(9,'DS-24BHDG125','h8uo','Meters','1',0,'','','8545',18,'feight',0,0,0,0,'',NULL,'8504',18,32,NULL,NULL,'Power Adapter','0',10,NULL,NULL),(10,'Gemicates DS-123456-S','4MP Camera','PCS','13,1',0,'Bullet Camera','1','8525',18,'CCTV camera HSN',20,15,0,0,'',NULL,'9987',18,10,NULL,NULL,'Services','150',11,NULL,NULL),(11,'GCT-2020-001-TESTING','CAMERA TOOLS','NOS','10',0,'CAMERA ACCESOIRES','','8571',18,'Camera Accessories',2,5,0,0,'',NULL,'9987',18,5,NULL,NULL,'Services','20',7,'2021-06-25 17:04:34',1),(12,'2','System services','PCS','18',0,'OFFICE','7','8525',18,'CCTV camera HSN',2,10,0,0,'',NULL,'9987',18,12,NULL,NULL,'Services','54',14,'2020-11-06 12:59:08',1024),(13,'GM-1001','Camera accessories\n','PCS','19',0,'2','3','8898',28,'camera gst',25,40,0,0,'',NULL,' 995461 ( Camera Installation )',18,20,NULL,NULL,'camera Installation Charges ','560',15,'2020-12-02 06:32:32',1028),(14,'glo123','jkl','NOS','14',0,'','2','8525',18,'CCTV camera HSN',9,3,0,0,'',NULL,'8543',18,4,NULL,NULL,'','5',12,'2020-12-16 10:08:15',1),(15,'sa001','cctv','NOS','1,5,8',0,'2','1','8544',5,'Solar Water 365',1,10,0,0,'',NULL,'8544',5,15,NULL,NULL,'Solar Water 365','100',16,'2021-06-25 17:53:01',1),(16,'sa002','FF','NOS','19',0,'2','3','8544',5,'Solar Water 365',1,1,0,0,'19',NULL,'0',0,0,NULL,NULL,'','0',17,'2021-06-25 16:36:45',1),(17,'Testing','KO','Meters','1',0,'3','1','8541',5,'solar street light',0,2,0,0,'',NULL,'8525',18,1,NULL,NULL,'CCTV camera HSN','0',18,'2024-06-03 11:08:59',1),(18,'HI','','Days','10',0,'','','8541',5,'solar street light',1,2,0,0,'10',NULL,'8541',5,3,NULL,NULL,'solar street light','2',19,'2024-06-03 11:13:22',1),(19,'IITM GROUP','hi','NOS','1',0,'2','7','8544',5,'Solar Water 365',1,1,0,0,'1',NULL,'9031',18,1,NULL,NULL,'Sensors','1',20,'2024-06-03 11:15:33',1),(20,'Gemicates','Gemicates','BOX','4',0,'4','2','8541',5,'solar street light',1,1,0,0,'4',NULL,'8517',18,1,NULL,NULL,'Video Door Phone','1',21,'2024-06-03 11:20:56',1),(21,'1','1','BOX','5',0,'3','3','8541',5,'solar street light',8,12,0,0,'',NULL,'8525',18,1,NULL,NULL,'CCTV camera HSN','1',23,'2024-06-12 05:54:54',1),(22,'COMP_SYS_01','adsad','Meters','15,16',0,'','2','8541',5,'solar street light',1,1,0,0,'',NULL,'8521',18,1,NULL,NULL,'DVR/NVR/XVR','1',13,'2024-06-21 11:16:49',1);
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
