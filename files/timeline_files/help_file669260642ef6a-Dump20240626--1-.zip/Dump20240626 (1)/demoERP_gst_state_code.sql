-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gst_state_code`
--

DROP TABLE IF EXISTS `gst_state_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gst_state_code` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `gstin_number_first_two_digits` varchar(45) DEFAULT 'null',
  `state_code` varchar(45) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gst_state_code`
--

LOCK TABLES `gst_state_code` WRITE;
/*!40000 ALTER TABLE `gst_state_code` DISABLE KEYS */;
INSERT INTO `gst_state_code` VALUES (1,'Andaman and Nicobar Islands','35','AN',0),(2,'Andhra Pradesh','28','AP',0),(3,'Andhra Pradesh (New)','37','AD',0),(4,'Arunachal Pradesh','12','AR',0),(5,'Assam','18','AS',0),(6,'Bihar','10','BH',0),(7,'Chandigarh','4','CH',0),(8,'Chattisgarh','22','CT',0),(9,'Dadra and Nagar Haveli','26','DN',0),(10,'Daman and Diu','25','DD',0),(11,'Delhi','7','DL',0),(12,'Goa','30','GA',0),(13,'Gujarat','24','GJ',0),(14,'Haryana','6','HR',0),(15,'Himachal Pradesh','2','HP',0),(16,'Jammu and Kashmir','1','JK',0),(17,'Jharkhand','20','JH',0),(18,'Karnataka','29','KA',0),(19,'Kerala','32','KL',0),(20,'Lakshadweep Islands','31','LD',0),(21,'Madhya Pradesh','23','MP',0),(22,'Maharashtra','27','MH',0),(23,'Manipur','14','MN',0),(24,'Meghalaya','17','ME',0),(25,'Mizoram','15','MI',0),(26,'Nagaland','13','NL',0),(27,'Odisha','21','OR',0),(28,'Pondicherry','34','PY',0),(29,'Punjab','3','PB',0),(30,'Rajasthan','8','RJ',0),(31,'Sikkim','11','SK',0),(32,'Tamil Nadu','33','TN',0),(33,'Telangana','36','TS',0),(34,'Tripura','16','TR',0),(35,'Uttar Pradesh','9','UP',0),(36,'Uttarakhand','5','UT',0),(37,'West Bengal','19','WB',0),(38,'bengal','65','BH',1);
/*!40000 ALTER TABLE `gst_state_code` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:13
