-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `purchase_order_items`
--

DROP TABLE IF EXISTS `purchase_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `quantity` double NOT NULL,
  `unit_type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '',
  `rate` double NOT NULL,
  `total` double NOT NULL,
  `purchase_order_id` int NOT NULL,
  `category` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `hsn_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `make` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `tax` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `gst` double NOT NULL,
  `tax_amount` double NOT NULL,
  `discount_percentage` double NOT NULL,
  `net_total` double NOT NULL,
  `hsn_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `with_gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `without_gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `quantity_total` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_items`
--

LOCK TABLES `purchase_order_items` WRITE;
/*!40000 ALTER TABLE `purchase_order_items` DISABLE KEYS */;
INSERT INTO `purchase_order_items` VALUES (1,'DS-7A08HQHI-K1','DVR',10,'NOS',6850,68500,1,'DVR','8521','','',18,12330,0,80830,'DVR/NVR/XVR',0,'yes',NULL,68500),(2,'GC-BNC-001','BNC Pin',1,'NOS',10,9.5,2,'Camera accessories','8571','','',18,1.71,5,11.21,'Camera Accessories',0,'yes',NULL,10),(3,'DS-2CE1AD0T-IRPF','2MP Camera\n',10,'NOS',150,1500,2,'','8525','','',18,270,0,1770,'CCTV camera HSN',0,'yes',NULL,1500),(4,'1lH1SCA3-090B','Cable',10,'',18,180,2,'','8471','','',18,32.4,0,212.4,'Cables',0,'yes',NULL,180),(5,'GC-DC-001','DC Pin',52,'NOS',20,1040,2,'Camera accessories','8571','','',18,187.2,0,1227.2,'Camera Accessories',0,'yes',NULL,1040),(6,'DS-7A08HQHI-K1','DVR',5,'NOS',6850,34250,2,'DVR','8521','','',18,6165,0,40415,'DVR/NVR/XVR',0,'yes',NULL,34250),(7,'alkflksjfbjlfbz','',1,'',500,500,2,'','','','',0,0,0,500,'',0,'yes',NULL,500),(8,'DS-2cead0t-IRP/eco','camera\n2mp\neco',10,'',1000,10000,2,'','','','',0,0,0,10000,'',0,'yes',NULL,10000),(9,'nnbnstnhj','nhnf\nfaedef\ndfgfeg\n',10,'',55,550,2,'','','','',0,0,0,550,'',0,'yes',NULL,550),(10,'GC-BNC-001','BNC Pin',10,'NOS',10,98,5,'Camera accessories','8571','','',18,17.64,2,115.64,'Camera Accessories',0,'yes',NULL,100),(11,'DS-2CE1AC0T-IRP','2MP DOME CAMERA',10,'NOS',1250,12500,6,'CAMERA','8525','HIKVISION','',18,2250,0,14750,'CCTV camera HSN',0,'yes',NULL,12500),(12,'DS-7A08HQHI-K1','DVR',2,'NOS',6850,13700,6,'DVR','8521','','',18,2466,0,16166,'DVR/NVR/XVR',0,'yes',NULL,13700),(13,'GC-BNC-001','BNC Pin',10,'NOS',10,100,6,'Camera accessories','8571','','',18,18,0,118,'Camera Accessories',0,'yes',NULL,100),(14,'1lH1SCA3-090B','Cable',100,'Meters',18,1800,6,'','8471','','',18,324,0,2124,'Cables',0,'yes',NULL,1800),(15,'1lH1SCA3-090B','Cable',23,'Meters',18,414,7,'','8471','','',18,74.52,0,488.52,'Cables',0,'yes',NULL,414),(16,'example part1','m',55,'NOS',10000,187000,8,'solar','8544','1','',5,9350,66,196350,'Solar Water 365',0,'yes',NULL,550000),(17,'DS-7A08HQHI-K1','DVR',56,'NOS',0,0,9,'DVR','-','','',0,0,0,0,'-',0,'no',NULL,0),(18,'GC-BNC-001','BNC Pin',165,'NOS',10,1650,11,'Camera accessories','8571','','',18,297,0,1947,'Camera Accessories',0,'yes',NULL,1650),(19,'DS-7A08HQHI-K1','DVR',2,'NOS',6850,13700,10,'DVR','8521','','',18,2466,0,16166,'DVR/NVR/XVR',0,'yes',NULL,13700),(20,'nnbnstnhj','nhnf\nfaedef\ndfgfeg\n',5,'',20,100,12,'','-','','',0,0,0,100,'-',0,'no',NULL,100),(21,'com1','comadsa',1,'NOS',1000,900,13,'monitor','8517','4','',18,162,10,1062,'Video Door Phone',0,'yes',NULL,1000),(22,'DS-7A08HQHI-K1','DVR',67,'NOS',666,40606.02,14,'DVR','-','','',0,0,9,40606.02,'-',0,'no',NULL,44622),(23,'DS-7A08HQHI-K1','DVR',400,'NOS',6850,2685200,15,'DVR','8521','','',18,483336,2,3168536,'DVR/NVR/XVR',0,'yes',NULL,2740000),(24,'DS-2cead0t-IRP/eco','camera\n2mp\neco',60,'',1000,55800,15,'','','','',0,0,7,55800,'',0,'yes',NULL,60000),(25,'DS-7A08HQHI-K1 DVR','GGG',88,'NOS',7800,631488,15,'DVR','8521','3','',0,0,8,631488,'',0,'yes',NULL,686400),(26,'DS-2CE1AD0T-IRPF','2MP Camera\n',2,'NOS',150,300,16,'','8525','','',18,54,0,354,'CCTV camera HSN',0,'yes',NULL,300),(27,'DS-7A08HQHI-K1','',1,'NOS',200,200,15,'','8517','','',0,0,0,200,'',0,'yes',NULL,200),(28,'GC-BNC-001','BNC Pin',10,'NOS',0.051320000000000005,0.482408,17,'Camera accessories','-','','',0,0,6,0.482408,'-',0,'no',NULL,0.5132),(29,'GC-BNC-001','BNC Pin',15,'NOS',10,150,18,'Camera accessories','8571','','',18,27,0,177,'Camera Accessories',0,'yes',NULL,150),(30,'1lH1SCA3-090B','Cable',10,'Meters',18,180,19,'','8471','','',18,32.4,0,212.4,'Cables',0,'yes',NULL,180),(31,'DS-2CE1AC0T-IRP','2MP DOME CAMERA',1,'NOS',247296.15875,247296.15875,21,'','-','','',0,0,0,247296.15875,'-',0,'no',NULL,247296.15875);
/*!40000 ALTER TABLE `purchase_order_items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:14
