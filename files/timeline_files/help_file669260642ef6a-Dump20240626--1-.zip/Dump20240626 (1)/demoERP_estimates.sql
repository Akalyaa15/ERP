-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `estimates`
--

DROP TABLE IF EXISTS `estimates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `estimate_request_id` int NOT NULL DEFAULT '0',
  `estimate_date` date NOT NULL,
  `valid_until` date NOT NULL,
  `note` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `last_email_sent_date` date DEFAULT NULL,
  `status` enum('draft','sent','accepted','declined') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'draft',
  `tax_id` int NOT NULL DEFAULT '0',
  `tax_id2` int NOT NULL DEFAULT '0',
  `project_id` int NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `delivery_note_date` date DEFAULT NULL,
  `supplier_ref` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `other_references` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `terms_of_payment` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `buyers_order_no` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `buyers_order_date` date DEFAULT NULL,
  `dispatch_document_no` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `destination` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `dispatched_through` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `terms_of_delivery` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `freight_amount` double NOT NULL,
  `gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `hsn_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `hsn_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `delivery_address` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `estimate_delivery_address` tinyint NOT NULL DEFAULT '0',
  `delivery_address_company_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `delivery_address_city` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `delivery_address_state` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `delivery_address_zip` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `delivery_address_country` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `without_gst` tinyint NOT NULL DEFAULT '0',
  `lut_number` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `with_gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `with_inclusive_tax` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `freight_tax_amount` double DEFAULT NULL,
  `delivery_address_phone` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `estimate_no` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `payment_status` enum('draft','not_paid') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'draft',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimates`
--

LOCK TABLES `estimates` WRITE;
/*!40000 ALTER TABLE `estimates` DISABLE KEYS */;
INSERT INTO `estimates` VALUES (1,1,0,'2020-04-18','2020-04-22','',NULL,'accepted',0,0,0,0,'0000-00-00','','','Demand Draft','','0000-00-00','','','','',0,'','','','',0,'','','','','',0,'458975- testing',NULL,NULL,NULL,NULL,'','','draft'),(2,2,0,'2020-05-08','2020-06-08','',NULL,'accepted',0,0,0,0,'2020-05-08','ABT/2021/092','','Cash','AT/2021/PO/053','2020-05-06','','Mumbai','2','',1180,'18','8545','feight','Pune',1,'Desire Pvt Ltd','Pune','Maharastra','','',0,'',1000,'yes','no',180,'022-48715721','','draft'),(3,9,0,'2019-11-02','2019-12-01','',NULL,'accepted',0,0,0,0,'2020-05-11','GCT14180466-3','GCT14180472 -testing','Cash','18140107 ','2020-05-11','','','2','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','','draft'),(4,9,0,'2020-05-12','2020-06-11','',NULL,'sent',0,0,0,0,'2020-05-13','GCT 197645-TESTING','','Cash','1238205','2020-05-13','','CHENGELPET','2','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','','draft'),(5,158,0,'2020-06-15','2020-06-24','',NULL,'accepted',0,0,0,0,'2020-06-15','','','Cash','','2020-06-15','','','','',5000,'5','8544','Solar Water 365','',0,'','','','','',0,'',4761.9047619048,'yes','yes',238.09523809524,'','PROFORMA5','draft'),(6,14,0,'2020-07-06','2020-07-30','',NULL,'draft',0,0,0,0,'2020-07-06','','','Cash','','2020-07-06','','','','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro6','draft'),(7,2,0,'2020-08-01','2020-08-01','',NULL,'draft',0,0,0,0,'2020-08-01','','','Cash','','2020-08-01','','','5','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro7','draft'),(8,13,0,'2020-08-27','2020-09-02','',NULL,'accepted',0,0,0,0,'2020-08-27','','','NEFT','','2020-08-27','','','5','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro8','draft'),(9,1,0,'2020-08-27','2020-08-30','',NULL,'sent',0,0,0,0,'2020-08-27','','','Cheque','','2020-08-27','','','5','',0,'','','','',0,'','','','','',0,'458975- testing',NULL,NULL,NULL,NULL,'','pro9a','draft'),(10,173,0,'2020-09-11','2020-09-13','',NULL,'sent',0,0,0,0,'2020-09-11','','','NEFT','','2020-09-11','','','','',118,'18','8545','feight','',0,'','','','','',0,'',100,'yes','no',18,'','pro10','draft'),(11,178,0,'2020-09-29','2020-10-08','',NULL,'draft',0,0,0,0,'2020-09-29','red3','dd','Cheque','yt34','2020-09-29','tttt89','chennai','1','free',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro11','draft'),(12,179,0,'2020-10-01','2020-10-31','',NULL,'declined',0,0,0,0,'2020-10-01','Supplier ref2','ref2','Cheque','yt3466','2020-10-01','tttt89','chennai','1','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro12','draft'),(13,182,0,'2020-10-13','2020-10-30','n',NULL,'draft',0,0,0,0,'2020-10-13','sup','dd','Cash','yt3466','2020-10-13','TKT887','chennai','1','uuu',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro13','draft'),(14,183,0,'2020-10-13','2020-10-30','nnn',NULL,'draft',0,0,0,0,'2020-10-13','sup','dd','Cash','yt34','2020-10-13','TKT887','chennai','1','hhh',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro14','draft'),(15,13,0,'2020-11-06','2020-11-29','security',NULL,'accepted',0,0,0,0,'2020-11-06','pan card','aadhar card','Cash','1234','2020-11-06','','Chennai','2','before 10PM',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro15','draft'),(16,14,0,'2020-11-06','2020-11-14','',NULL,'draft',0,0,0,0,'2020-11-11','','','NEFT','','2020-11-11','','','','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro16','draft'),(17,192,0,'2020-12-02','2020-12-04','DC031220201',NULL,'accepted',0,0,0,0,'2020-12-02','Gemicates ','','Cash','INQC0001','2020-12-02','','Anna Nagar','4','Cash on delivery',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro17','draft'),(18,193,0,'2021-03-25','2021-04-01','Direct',NULL,'sent',0,0,0,0,'2021-03-25','','','Cash','','2021-03-25','','Covai','2','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro18','draft'),(19,181,0,'2021-06-23','2021-06-24','',NULL,'sent',0,0,0,0,'2021-06-23','','','Cash','','2021-06-23','','','','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro19','draft'),(20,181,0,'2021-06-23','2021-06-30','',NULL,'accepted',0,0,56,0,'2021-06-23','','','NEFT','','2021-06-23','','','','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro20','not_paid'),(21,1,0,'2021-06-24','2021-07-01','',NULL,'accepted',0,0,57,0,'2021-06-25','Q00001','','NEFT','','2021-06-25','','','','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro21','draft'),(22,2,0,'2021-06-25','2021-07-02','',NULL,'accepted',0,0,0,0,'2021-06-25','1234','','NEFT','','2021-06-25','','','4','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro22','draft'),(23,2,0,'2022-05-03','2022-05-19','',NULL,'draft',0,0,0,0,'2022-05-05','','','NEFT','','2022-05-05','','','','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro23','draft'),(24,164,0,'2024-05-09','2024-05-16','hi',NULL,'draft',0,0,0,0,'2024-05-30','hi','','Cheque','1234','2024-05-30',' 4567890','hi','3','hi',0,'','','','171,89',1,'hi','chennai','tamilnadu','629502','91',0,'',NULL,NULL,NULL,NULL,'9003612377','pro24','draft'),(25,163,0,'2024-05-31','2024-06-07','',NULL,'draft',0,0,0,0,'2024-06-01','','','Cheque','','2024-06-01','','','','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro25','draft'),(26,196,0,'2024-06-06','2024-06-20','1',NULL,'draft',0,0,0,0,'2024-06-07','1','1','Cash','1','2024-06-07','1','1','2','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro26','draft'),(27,163,0,'2024-06-07','2024-06-07','1',NULL,'draft',0,0,0,0,'2024-06-07','1','1','Cash','1','2024-06-07','4567890','1','1','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro27','draft'),(28,9,0,'2024-06-07','2024-06-21','q',NULL,'draft',0,0,0,0,'2024-06-07','123456','1','Cash','1','2024-06-07','','','3','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro28','draft'),(29,9,0,'2024-06-07','2024-06-13','1',NULL,'draft',0,0,0,0,'2024-06-07','1','','IMPS','1','2024-06-07','1','1','3','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro29','draft'),(30,9,0,'2024-06-07','2024-06-13','1',NULL,'draft',0,0,0,0,'2024-06-07','1','1','IMPS','1','2024-06-07','1','1','1','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro30','draft'),(31,9,0,'2024-06-08','2024-06-27','1',NULL,'draft',0,0,0,0,'2024-06-08','1','1','Demand Draft','1','2024-06-08','1','1','','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro31','draft'),(32,163,0,'2024-06-08','2024-06-21','1',NULL,'draft',0,0,0,0,'2024-06-08','1','123','Demand Draft','1234','2024-06-08','1','1','4','1',0,'','','','2',1,'11','','','','',0,'',NULL,NULL,NULL,NULL,'1','pro32','draft'),(33,9,0,'2024-06-05','2024-06-22','1',NULL,'draft',0,0,0,0,'2024-06-08','1','1','Cash','1','2024-06-08','1','1','3','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro33','draft'),(34,10,0,'2024-06-07','2024-06-07','1',NULL,'draft',0,0,0,0,'2024-06-08','123456','123','Cash','1','2024-06-08','1','1','1','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro34','draft'),(35,160,0,'2024-05-29','2024-06-22','3',NULL,'draft',0,0,0,0,'2024-06-08','3','123','IMPS','3','2024-04-15','3','1','1','1',0,'','','','',1,'h','','','','',0,'14256',NULL,NULL,NULL,NULL,'h','pro35','draft'),(36,163,0,'2024-06-08','2024-06-14','1',NULL,'draft',0,0,0,0,'2024-06-08','123456','1','IMPS','1','2024-06-08','1','1','1','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro36','draft'),(37,9,0,'2024-06-10','2024-06-14','1',NULL,'draft',0,0,0,0,'2024-06-10','','1','IMPS','1','2024-06-10','1','1','','1',0,'','','','1',1,'1','1','1','1','1',0,'',NULL,NULL,NULL,NULL,'1','pro37','draft'),(38,171,0,'2024-06-04','2024-06-27','1',NULL,'draft',0,0,0,0,'2024-06-10','1','1','Demand Draft','1','2024-06-10','1','1','2','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro38','draft'),(39,201,0,'2024-06-12','2024-06-12','1',NULL,'draft',0,0,0,0,'2024-06-12','1','1','Cash','1','2024-06-12','1','1','3','1',0,'','','','',1,'1','','','','',0,'14256',NULL,NULL,NULL,NULL,'1','pro39','draft'),(40,160,0,'2024-06-21','2024-06-21','1',NULL,'draft',0,0,0,0,'2024-06-21','1','1','Cash','1','2024-06-21','1','1','2','1',0,'','','','',0,'','','','','',0,'14256',NULL,NULL,NULL,NULL,'','pro40','draft'),(41,9,0,'2024-06-21','2024-07-03','1',NULL,'draft',0,0,0,0,'2024-06-21','1234','1','Cheque','1','2024-06-11','3','1','1','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro41','draft'),(42,163,0,'2024-06-21','2024-06-27','1',NULL,'draft',0,0,0,0,'2024-06-21','123456','123','IMPS','1','2024-06-21','1','1','4','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro42','draft'),(43,163,0,'2024-06-13','2024-06-27','1',NULL,'draft',0,0,0,0,'2024-06-21','123456','123','Cheque','1','2024-06-21','1','1','1','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro43','draft'),(44,9,0,'2024-06-07','2024-06-13','1',NULL,'draft',0,0,0,0,'2024-06-21','123456','123','IMPS','1','2024-06-21','1','1','4','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro44','draft'),(45,11,0,'2024-05-28','2024-06-29','12',NULL,'draft',0,0,0,0,'2024-06-22','123456','1','NEFT','123415','2024-06-22','1','1','4','1',0,'','','','',1,'gemicates','','','','',0,'',NULL,NULL,NULL,NULL,'111','pro45','draft'),(46,9,0,'2024-06-13','2024-06-13','1',NULL,'draft',0,0,0,0,'2024-06-22','1234','123','Demand Draft','1','2024-06-22','1','1','4','12345678',0,'','','','',1,'gemicates','','','','',0,'',NULL,NULL,NULL,NULL,'657657567','pro46','draft'),(47,10,0,'2024-05-29','2024-08-25','1',NULL,'draft',0,0,0,0,'2024-06-26','1','123','Cheque','1','2024-06-26','1','1','3','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','pro47','draft');
/*!40000 ALTER TABLE `estimates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
