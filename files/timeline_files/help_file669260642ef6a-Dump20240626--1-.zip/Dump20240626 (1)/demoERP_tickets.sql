-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `project_id` int NOT NULL DEFAULT '0',
  `ticket_type_id` int NOT NULL,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_by` int NOT NULL,
  `created_at` datetime NOT NULL,
  `status` enum('new','client_replied','open','closed') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'new',
  `last_activity_at` datetime DEFAULT NULL,
  `assigned_to` int NOT NULL DEFAULT '0',
  `labels` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES (1,1,0,9,'invoice date cannot be more than current',247,'2020-04-18 11:37:04','open','2020-04-18 11:37:04',12,'',0),(2,3,0,1,'Test',355,'2020-04-18 13:48:13','closed','2020-04-18 13:48:13',497,'',0),(3,3,0,9,'Currency Conversion',247,'2020-04-25 11:32:30','closed','2020-04-25 11:32:30',0,'',0),(4,3,0,9,'invoice Modification',247,'2020-04-25 11:36:17','closed','2020-04-25 11:36:17',0,'',0),(5,6,0,9,'Issie',963,'2020-04-25 16:24:10','closed','2020-04-25 16:24:10',0,'',0),(6,4,0,9,'ssssss Program on Technology Information Forecasting and assessment Council (TIFAC)',1,'2020-05-19 11:33:39','closed','2020-05-19 11:33:39',1,'',0),(7,6,0,2,'Training Program on Technology Information Forecasting',1,'2020-05-19 11:34:23','closed','2020-05-19 11:34:23',12,'',0),(8,14,0,9,'Checking bugs in gems Portal',15,'2020-05-19 12:39:51','closed','2020-05-19 12:39:51',15,'',0),(9,18,0,1,'sasa',1,'2020-05-23 22:22:19','closed','2020-05-23 22:22:19',418,'',0),(10,168,0,9,'Gems Manager Software Development',1,'2020-09-21 10:32:53','open','2020-09-21 10:32:53',537,'',0),(11,171,0,9,'Ticket',1,'2020-09-30 09:49:37','closed','2020-09-30 09:50:26',624,'ww',0),(12,13,0,8,'Test1',1,'2020-10-13 15:35:50','new','2020-10-13 15:35:50',985,'ww',0),(13,175,0,9,'audit',1024,'2020-11-06 08:59:06','new','2020-11-06 08:59:06',985,'CORRECTING',0),(14,162,0,9,'test',1,'2021-03-25 17:11:21','new','2021-03-25 17:11:21',1032,'',0),(15,3,0,9,'System service',1,'2024-02-26 20:29:49','open','2024-02-26 20:32:12',537,'',0),(16,10,0,9,'hoi',1,'2024-05-25 12:36:24','new','2024-05-25 12:36:24',418,'ww',0),(17,191,0,9,'Testing',1,'2024-05-30 12:24:16','new','2024-05-30 12:24:16',418,'CORRECTING',0),(18,160,0,9,'Akalyaa',1,'2024-06-01 10:07:58','new','2024-06-01 10:07:58',0,'',0),(19,163,0,9,'Testing',1,'2024-06-01 12:42:26','new','2024-06-01 12:42:26',537,'CORRECTING',0),(20,9,0,9,'Testing',1,'2024-06-06 06:10:15','new','2024-06-06 06:10:15',418,'CORRECTING',0),(21,173,0,9,'Testing',1,'2024-06-06 06:16:49','new','2024-06-06 06:16:49',418,'CORRECTING',0),(22,10,0,9,'Testing',1,'2024-06-08 09:01:00','new','2024-06-08 09:01:00',418,'CORRECTING',0),(23,163,0,9,'Testing',1,'2024-06-10 08:08:10','new','2024-06-10 08:08:10',985,'CORRECTING',0),(24,9,0,9,'Testing',1,'2024-06-15 08:47:09','new','2024-06-15 08:47:09',418,'',0),(25,9,0,9,'Akalyaa',1,'2024-06-22 06:16:12','new','2024-06-22 06:16:12',537,'CORRECTING',0),(26,162,0,9,'hi',1,'2024-06-22 07:23:36','new','2024-06-22 07:23:36',537,'CORRECTING',0),(27,163,0,9,'Testing',1,'2024-06-26 05:22:26','new','2024-06-26 05:22:26',985,'',0);
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
