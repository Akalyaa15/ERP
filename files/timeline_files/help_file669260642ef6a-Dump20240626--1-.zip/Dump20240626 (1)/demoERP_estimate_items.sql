-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `estimate_items`
--

DROP TABLE IF EXISTS `estimate_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimate_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `quantity` double NOT NULL,
  `unit_type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `rate` double NOT NULL,
  `total` double NOT NULL,
  `estimate_id` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `category` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `hsn_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `make` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `tax` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `gst` double NOT NULL,
  `tax_amount` double NOT NULL,
  `discount_percentage` double NOT NULL,
  `net_total` double NOT NULL,
  `hsn_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `profit_percentage` double NOT NULL,
  `actual_value` double NOT NULL,
  `MRP` double NOT NULL,
  `associated_with_part_no` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `profit_value` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `with_gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `without_gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `quantity_total` double NOT NULL,
  `discount_amount` double DEFAULT NULL,
  `with_installation` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `with_installation_gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `installation_hsn_code_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `installation_gst` double DEFAULT NULL,
  `installation_rate` double DEFAULT NULL,
  `installation_hsn_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `installation_total` double DEFAULT NULL,
  `subtotal` double DEFAULT NULL,
  `installation_tax_amount` double DEFAULT NULL,
  `client_profit_margin` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `estimate_type` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimate_items`
--

LOCK TABLES `estimate_items` WRITE;
/*!40000 ALTER TABLE `estimate_items` DISABLE KEYS */;
INSERT INTO `estimate_items` VALUES (1,'GC-CA-001','Camera Accessories',1,'NOS',30,30,1,0,'','-','','',0,0,0,40,'-',0,0,0,'','5','no',NULL,30,0,'yes','no','-',0,10,'-',10,40,0,'20',NULL),(2,'DS-2CE1AD0T-IRPF','Camera',10,'NOS',150,1425,2,0,'','8525','','',18,256.5,5,7581.5,'CCTV camera HSN',0,0,0,'','250','yes',NULL,1500,75,'yes','yes','Services',18,500,'9987',5000,6500,900,'20',NULL),(3,'GC-BNC-001','BNC',1000,'',11,11000,3,0,'','','','',0,0,0,65000,'',0,0,0,'','1000','yes',NULL,11000,0,'yes','yes','',0,54,'',54000,65000,0,'10',NULL),(4,'GC-BNC-001','BNC',25,'',11,275,4,0,'','','','',0,0,0,1625,'',0,0,0,'','25','yes',NULL,275,0,'yes','yes','',0,54,'',1350,1625,0,'10',NULL),(5,'DS-7A08HQHI-K1','DVR\n',1,'NOS',0,0,5,0,'','8544','','',5,0,8,0,'Solar Water 365',0,0,0,'','0','yes',NULL,0,0,'yes','yes','Solar Water 365',5,520,'8544',520,520,0,'20',NULL),(6,'exampleid123','solar',1,'NOS',10138.38,10138.38,5,0,'solaruuu','8544','1','',5,506.919,0,11487.819,'Solar Water 365',1,0,0,'','1759.553553719','yes',NULL,10138.38,0,'yes','yes','CCTV camera HSN',18,714,'8525',714,10852.38,128.52,'20',NULL),(7,'Gemicates DS-123456-S','4MP Camera',3,'PCS',4197.5,6296.25,8,0,'Bullet Camera','8525','1','',18,1133.325,50,8013.675,'CCTV camera HSN',15,0,0,'','1642.5','yes',NULL,12592.5,6296.25,'yes','yes','',18,165,'9987',495,13087.5,89.1,'',NULL),(8,'DS-2CE1AD0T-IRPF','Camera',10,'NOS',150,1425,10,0,'','8525','','',18,256.5,5,1681.5,'CCTV camera HSN',0,0,0,'','0','yes',NULL,1500,75,'no','no','-',18,0,'-',0,6500,0,'',NULL),(9,'GC-CA-001','Camera Accessories',7,'NOS',31.304399999999998,219.1308,7,0,'','-','','',0,0,0,292.1744,'-',0,0,0,'','0','no',NULL,219.1308,0,'yes','no','-',0,10.4348,'-',73.0436,292.1744,0,'',NULL),(10,'DS-7A08HQHI-K1','DVR\n',666,'NOS',45.52236,28498.8182544,11,0,'','-','','',0,0,6,30269.2060944,'-',0,0,0,'','6996.43656','no',NULL,30317.89176,1819.0735056,'yes','no','-',0,2.65824,'-',1770.38784,32088.2796,0,'30',NULL),(11,'GC-CA-001','Camera Accessories',8,'NOS',43.343579999999996,322.4762352,12,0,'','-','','',0,0,7,438.0591152,'-',0,0,0,'','0','no',NULL,346.74864,24.2724048,'yes','no','-',0,14.447859999999999,'-',115.58288,462.33152,0,'',NULL),(12,'GC-CA-001','Camera Accessories',77,'NOS',0.16981800000000002,12.4221867,13,0,'','-','','',0,0,5,16.3846067,'-',0,0,0,'','1.188726','no',NULL,13.075986,0.6537993,'yes','no','-',0,0.051460000000000006,'-',3.96242,17.038406,0,'10',NULL),(13,'GC-BNC-001','BNC',55,'',0.051320000000000005,2.737922,14,0,'','-','','',0,0,3,2.737922,'-',0,0,0,'','0','no',NULL,2.8226,0.084678,'no','no','-',0,0,'-',0,18.06464,0,'',NULL),(14,'2','System services',3,'PCS',9.9,28.215,15,0,'OFFICE','8525','7','',18,5.0787,5,247.3929,'CCTV camera HSN',10,0,0,'','2.7','yes',NULL,29.7,1.485,'yes','yes','Services',18,60.480000000000004,'9987',181.44,211.14,32.6592,'',NULL),(15,'DS-2CE1AC0T-IRP','2MP Dome Camera',40,'NOS',1500,45000,16,0,'Camera','8525','4','',18,8100,25,79060,'CCTV camera HSN',20,0,0,'','20000','yes',NULL,60000,15000,'yes','yes','',18,550,'9987',22000,82000,3960,'30',NULL),(16,'GM-1001','Camera accessories\n',15,'PCS',4550,66543.75,17,0,'2','8898','3','',28,18632.25,2.5,286956,'camera gst',40,0,0,'','28102.941176471','yes',NULL,68250,1706.25,'yes','yes','camera Installation Charges ',18,11400,' 995461 ( Camera Installation )',171000,239250,30780,'30',NULL),(17,'GC-CA-001','Camera Accessories',1,'NOS',39,39,17,0,'','','','',0,0,0,49,'',0,0,0,'','9','yes',NULL,39,0,'yes','yes','',0,10,'',10,49,0,'30',NULL),(18,'GC-CA-001','Camera Accessories',1,'NOS',42,37.8,18,0,'','-','','',0,0,10,37.8,'-',0,0,0,'','12','no',NULL,42,4.2,'no','no','-',0,0,'-',0,52,0,'40',NULL),(19,'SID001','ENGINEER AND TECHNICIAN',1,'Days',0.5086,0.5086,19,0,'3','-','','',0,0,0,0.5086,'-',0,0,0,'','0','no',NULL,0.5086,0,'no','no','-',0,0,'-',0,0.5086,0,'30','1'),(20,'SID002','SKILLED TECHNICIAN',22,'Days',25,550,20,0,'3','-','','',0,0,0,550,'-',0,0,0,'','0','no',NULL,550,0,'no','no','-',0,0,'-',0,550,0,'30','1'),(21,'SID003','ENGINEER T&C',22,'Days',75,1650,20,0,'3','-','','',0,0,0,1650,'-',0,0,0,'','0','no',NULL,1650,0,'no','no','-',0,0,'-',0,1650,0,'30','1'),(22,'SID002','SKILLED TECHNICIAN',1,'Days',25,25,21,0,'3','-','','',0,0,0,25,'-',0,0,0,'','0','no',NULL,25,0,'no','no','-',0,0,'-',0,25,0,'10','1'),(23,'SID001','ENGINEER AND TECHNICIAN',1,'Days',75,75,9,0,'3','-','','',0,0,0,75,'-',0,0,0,'','0','no',NULL,75,0,'no','no','-',0,0,'-',0,75,0,'10','1'),(24,'sa001','cctv',1,'NOS',10400,7280,22,1,'2','8544','1','',5,364,30,7644,'Solar Water 365',30,0,0,'','2400','yes',NULL,10400,3120,'no','no','-',5,0,'-',0,10515,0,'',NULL),(25,'sa001','cctv',1,'NOS',13520,9464,22,1,'2','8544','1','',5,473.2,30,9937.2,'Solar Water 365',30,0,0,'','5070','yes',NULL,13520,4056,'no','no','-',5,0,'-',0,13635,0,'30',NULL),(26,'sa002','FF',1,'NOS',3250,0,22,0,'2','8544','3','',5,0,100,0,'Solar Water 365',0,3250,3412.5,'19','750','yes',NULL,3250,3250,'no','no','-',0,0,'-',0,3250,0,'30',NULL),(27,'sa001','cctv',1,'NOS',10400,8840,22,1,'2','8544','1','',5,442,15,9282,'Solar Water 365',0,0,0,'','2400','yes',NULL,10400,1560,'no','no','-',5,0,'-',0,10515,0,'30',NULL),(28,'SID002','SKILLED TECHNICIAN',1,'Days',25,25,22,0,'3','-','','',0,0,0,25,'-',0,0,0,'','0','no',NULL,25,0,'no','no','-',0,0,'-',0,25,0,'30','1');
/*!40000 ALTER TABLE `estimate_items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:16
