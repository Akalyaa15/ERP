-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `invoice_payments`
--

DROP TABLE IF EXISTS `invoice_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount` double NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method_id` int NOT NULL,
  `note` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `invoice_id` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `transaction_id` tinytext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_by` int DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `reference_number` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `files` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `client_po_payment_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_payments`
--

LOCK TABLES `invoice_payments` WRITE;
/*!40000 ALTER TABLE `invoice_payments` DISABLE KEYS */;
INSERT INTO `invoice_payments` VALUES (1,500,'2020-04-30',4,'',1,0,NULL,247,'2020-04-17 19:23:55','','',NULL),(2,-5266,'2020-04-19',1,'wdads',3,0,NULL,247,'2020-04-18 18:37:54','','',NULL),(3,75250,'2020-05-09',7,'Advance Payment',5,0,NULL,247,'2020-05-09 10:28:50','','',NULL),(4,2500,'2020-05-14',7,'',8,0,NULL,621,'2020-05-13 14:31:53','','',NULL),(5,15000,'2020-05-28',1,'',9,0,NULL,621,'2020-05-13 14:33:18','','',NULL),(6,900,'2020-06-15',1,'test',10,0,NULL,1,'2020-06-15 14:02:05','123','a:1:{i:0;a:2:{s:9:\"file_name\";s:52:\"invoice_payment_file5ee7320566795-Screenshot--3-.png\";s:9:\"file_size\";s:6:\"152114\";}}',NULL),(7,600,'2020-08-28',1,'Payment Rec',13,0,NULL,247,'2020-08-28 07:48:18','15','a:1:{i:0;a:2:{s:9:\"file_name\";s:120:\"invoice_payment_file5f48b6c268fa3-A_Rangasamy_Engineers_Pvt_Ltd-Gemicates_Technologies_Private_Limited-Work_Orders-1.pdf\";s:9:\"file_size\";s:6:\"106196\";}}',NULL),(8,10,'2020-09-18',1,'advance',22,0,NULL,1,'2020-09-18 07:23:57','123','a:1:{i:0;a:2:{s:9:\"file_name\";s:53:\"invoice_payment_file5f64608d0f7d0-ACME-26-08-2019.pdf\";s:9:\"file_size\";s:5:\"51035\";}}',NULL),(9,1000,'2020-09-27',5,'fine',24,0,NULL,1,'2020-09-27 05:48:24','yyy','a:1:{i:0;a:2:{s:9:\"file_name\";s:49:\"invoice_payment_file5f7027a8781f4-Meet-25920.docx\";s:9:\"file_size\";s:5:\"11251\";}}',NULL),(10,45,'2020-09-29',1,'ggggg',25,0,NULL,1,'2020-09-29 11:50:47','uyuyu','a:1:{i:0;a:2:{s:9:\"file_name\";s:54:\"invoice_payment_file5f731f77ca350-todays-meeting-.docx\";s:9:\"file_size\";s:4:\"9665\";}}',NULL),(11,14000,'2020-09-12',7,'collecting\n',10,0,NULL,1024,'2020-11-06 10:45:25','456456','a:1:{i:0;a:2:{s:9:\"file_name\";s:71:\"invoice_payment_file5fa529455bf95-GCT-PI-20-21-002-Manimangalam-BDO.pdf\";s:9:\"file_size\";s:6:\"457890\";}}',NULL),(12,1251,'2020-11-10',1,'ad',30,0,NULL,247,'2020-11-10 05:16:52','10324324','a:1:{i:0;a:2:{s:9:\"file_name\";s:102:\"invoice_payment_file5faa224481950-Danway-Gemicates_Technologies_Private_Limited-Proforma_Invoice-1.pdf\";s:9:\"file_size\";s:6:\"112325\";}}',NULL),(13,97070,'2020-12-02',1,'payment against invoice no 10035',35,0,NULL,1028,'2020-12-02 06:43:31','112','a:1:{i:0;a:2:{s:9:\"file_name\";s:41:\"invoice_payment_file5fc73793b319b-acc.PNG\";s:9:\"file_size\";s:4:\"5010\";}}',NULL),(14,501,'2021-06-25',1,'paid',39,0,NULL,1,'2021-06-24 19:08:41','UTR12345','a:1:{i:0;a:2:{s:9:\"file_name\";s:42:\"invoice_payment_file60d4d839ce468-Logo.png\";s:9:\"file_size\";s:4:\"7713\";}}',NULL);
/*!40000 ALTER TABLE `invoice_payments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
