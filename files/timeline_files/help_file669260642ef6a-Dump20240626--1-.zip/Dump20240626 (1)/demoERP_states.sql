-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `states` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `country_code` varchar(45) DEFAULT 'null',
  `state_code` varchar(45) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `last_activity` datetime DEFAULT NULL,
  `last_activity_user` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `states` VALUES (1,'Andaman and Nicobar Islands','356','AN',0,NULL,NULL),(2,'Andhra Pradesh','356','AP',0,NULL,NULL),(3,'Andhra Pradesh (New)','356','AD',0,NULL,NULL),(4,'Arunachal Pradesh','356','AR',0,NULL,NULL),(5,'Assam','356','AS',0,NULL,NULL),(6,'Bihar','356','BH',0,NULL,NULL),(7,'Chandigarh','356','CH',0,NULL,NULL),(8,'Chattisgarh','356','CT',0,NULL,NULL),(9,'Dadra and Nagar Haveli','356','DN',0,NULL,NULL),(10,'Daman and Diu','356','DD',0,NULL,NULL),(11,'Delhi','356','DL',0,NULL,NULL),(12,'Goa','356','GA',0,NULL,NULL),(13,'Gujarat','356','GJ',0,NULL,NULL),(14,'Haryana','356','HR',0,NULL,NULL),(15,'Himachal Pradesh','356','HP',0,NULL,NULL),(16,'Jammu and Kashmir','356','JK',0,NULL,NULL),(17,'Jharkhand','356','JH',0,NULL,NULL),(18,'Karnataka','356','KA',0,NULL,NULL),(19,'Kerala','356','KL',0,NULL,NULL),(20,'Lakshadweep Islands','356','LD',0,NULL,NULL),(21,'Madhya Pradesh','356','MP',0,NULL,NULL),(22,'Maharashtra','356','MH',0,NULL,NULL),(23,'Manipur','356','MN',0,NULL,NULL),(24,'Meghalaya','356','ME',0,NULL,NULL),(25,'Mizoram','356','MI',0,NULL,NULL),(26,'Nagaland','356','NL',0,NULL,NULL),(27,'Odisha','356','OR',0,NULL,NULL),(28,'Pondicherry','356','PY',0,NULL,NULL),(29,'Punjab','356','PB',0,NULL,NULL),(30,'Rajasthan','356','RJ',0,NULL,NULL),(31,'Sikkim','356','SK',0,NULL,NULL),(32,'Tamil Nadu','356','TN',0,NULL,NULL),(33,'Telangana','356','TS',0,NULL,NULL),(34,'Tripura','356','TR',0,NULL,NULL),(35,'Uttar Pradesh','356','UP',0,NULL,NULL),(36,'Uttarakhand','356','UT',0,NULL,NULL),(37,'West Bengal','356','WB',0,NULL,NULL),(38,'bengal','356','BH',1,NULL,NULL),(39,'Lahore','586','LH',0,NULL,NULL),(40,'Albalam','004','AL',0,NULL,NULL),(41,'Badakhshan','004','BA',0,NULL,NULL),(42,'Ararat','840','AT',0,NULL,NULL),(43,'Cambridge','826','CB',0,NULL,NULL),(44,'TAMIL NADU','356','TN',0,NULL,NULL),(45,'Balochistan','586','BA',0,NULL,NULL),(46,'Tamilnadu','356','T1',0,NULL,NULL),(47,'TN','356','t',0,NULL,NULL),(48,'BELG','056','BG',0,NULL,NULL),(49,'ALbani','008','.',0,'2021-04-01 04:52:15',1),(50,'Testing','004','12',0,'2024-06-22 10:03:03',1);
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
