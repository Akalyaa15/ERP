-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `loan`
--

DROP TABLE IF EXISTS `loan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `loan_date` date NOT NULL,
  `category_id` int NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `amount` double NOT NULL,
  `files` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `project_id` int DEFAULT '0',
  `user_id` int NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `total` double NOT NULL,
  `voucher_no` int NOT NULL DEFAULT '0',
  `interest` double NOT NULL,
  `member_type` varchar(45) CHARACTER SET big5 COLLATE big5_chinese_ci DEFAULT NULL,
  `phone` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `company` int DEFAULT '0',
  `due_date` date DEFAULT NULL,
  `interest_amount` double NOT NULL,
  `status` enum('not_paid','paid') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'not_paid',
  `vendor_company` int DEFAULT '0',
  `last_activity` datetime DEFAULT NULL,
  `last_activity_user` int DEFAULT NULL,
  `payment_status` int DEFAULT '0',
  `currency_symbol` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `currency` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan`
--

LOCK TABLES `loan` WRITE;
/*!40000 ALTER TABLE `loan` DISABLE KEYS */;
INSERT INTO `loan` VALUES (1,'2020-04-17',6,'Loans for gems labs\n',25000,'a:1:{i:0;a:2:{s:9:\"file_name\";b:0;s:9:\"file_size\";s:6:\"101835\";}}','sd',0,0,0,25000,7,0,'om','0',0,'2020-04-18',0,'not_paid',0,NULL,NULL,0,'',''),(2,'2020-04-17',6,'Loans for gems labs\n',25000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:103:\"loan_file5eb94e0a44753-Akasaka_Electronics_Ltd-Gemicates_Technologies_Private_Limited-Work_Orders-5.pdf\";s:9:\"file_size\";s:5:\"98175\";}}','Loan ',0,1,0,26250,7,5,'tm','0',0,'2020-05-11',1250,'not_paid',0,NULL,NULL,0,'',''),(3,'2020-06-15',6,'Loan for Personal\n',8500,'a:1:{i:0;a:2:{s:9:\"file_name\";s:41:\"loan_file5ee73561502db-Screenshot--3-.png\";s:9:\"file_size\";s:6:\"152114\";}}','text',7,1,0,8755,3,3,'tm','0',0,'2020-06-15',255,'not_paid',0,NULL,NULL,0,'',''),(4,'2020-06-24',1,'test',8000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:41:\"loan_file5ef2d82048f13-Screenshot--1-.png\";s:9:\"file_size\";s:6:\"159770\";}}','example',14,1,0,8160,0,2,'tm','0',0,'2020-06-24',160,'not_paid',0,NULL,NULL,0,'',''),(5,'2020-09-27',11,'yyyy',77777,'a:1:{i:0;a:2:{s:9:\"file_name\";s:43:\"loan_file5f70475e7f7a3-todays-meeting-.docx\";s:9:\"file_size\";s:4:\"9665\";}}','Test1',32,1,0,79332.54,0,2,'tm','0',0,'2020-09-27',1555.54,'not_paid',0,'2020-12-02 09:44:07',1028,0,'',''),(6,'2020-10-01',2,'jj',10000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:43:\"loan_file5f75d1169a107-todays-meeting-.docx\";s:9:\"file_size\";s:4:\"9665\";}}','Glitches2',32,1,0,10200,0,2,'tm','0',0,'2020-10-30',200,'not_paid',0,'2020-10-01 12:52:38',1,0,'','');
/*!40000 ALTER TABLE `loan` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:13
