-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `purchase_orders`
--

DROP TABLE IF EXISTS `purchase_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vendor_id` int NOT NULL,
  `estimate_request_id` int NOT NULL DEFAULT '0',
  `purchase_order_date` date NOT NULL,
  `valid_until` date NOT NULL,
  `note` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `last_email_sent_date` date DEFAULT NULL,
  `status` enum('draft','not_paid') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'draft',
  `tax_id` int NOT NULL DEFAULT '0',
  `tax_id2` int NOT NULL DEFAULT '0',
  `project_id` int NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `delivery_note_date` date DEFAULT NULL,
  `supplier_ref` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `other_references` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `terms_of_payment` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `purchase_order_no` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `purchase_date` date DEFAULT NULL,
  `dispatch_document_no` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `destination` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `dispatched_through` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `terms_of_delivery` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `freight_amount` double NOT NULL,
  `gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `hsn_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `hsn_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `delivery_address` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `estimate_delivery_address` tinyint NOT NULL DEFAULT '0',
  `delivery_address_company_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `delivery_address_city` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `delivery_address_state` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `delivery_address_zip` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `delivery_address_country` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `partner_id` int NOT NULL DEFAULT '0',
  `without_gst` tinyint NOT NULL DEFAULT '0',
  `lut_number` varchar(45) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `with_gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `with_inclusive_tax` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `freight_tax_amount` double DEFAULT NULL,
  `quantity_total` double NOT NULL,
  `delivery_address_phone` varchar(45) DEFAULT NULL,
  `modified` int NOT NULL DEFAULT '0',
  `due_reminder_date` date DEFAULT NULL,
  `purchase_no` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_orders`
--

LOCK TABLES `purchase_orders` WRITE;
/*!40000 ALTER TABLE `purchase_orders` DISABLE KEYS */;
INSERT INTO `purchase_orders` VALUES (1,55,0,'2020-04-17','2020-04-30','',NULL,'not_paid',0,0,0,0,'2020-04-17','','','Demand Draft','','2020-04-17','','','','',619.5,'18','8545','feight','',0,'','','','','',0,0,'',525,'yes','no',94.5,0,'',0,NULL,''),(2,1,0,'2020-04-20','2020-04-24','',NULL,'not_paid',0,0,0,1,'2020-04-20','gemicates','technologies','Cash','54321','2020-04-20','pocket','chennaiu','4','',0,'','','','',1,'Gemicates Technologies','chennai','tamilnadu','631501','india',0,0,'',NULL,NULL,NULL,NULL,0,'0987654321',0,NULL,''),(3,1,0,'2020-04-23','2020-04-24','',NULL,'not_paid',0,0,0,1,'2020-04-23','kisho','','Cash','901','2020-04-23','','chennai','4','',0,'','','','chennai',1,'Gemicates ','chennai','Tamilnadu','600021','India',0,0,'',NULL,NULL,NULL,NULL,0,'8021234561',0,NULL,''),(4,168,0,'2020-04-23','2020-04-25','',NULL,'not_paid',0,0,0,0,'2020-04-23','kishore','','Demand Draft','','2020-04-23','','','','',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC4'),(5,214,0,'2020-04-23','2020-04-24','',NULL,'not_paid',0,0,0,0,'2020-04-23','','','Cheque','','0000-00-00','','','','',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,''),(6,207,0,'2020-05-11','2020-05-30','',NULL,'not_paid',0,0,0,0,'2020-05-11','ABT-2020/21-PI-2091','','Cash','PHIPL-PI-0342','2020-05-08','','Chennai','4','',295,'18','8545','feight','Sriperumbudur',1,'Mr. Kumar','Chennai','Tamilnadu','600584','India',0,0,'',250,'yes','no',45,0,'9857428486',0,NULL,''),(7,201,0,'2020-05-13','2020-06-11','',NULL,'not_paid',0,0,0,0,'2020-05-13','GCT 197645-TESTING','','Cash','','2020-05-13','','','','',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,''),(8,217,0,'2020-06-15','2020-06-24','',NULL,'not_paid',0,0,0,0,'2020-06-15','','','Cash','','2020-06-15','','','','',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC3218'),(9,113,0,'2020-07-11','2020-08-07','',NULL,'not_paid',0,0,0,0,'2020-07-11','PO-89/52/2019-20','','Cheque','15/20-20','2020-07-11','','chennai','','',0,'','','','',0,'','','','','',0,0,'14256',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC9'),(10,164,0,'2020-08-14','2020-08-14','',NULL,'not_paid',0,0,0,0,'2020-08-14','','','NEFT','','2020-08-14','','','','',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC10'),(11,124,0,'2020-08-15','2020-08-15','',NULL,'not_paid',0,0,0,0,'2020-08-15','','','Cash','a16516','2020-08-30','','','','',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC11'),(12,224,0,'2020-09-12','2020-09-13','',NULL,'not_paid',0,0,0,0,'2020-09-12','','','NEFT','','2020-09-12','','','','',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC12'),(13,3,0,'2020-09-21','2020-09-21','',NULL,'draft',0,0,0,0,'2020-09-21','','','Cheque','','2020-09-21','','','4','',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC13'),(14,226,0,'2020-09-30','2020-10-09','',NULL,'not_paid',0,0,0,0,'2020-09-30','Supplier ref2','ref2','Demand Draft','PL no 89','2020-09-30','tttt89','chennai','2','free',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC14'),(15,227,0,'2020-10-01','2020-10-30','DELIVERY NOTE',NULL,'not_paid',0,0,0,0,'2020-10-01','VENDOR34','SO34','Cash','PI78','2020-10-01','TKT88','chennai','1','FREE ON BOARD',4000,'18','8504','Power Adapter','',0,'','','','','',0,0,'',3389.8305084746,'yes','yes',610.16949152542,0,'',0,NULL,'ABC15'),(16,164,0,'2020-10-02','2020-10-14','',NULL,'draft',0,0,0,0,'2020-10-02','','','Cash','','2020-10-02','','','','',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC16'),(17,228,0,'2020-10-13','2020-10-31','bbbb',NULL,'not_paid',0,0,0,0,'2020-10-13','sup','SO34','Cash','PL no 89','2020-10-13','TKT887','chennai','1','tttt',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC17'),(18,116,0,'2020-10-27','2020-10-28','',NULL,'not_paid',0,0,0,0,'2020-10-27','','','Cash','','2020-10-27','','','','',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC18'),(19,17,0,'2020-11-09','2020-11-10','',NULL,'not_paid',0,0,0,0,'2020-11-09','','','Cash','','2020-11-09','','','','',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',1,NULL,'ABC19'),(20,164,0,'2021-06-25','2021-07-02','',NULL,'draft',0,0,0,0,'2021-06-25','','','Cash','','2021-06-25','','','','',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC20'),(21,164,0,'2021-07-16','2021-07-23','',NULL,'draft',0,0,0,0,'2021-07-16','','','Cash','','2021-07-16','','','','',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC21'),(22,164,0,'2024-06-07','2024-06-07','1',NULL,'draft',0,0,0,0,'2024-06-07','123456','1','Cash','1','2024-06-07','1','1','4','1',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC22'),(23,124,0,'2024-05-30','2024-06-06','1',NULL,'draft',0,0,0,0,'2024-06-07','123456','','Demand Draft','1','2024-06-07','1','1','2','1',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC23'),(24,200,0,'2024-06-08','2024-06-08','1',NULL,'draft',0,0,0,0,'2024-06-08','1','1','Cheque','1','2024-06-08','1','1','1','1',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC24'),(25,94,0,'2024-06-08','2024-06-14','1',NULL,'draft',0,0,0,0,'2024-06-08','1','123','Demand Draft','1','2024-06-08','4567890','1','1','1',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC25'),(26,164,0,'2024-06-07','2024-06-08','1',NULL,'draft',0,0,0,0,'2024-06-08','1','1','Cheque','1','2024-06-08','1','1','','1',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC26'),(27,164,0,'2024-06-08','2024-06-21','1',NULL,'draft',0,0,0,0,'2024-06-08','1','1','Cash','1','2024-06-08','1','1','','1',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC27'),(28,164,0,'2024-06-04','2024-07-27','1',NULL,'draft',0,0,0,0,'2024-06-08','1','1','Cash','1','2024-06-08','1','','2','',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC28'),(29,94,0,'2024-06-01','2024-06-15','1',NULL,'draft',0,0,0,0,'2024-06-08','','','Cheque','1','2024-06-08','4567890','1','','1',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC29'),(30,113,0,'2024-06-08','2024-06-08','1',NULL,'draft',0,0,0,0,'2024-06-08','123456','1','Cash','1','2024-06-08','1','1','2','1',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC30'),(31,200,0,'2024-06-08','2024-06-08','1',NULL,'draft',0,0,0,0,'2024-06-08','123456','1','Cheque','1','2024-06-08','','1','3','1',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC31'),(32,94,0,'2024-06-11','2024-06-12','1',NULL,'draft',0,0,0,0,'2024-06-11','1','1','Cash','1','2024-06-11','1','1','4','1',0,'','','','',1,'111','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC32'),(33,164,0,'2024-06-12','2024-06-13','1',NULL,'draft',0,0,0,0,'2024-06-10','123456','1','IMPS','1','2024-06-01','1','1','1','1',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC33'),(34,94,0,'2024-06-21','2024-06-21','1',NULL,'draft',0,0,0,0,'2024-06-21','123456','1','Demand Draft','1','2024-06-21','1','1','','1',0,'','','','',1,'111','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC34'),(35,200,0,'2024-06-05','2024-06-20','2',NULL,'draft',0,0,0,0,'2024-06-22','2','2','IMPS','2','2024-06-22','2','2','3','2',0,'','','','2',1,'2','2','2','2','2',0,0,'',NULL,NULL,NULL,NULL,0,'2',0,NULL,'ABC35'),(36,200,0,'2024-06-21','2024-06-21','1',NULL,'draft',0,0,0,0,'2024-06-22','1','1','Demand Draft','1','2024-06-22','1','1','3','1234',0,'','','','',1,'123','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC36'),(37,164,0,'2024-06-13','2024-10-02','1',NULL,'draft',0,0,0,0,'2024-06-26','1234','123','NEFT','1','2024-06-26','1','1','2','1',0,'','','','',0,'','','','','',0,0,'',NULL,NULL,NULL,NULL,0,'',0,NULL,'ABC37');
/*!40000 ALTER TABLE `purchase_orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:14
