-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `service_id_generation`
--

DROP TABLE IF EXISTS `service_id_generation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_id_generation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `quantity` double NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `unit_type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '',
  `rate` double NOT NULL,
  `category` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `make` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `associated_with_part_no` varchar(45) DEFAULT NULL,
  `hsn_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `hsn_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `total` varchar(100) DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_activity_user` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title_UNIQUE` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_id_generation`
--

LOCK TABLES `service_id_generation` WRITE;
/*!40000 ALTER TABLE `service_id_generation` DISABLE KEYS */;
INSERT INTO `service_id_generation` VALUES (1,'SID001','ENGINEER AND TECHNICIAN',0,0,'Days',0,'3','','1','8544','5','Solar Water 365',NULL,'2021-06-23 15:56:07',1),(2,'SID002','SKILLED TECHNICIAN',0,0,'Days',0,'3','','2','8544','5','Solar Water 365',NULL,'2021-06-23 15:56:46',1),(3,'SID003','ENGINEER T&C',0,0,'Days',0,'3','','1','8544','5','Solar Water 365',NULL,'2021-06-23 15:57:24',1),(4,'Akalyaa','JI',0,0,'BOX',0,'4','','2','8544','5','Solar Water 365',NULL,'2024-06-01 09:53:46',1),(5,'Akalyaa11','1',0,0,'PCS',0,'4','','2','8521','18','DVR/NVR/XVR',NULL,'2024-06-12 05:53:21',1);
/*!40000 ALTER TABLE `service_id_generation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:14
