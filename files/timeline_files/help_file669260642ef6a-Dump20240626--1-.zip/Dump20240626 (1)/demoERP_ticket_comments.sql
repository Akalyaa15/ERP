-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ticket_comments`
--

DROP TABLE IF EXISTS `ticket_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_by` int NOT NULL,
  `created_at` datetime NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `ticket_id` int NOT NULL,
  `files` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_comments`
--

LOCK TABLES `ticket_comments` WRITE;
/*!40000 ALTER TABLE `ticket_comments` DISABLE KEYS */;
INSERT INTO `ticket_comments` VALUES (1,247,'2020-04-18 11:37:04','v',1,'a:0:{}',0),(2,355,'2020-04-18 13:48:13','Testing Gems Portal',2,'a:0:{}',0),(3,247,'2020-04-25 11:32:30','Currency Conversion',3,'a:0:{}',0),(4,247,'2020-04-25 11:36:17','Invoice Modification',4,'a:1:{i:0;a:2:{s:9:\"file_name\";s:104:\"ticket_file5ea3d359bd7f1-Gemicates_Technologies-Gemicates_Technologies_Private_Limited-Invoice-3--1-.pdf\";s:9:\"file_size\";s:6:\"109866\";}}',0),(5,963,'2020-04-25 16:24:10','Test the partner',5,'a:0:{}',0),(6,1,'2020-05-19 11:33:39','d',6,'a:0:{}',0),(7,1,'2020-05-19 11:34:23','dssds',7,'a:1:{i:0;a:2:{s:9:\"file_name\";s:71:\"ticket_file5ec376e7b1ac0-FRD_RPF_Grievance-Redressal-System_Ver-1.1.doc\";s:9:\"file_size\";s:6:\"310784\";}}',0),(8,15,'2020-05-19 12:39:51','z\\',8,'a:0:{}',0),(9,1,'2020-05-23 22:22:19','s',9,'a:0:{}',0),(10,1,'2020-09-21 10:32:53','as',10,'a:0:{}',0),(11,1,'2020-09-30 09:49:37','issues ',11,'a:0:{}',0),(12,1,'2020-09-30 09:50:26','ttttttt',11,'a:0:{}',0),(13,1,'2020-10-13 15:35:50','ggg',12,'a:1:{i:0;a:2:{s:9:\"file_name\";s:45:\"ticket_file5f85c9568650d-todays-meeting-.docx\";s:9:\"file_size\";s:4:\"9665\";}}',0),(14,1024,'2020-11-06 08:59:06','CALCULATING',13,'a:0:{}',0),(15,1,'2021-03-25 17:11:21','eagshf',14,'a:0:{}',0),(16,1,'2024-02-26 20:29:49','PC is notworking',15,'a:0:{}',0),(17,1,'2024-02-26 20:31:16','need manual for testing',15,'a:1:{i:0;a:2:{s:9:\"file_name\";s:44:\"ticket_file65dcf514a7ff7-Plenome_Standee.pdf\";s:9:\"file_size\";s:6:\"889980\";}}',0),(18,1,'2024-02-26 20:32:12','manual sent',15,'a:0:{}',0),(19,1,'2024-05-25 12:36:24','hi',16,'a:0:{}',0),(20,1,'2024-05-30 12:24:16','HI',17,'a:0:{}',0),(21,1,'2024-06-01 10:07:58','rtg',18,'a:0:{}',0),(22,1,'2024-06-01 12:42:26','hi',19,'a:0:{}',0),(23,1,'2024-06-06 06:10:15','NOt ixing',20,'a:1:{i:0;a:2:{s:9:\"file_name\";s:75:\"ticket_file666152c751f60-note_file6655c666f20ae-Gems-Manager-Gemicates.xlsx\";s:9:\"file_size\";s:5:\"14393\";}}',0),(24,1,'2024-06-06 06:16:49','hi',21,'a:0:{}',0),(25,1,'2024-06-08 09:01:00','Hai',22,'a:0:{}',0),(26,1,'2024-06-10 08:08:10','Testing',23,'a:1:{i:0;a:2:{s:9:\"file_name\";s:78:\"ticket_file6666b46ac8a0d-note_file6655c666f20ae-Gems-Manager-Gemicates-2-.xlsx\";s:9:\"file_size\";s:5:\"14393\";}}',0),(27,1,'2024-06-15 08:47:09','1',24,'a:0:{}',0),(28,1,'2024-06-22 06:16:12','123',25,'a:0:{}',0),(29,1,'2024-06-22 07:23:36','Testing',26,'a:0:{}',0),(30,1,'2024-06-26 05:22:26','123',27,'a:0:{}',0);
/*!40000 ALTER TABLE `ticket_comments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
