-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `project_id` int NOT NULL,
  `milestone_id` int NOT NULL DEFAULT '0',
  `assigned_to` int NOT NULL,
  `deadline` date DEFAULT NULL,
  `labels` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `points` tinyint NOT NULL DEFAULT '1',
  `status` enum('to_do','in_progress','done') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'to_do',
  `status_id` int NOT NULL,
  `start_date` date DEFAULT NULL,
  `collaborators` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `sort` int NOT NULL DEFAULT '0',
  `deleted` tinyint NOT NULL DEFAULT '0',
  `client_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` VALUES (1,'Project, Announcement modules to be verified','',1,0,506,'2020-04-30','',1,'to_do',3,'2020-04-18','',0,0,3),(2,'App Development','',2,0,0,'2020-04-30','assign',4,'to_do',1,'2020-04-25','',0,0,0),(3,'Training','',1,0,247,'2020-04-30','',1,'to_do',3,'2020-04-30','',0,0,3),(4,'Training On portal Modules','',5,0,247,'2020-05-09','',3,'to_do',1,'2020-05-08','',0,0,3),(5,'New project testing','regarding new meetiing-TESTING',0,0,621,'2020-05-09','',1,'to_do',3,'2020-05-08','',0,0,4),(6,'Software flow document creation','asd',7,0,506,'2020-05-10','',1,'to_do',3,'2020-05-09','621',0,0,8),(7,'Software flow document creation','asd',8,0,506,'2020-05-10','',1,'to_do',3,'2020-05-09','621',0,0,0),(8,'Software flow document creation','asd',9,0,506,'0000-00-00','',1,'to_do',3,'0000-00-00','621',0,0,0),(9,'testing','',9,0,1,NULL,'',3,'to_do',3,NULL,'',0,0,0),(10,'testing module','testing search',12,0,385,'2020-05-20','app testing',5,'to_do',2,'2020-05-18','385',0,0,10),(11,'task date checking-TESTING','date checking',13,0,621,'2020-05-22','',2,'to_do',3,'2020-05-20','',0,0,3),(12,'update to liver server','',9,0,1,'2020-06-16','',1,'to_do',3,'2020-06-15','966',0,0,2),(13,'testing erpdemo portal','',14,0,5,'2020-06-15','',1,'to_do',1,'2020-06-15','12',0,0,158),(14,'Bug clearance','',17,0,506,'2020-07-24','',1,'to_do',1,'2020-07-04','',0,0,8),(15,'Posting arivudaimai articles','',6,0,15,'2020-08-01','',1,'to_do',1,'2020-07-01','',0,0,3),(16,'ERP demo portal checking- with clearing the bugs in gemicates portal','To check & clear the bugs',0,0,621,NULL,'',1,'to_do',3,NULL,'',0,0,11),(17,'ERP demo portal checking- with clearing the bugs in gemicates portal','To chcek & clear the bUgs',6,0,621,'2020-07-11','',1,'to_do',3,'2020-07-06','',0,0,3),(18,'test pro','123',18,0,504,'2020-07-08','',1,'to_do',1,'2020-07-07','',0,0,0),(19,'task2','asd',18,0,504,'2020-07-09','',1,'to_do',1,'2020-07-08','',0,0,0),(20,'test not client ','',14,0,5,'2020-07-07','',1,'to_do',1,'2020-07-07','',0,0,0),(21,'Testing','',8,0,966,'2020-07-06','',1,'to_do',2,'2020-07-06','',0,0,0),(22,'Software flow document creation','asd',19,0,506,'0000-00-00','',1,'to_do',3,'0000-00-00','621',0,0,0),(23,'testing','',19,0,1,NULL,'',3,'to_do',3,NULL,'',0,0,0),(24,'update to liver server','',19,0,1,'2020-06-16','',1,'to_do',5,'2020-06-15','966',0,0,2),(25,'Software flow document creation','asd',20,0,506,'0000-00-00','',1,'to_do',3,'0000-00-00','621',0,0,0),(26,'testing','',20,0,1,'0000-00-00','',3,'to_do',3,'0000-00-00','',0,0,0),(27,'update to liver server','',20,0,1,'2020-08-07','',1,'to_do',2,'2020-08-07','966',0,0,7),(28,'Bug clearance','',21,0,506,'0000-00-00','',1,'to_do',1,'0000-00-00','',0,0,8),(29,'BUGS CHECKING IN DEMO PORTAL','',6,0,621,'2020-07-13','',1,'to_do',3,'2020-07-13','',0,0,3),(30,'Project, Announcement modules to be verified','',24,0,506,'2020-04-30','',1,'to_do',3,'2020-04-18','',0,0,3),(31,'Training','',24,0,247,'2020-04-30','',1,'to_do',3,'2020-04-30','',0,0,3),(32,'Bug clearance','',26,0,506,'2020-07-24','',1,'to_do',1,'2020-07-04','',0,0,5),(33,'clone task','',26,0,5,'2020-08-08','',1,'to_do',1,'2020-08-07','',0,0,5),(34,'sample task ','s',26,0,5,'2020-08-07','',1,'to_do',1,'2020-08-07','',0,0,5),(35,'Bug clearance','',27,0,506,'0000-00-00','',1,'to_do',1,'0000-00-00','',0,0,8),(36,'Verification ','',13,0,621,'2020-08-06','',2,'to_do',1,'2020-07-28','',0,0,3),(37,'Discussion ','',6,0,621,'2020-09-01','',1,'to_do',1,'2020-08-31','',0,0,3),(38,'Bug clearance','',29,0,506,'0000-00-00','',1,'to_do',1,'0000-00-00','',0,0,8),(39,'Bug clearance','',30,0,506,'0000-00-00','',1,'to_do',1,'0000-00-00','',0,0,8),(40,'bugs clear','',17,0,1,'2020-08-21','',1,'to_do',1,'2020-08-21','506',0,0,8),(41,'clear bugs in erp portal','',17,0,506,'2020-08-21','',1,'to_do',1,'2020-08-21','5',0,0,8),(42,'Bug clearance','',31,0,506,'0000-00-00','',1,'to_do',1,'0000-00-00','',0,0,170),(43,'bugs clear','',31,0,1,'0000-00-00','',1,'to_do',1,'0000-00-00','506',0,0,170),(44,'clear bugs in erp portal','',31,0,506,'0000-00-00','',1,'to_do',1,'0000-00-00','5',0,0,170),(45,'Bug clearance','',34,0,506,'2020-07-24','',1,'to_do',1,'2020-07-04','',0,0,8),(46,'bugs clear','',34,0,1,'2020-08-21','',1,'to_do',1,'2020-08-21','506',0,0,8),(47,'clear bugs in erp portal','',34,0,506,'2020-08-21','',1,'to_do',1,'2020-08-21','5',0,0,8),(48,'Team member Attendance Module Bug Testing','testing',39,0,1004,'2020-09-25','',1,'to_do',1,'2020-09-13','1,5,506,247',0,0,3),(49,'testing','testing',28,0,993,'2020-09-15','testing',4,'to_do',1,'2020-09-14','396',0,0,165),(50,'test pro','123',41,0,504,'0000-00-00','',1,'to_do',1,'0000-00-00','',0,0,3),(51,'task2','asd',41,0,504,'0000-00-00','',1,'to_do',1,'0000-00-00','',0,0,3),(52,'Testing ','Testing gems ',7,0,504,'2020-09-15','',4,'to_do',2,'2020-09-14','',0,0,8),(53,'Relay retrofit ','Feed Pump-01',42,2,1000,'2020-09-17','',2,'to_do',2,'2020-09-14','504',0,0,163),(54,'Test the Modules123','test',10,0,999,'2020-10-09','speed test',5,'to_do',1,'2020-09-29','504',0,0,9),(55,'title test task','today tests',34,0,625,'2020-10-09','',5,'to_do',2,'2020-09-29','506',0,0,8),(56,'T&C 11kv panel and Report Generation','TD',46,0,1000,'2020-10-12','',2,'to_do',1,'2020-10-12','1008',0,0,12),(57,'SOP Purchase Order on Vendors','The procedures for purchase orders',42,2,1000,'2020-10-31','',5,'to_do',2,'2020-10-13','504',0,0,163),(58,'Testing','',50,0,1022,'2020-10-20','',1,'to_do',1,'2020-10-20','',0,0,8),(59,'audit','CHECKING',0,0,1024,'2020-11-06','CALCULATING',1,'to_do',3,'2020-11-06','',0,0,32),(60,'33kv panel eractiuon','',46,0,1,'2020-11-14','',1,'to_do',1,'2020-11-07','5,247,1008',0,0,12),(61,'To guide the Work Flow to the New Joinee ','To guide the Work Flow to the New Joinee\n',52,0,506,'2020-11-28','',1,'to_do',1,'2020-11-28','',0,0,191),(62,'to learn gems manager','to understand the working flow',54,0,1032,'2021-03-26','',2,'to_do',1,'2021-03-25','',0,0,3),(63,'bug clearance project','bug clearance project',1,0,506,'2021-05-28','',2,'to_do',1,'2021-05-19','',0,0,3),(64,'bug clearance project','clearance of bug',1,0,247,'2021-05-28','',1,'to_do',1,'2021-05-19','',0,0,3),(65,'Web App testing','manual testing',51,0,1,'2024-02-28','',2,'to_do',1,'2024-02-26','985',0,0,8),(66,'testing','ghgh',0,0,1,'2024-05-25','',1,'to_do',1,'2024-05-25','',0,0,164),(67,'AKALYAA','PROJECT ASSOCIATE',0,0,1,'2024-05-26','',1,'to_do',1,'2024-05-25','',0,0,176),(68,'Akalyaa','project debug',10,0,504,'2024-05-27','speed test',1,'to_do',1,'2024-05-27','',0,0,9),(69,'Testing','hi',42,2,504,'2024-06-01','',1,'to_do',2,'2024-05-30','1000',0,0,163),(70,'Testing','JI',0,0,1,'2024-06-28','',1,'to_do',1,'2024-06-08','',0,0,160),(71,'Testing','hAI',0,0,1,'2024-06-04','',3,'to_do',1,'2024-06-04','',0,0,10),(72,'Testing','hai',58,1,1,NULL,'1',1,'to_do',1,'0000-00-00','hai',0,0,164),(73,'TESTING','HAI',58,1,1,NULL,'gh',1,'to_do',1,'0000-00-00','hai',0,0,164),(74,'TESTING','HAI',58,1,1,NULL,'gh',1,'to_do',1,'0000-00-00','hai',0,0,164),(75,'Testing','hai',25,0,985,'2024-06-19','',1,'to_do',1,'2024-06-05','',0,0,10),(76,'Testing','hi',42,2,1000,'2024-06-08','',2,'to_do',3,'2024-06-08','504',0,0,163),(77,'Testing','hi',11,0,621,'2024-06-19','',4,'to_do',1,'2024-06-10','',0,0,10),(78,'Testing','1',15,0,247,'2024-06-20','',2,'to_do',1,'2024-06-14','',0,0,163),(79,'Testing','Testing',10,0,999,'2024-06-27','speed test',1,'to_do',3,'2024-06-21','1',0,0,9),(80,'Testing','12345',19,0,621,'2024-07-05','',1,'to_do',2,'2024-06-21','506',0,0,163),(81,'Testing','testing',15,0,247,'2024-07-05','',3,'to_do',5,'2024-06-27','',0,0,163),(82,'IITM GROUP','0',10,0,999,'2024-06-26','speed test',1,'to_do',3,'2024-06-21','957',0,0,9),(83,'Testing','3',42,2,504,'2024-06-28','',2,'to_do',2,'2024-06-21','396',0,0,163),(84,'12345','1',10,0,999,'2024-06-26','speed test',1,'to_do',5,'2024-06-12','1',0,0,9),(85,'Testing','Testing',35,0,626,'2024-06-28','',1,'to_do',2,'2024-06-05','624',0,0,173),(86,'Testing','Testing',10,0,999,'2024-06-27','speed test',3,'to_do',3,'2024-06-25','1',0,0,9);
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:16
