-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `project_time`
--

DROP TABLE IF EXISTS `project_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_time` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `user_id` int NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `status` enum('open','logged','approved') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'logged',
  `note` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `task_id` int NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_time`
--

LOCK TABLES `project_time` WRITE;
/*!40000 ALTER TABLE `project_time` DISABLE KEYS */;
INSERT INTO `project_time` VALUES (1,1,247,'2020-05-30 10:00:00','2020-05-30 11:00:00','logged','',1,0),(2,3,1,'2020-05-02 15:22:05','2020-05-02 15:22:22','logged','',0,0),(3,3,1,'2020-05-02 16:54:29','2020-05-02 16:59:59','logged','',0,0),(4,5,247,'2020-05-08 18:29:04','2020-05-08 19:38:16','logged','Done on Training',4,0),(5,7,621,'2020-05-09 15:50:00','2020-05-09 15:50:00','logged','Testing',6,0),(6,7,506,'2020-05-09 15:55:51','2020-05-09 15:56:05','logged','Finished',0,0),(7,7,247,'2020-05-09 15:56:30','2020-05-09 15:57:06','logged','',6,0),(8,7,1,'2020-05-12 16:29:26','2020-05-12 16:30:01','logged','job done',6,0),(9,10,1,'2020-05-12 16:41:39','2020-05-12 16:42:32','logged','job done for testing',0,0),(10,3,1,'2020-05-12 17:13:15','2020-05-12 17:13:49','logged','job done',0,0),(11,2,1,'2020-05-12 18:44:54','2020-05-12 18:45:51','logged','Work done',2,0),(12,13,621,'2020-05-19 14:27:46','2020-05-19 14:31:20','logged','dates of projects creation  and start date and end date is not working properly',0,0),(13,14,1,'2020-06-15 13:46:50','2020-06-19 21:28:07','logged','finished',13,0),(14,6,621,'2020-07-06 15:58:00','2020-07-06 16:58:00','logged','to check the bugs',17,0),(15,14,5,'2020-07-07 14:08:41','2020-07-07 14:10:01','logged','test',13,0),(16,17,5,'2020-07-07 14:10:27','2020-07-07 14:11:15','logged','b',14,0),(17,6,621,'2020-07-07 15:07:54','2020-07-10 14:26:22','logged','chceking bugs\n',17,0),(18,6,621,'2020-07-10 14:51:00','2020-07-10 09:50:00','logged','checking upto partner only',17,0),(19,6,621,'2020-07-11 12:12:26','2020-07-11 13:50:30','logged','checking bugs',17,0),(20,6,621,'2020-07-11 13:50:40','2020-07-11 18:53:29','logged','Checking bugs',17,0),(21,26,506,'2020-08-13 17:07:51','2020-08-15 18:16:10','logged','done\n',33,0),(22,17,1,'2020-08-14 19:06:07','2020-08-14 19:09:17','logged','Bug clearance with description',14,0),(23,6,247,'2020-08-15 14:07:07','2020-08-15 14:07:44','logged','',0,0),(24,5,247,'2020-08-15 14:07:52','2020-08-15 14:07:56','logged','',0,0),(25,17,1,'2020-09-04 12:00:41','2020-09-04 12:00:46','logged','',0,0),(26,39,1004,'2020-09-13 12:48:29','2020-09-13 13:01:36','logged','test',48,0),(27,40,504,'2020-09-14 21:19:29','2020-09-14 21:22:37','logged','test',0,0),(28,41,504,'2020-09-14 21:24:06','2020-09-14 21:25:09','logged','test',0,0),(29,41,1,'2020-09-14 23:54:27','2020-09-15 00:55:08','logged','',50,0),(30,17,1,'2020-09-15 13:58:19','2020-09-16 00:29:30','logged','',0,0),(31,6,12,'2020-09-19 17:21:18',NULL,'open',NULL,0,0),(32,30,1,'2020-09-20 17:25:19','2020-09-24 22:47:22','logged','',39,0),(33,17,1,'2020-09-26 08:24:34','2020-09-29 13:40:23','logged','',14,0),(34,17,1,'2020-10-03 19:38:42','2020-10-05 22:59:26','logged','',14,0),(35,46,1,'2020-10-11 00:15:07','2020-10-11 00:15:59','logged','job in progress',56,0),(36,17,1008,'2020-10-12 22:18:40','2020-10-12 22:19:22','logged','test',14,0),(37,42,1000,'2020-10-13 15:18:15','2020-10-13 15:18:33','logged','',53,0),(38,39,247,'2020-10-24 15:27:40','2020-10-24 15:28:15','logged','explaining ',48,0),(39,52,1028,'2020-11-28 11:30:50',NULL,'open',NULL,0,0),(40,6,621,'2020-12-19 15:53:54','2020-12-25 14:50:20','logged','',29,0),(41,54,1032,'2021-03-25 22:32:34','2021-03-26 19:40:55','logged','To work',62,0),(42,54,1032,'2021-03-26 19:42:36',NULL,'open',NULL,0,0),(43,51,1,'2024-02-27 01:20:53','2024-02-27 01:24:01','logged','Testing done',65,0),(44,58,1,'2024-06-04 15:37:57','2024-06-04 17:56:01','logged','Testing',72,0);
/*!40000 ALTER TABLE `project_time` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:16
