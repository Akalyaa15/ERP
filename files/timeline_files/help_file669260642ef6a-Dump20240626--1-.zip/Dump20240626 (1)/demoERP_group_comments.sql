-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `group_comments`
--

DROP TABLE IF EXISTS `group_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_by` int NOT NULL,
  `created_at` datetime NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `project_id` int NOT NULL DEFAULT '0',
  `comment_id` int NOT NULL DEFAULT '0',
  `task_id` int NOT NULL DEFAULT '0',
  `file_id` int NOT NULL DEFAULT '0',
  `customer_feedback_id` int NOT NULL DEFAULT '0',
  `files` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `group_members` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `read_members` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_comments`
--

LOCK TABLES `group_comments` WRITE;
/*!40000 ALTER TABLE `group_comments` DISABLE KEYS */;
INSERT INTO `group_comments` VALUES (1,5,'2020-08-07 10:42:03','HAI gems ',1,0,0,0,0,'a:0:{}',0,'1,12,506',',506,1,12'),(2,247,'2020-08-21 13:01:23','Testing\n',1,0,0,0,0,'a:0:{}',0,'1,5,12,506,504',',1,504,5,12,506'),(3,504,'2020-08-21 13:01:42','test\n',1,0,0,0,0,'a:0:{}',0,'1,5,12,506,247',',247,1,5,12,506'),(4,5,'2020-08-21 13:01:50','hai i am arun',1,2,0,0,0,'a:0:{}',0,'1,12,506,247,504',',247,1,12,504,506'),(5,1,'2020-08-21 13:03:00','bell notifications',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',5,247,12,504,506'),(6,12,'2020-08-29 07:45:14','sa',1,0,0,0,0,'a:0:{}',0,'1,5,506,247,504',',1,504,5,247,506'),(7,1,'2020-08-29 07:45:23','zx',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(8,12,'2020-08-29 07:45:38','sas',1,0,0,0,0,'a:0:{}',0,'1,5,506,247,504',',1,504,5,247,506'),(9,1,'2020-08-29 07:46:04','xc',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(10,12,'2020-08-29 07:52:57','sas',1,0,0,0,0,'a:0:{}',0,'1,5,506,247,504',',1,504,5,247,506'),(11,1,'2020-08-31 04:26:07','sasasa',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(12,1,'2020-08-31 04:26:28','sddsdf',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(13,1,'2020-08-31 04:27:03','ddd',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(14,1,'2020-08-31 04:27:25','dsfddsf',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(15,1,'2020-08-31 04:28:04','fxfx',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(16,1,'2020-08-31 04:47:42','sa',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(17,1,'2020-08-31 04:48:20','asd',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(18,1,'2020-08-31 07:21:29','ffdggf',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(19,1,'2020-08-31 07:21:55','ffd',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(20,1,'2020-08-31 07:22:36','cvx',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(21,1,'2020-08-31 07:26:13','fg',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(22,1,'2020-08-31 07:35:50','df',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(23,1,'2020-08-31 07:51:25','fdf',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(24,1,'2020-08-31 07:54:11','df d',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(25,12,'2020-08-31 07:56:29','fdsdf',1,0,0,0,0,'a:0:{}',0,'1,5,506,247,504',',1,504,5,247,506'),(26,1,'2020-08-31 07:57:35','f',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(27,1,'2020-08-31 07:58:53','ssad',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(28,1,'2020-08-31 07:59:22','fdsd',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(29,1,'2020-08-31 08:00:18','Sjsj',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(30,1,'2020-08-31 08:00:25','Sjsj',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(31,1,'2020-08-31 08:04:08','fdf',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(32,1,'2020-08-31 08:05:12','ss',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(33,1,'2020-08-31 08:05:34','bb',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(34,1,'2020-08-31 08:06:34','dzf',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(35,1,'2020-08-31 08:23:41','th',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(36,1,'2020-09-01 06:54:53','Helllo\n',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(37,1,'2020-09-01 06:55:08','hiiii',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504',',12,504,5,247,506'),(38,504,'2020-09-03 17:23:35','1) Remove UAN, PAN, etc from pay slip, and secondly bank details should be showed XXXXXX except last 4 digits when it is converted to pdf. \n2) And I am not able to add or modify paid holidays when I am generating pay slip it shows the value must be 0 or below .\n3) Try to implement hierarchy for leave module as discussed. \n',1,0,0,0,0,'a:0:{}',0,'1,5,12,506,247',',1,12,5,247,506'),(39,504,'2020-09-03 17:32:26','4) And bold your left side content in pay slip, =when I convert it to pdf there is no difference I can see it from the document.\n5) when the name is longer it should not come to next line, try to reduce the size or adjust the content. \n6) Remove MICR code from bank details. \n7) kindly use following order \nEmployee name: - \nDesignation: - \nDepartment: - \nEmployee ID: - \nStatus :- \nRemove all the rest from that column. \n\n',1,0,0,0,0,'a:0:{}',0,'1,5,12,506,247',',1,12,5,247,506'),(40,504,'2020-09-03 17:37:02','8) From where we are getting annual leave available and taken, there is no details, kindly clarify \n9) Add below note in footer of payslip, once pdf generated this line should be present there.\n\nNote : - This is a system generated pay slip \n\n',1,0,0,0,0,'a:0:{}',0,'1,5,12,506,247',',1,12,5,247,506'),(41,504,'2020-09-03 17:38:50','10) Add comment box for LOP and other deductions when we are making it for our employees. \n\n',1,0,0,0,0,'a:0:{}',0,'1,5,12,506,247',',1,12,5,247,506'),(42,504,'2020-09-03 17:47:57','11) Log in page background not able to modify. \n12) Team members should only able to see their team members details and contact from the module of team members, they should not view admin details in the list. \n13) In timeline only admin can upload the pictures and other informations, other than for team members this option must be removed. \n14) In add event there no option for AM & PM , kindly include that as well. \n15) if possible link all the meetings with Microsoft teams or give a reminder pop up. \n16) And make sure when we are selecting the country the address related to all the documents will change. \n17) And may be change the name from Delivery Challan to Delivery Note.\n ',1,0,0,0,0,'a:0:{}',0,'1,5,12,506,247,15',',1,12,5,247,506'),(43,504,'2020-09-10 16:11:36','Test Tamilnadu ',3,0,0,0,0,'a:1:{i:0;a:2:{s:9:\"file_name\";s:73:\"group_comment_file5f5a503872888-peace-and-love-peace-31691930-500-375.jpg\";s:9:\"file_size\";s:5:\"78974\";}}',0,'999,957',',999,957'),(44,504,'2020-09-10 16:16:31','1) there is no notification indication coming once received the message from group chat. \\\n2) upload leave module \n3) Monisha start purging data entries in gems manager. dead line must be assigned maximum 28th September-2020\n\n',1,0,0,0,0,'a:0:{}',0,'1,5,12,506,247,15',',5,12,247,1,506'),(45,12,'2020-09-11 14:18:00','gfgfhf',3,0,0,0,0,'a:0:{}',0,'999,957',',999,957'),(46,12,'2020-09-11 14:18:31','h',3,0,0,0,0,'a:0:{}',0,'999,957',',999,957'),(47,12,'2020-09-11 14:18:39','sasa',1,0,0,0,0,'a:0:{}',0,'1,5,506,247,504,15',',504,247,5,1,506'),(48,504,'2020-09-11 17:31:57','1) Team there is an upload option in time line for admin but share or post option is not available. \n2) Arun IT kindly update the pay slip module asap. \n3) conform how we are making the leave calculation for the employees, though we are giving total number of holidays, but how we will differentiate the leaves for pending days available. \n\nIf above all the points are available and cleared proceed to upload modules in Live stream. \n',1,0,0,0,0,'a:0:{}',0,'1,5,12,506,247,15',',247,5,12,1,506'),(49,504,'2020-09-11 17:35:00','4) Team as discussed earlier kindly remove line manager mandatory for super admins ( VR, Arun, Santhoush,saravanan)',1,0,0,0,0,'a:0:{}',0,'1,5,12,506,247,15',',247,5,12,1,506'),(50,504,'2020-09-11 17:36:05','test ',3,0,0,0,0,'a:0:{}',0,'999,957',',999,957'),(51,504,'2020-09-11 17:38:58','5) as discussed there is no pop up coming when we sent group messages, \\pop up must be needed, otherwise employees some times will miss shared messages. \n',1,0,0,0,0,'a:0:{}',0,'1,5,12,506,247,15',',247,5,12,1,506'),(52,504,'2020-09-11 17:45:29','6) Voucher preview is not available once updated, do check and update. \n7) ',1,0,0,0,0,'a:0:{}',0,'1,5,12,506,247,15',',247,5,12,1,506'),(53,12,'2020-09-12 06:17:07','sdfdd',1,0,0,0,0,'a:0:{}',0,'1,5,506,247,504,15',',247,1,504,5,506'),(54,12,'2020-09-12 07:16:58','Hi',1,0,0,0,0,'a:0:{}',0,'1,5,506,247,504,15',',1,247,504,5,506'),(55,12,'2020-09-12 07:19:45','saa',1,0,0,0,0,'a:0:{}',0,'1,5,506,247,504,15',',1,247,504,5,506'),(56,1,'2020-09-14 18:40:26','test 1 2 3',2,0,0,0,0,'a:0:{}',0,'504,957,396,15,247,506',',504,247,506'),(57,1,'2020-09-14 18:41:12','zxc',2,0,0,0,0,'a:0:{}',0,'504,957,396,15,247,506',',504,247,506'),(58,5,'2020-09-19 15:42:21','Testing Erp',1,0,0,0,0,'a:0:{}',0,'1,12,506,247,504,15',',1,504,247,506'),(59,1,'2020-09-19 15:42:44','ase',1,0,0,0,0,'a:0:{}',0,'5,12,506,247,504,15',',5,504,247,506'),(60,504,'2020-09-19 20:15:29','test-01',1,0,0,0,0,'a:0:{}',0,'1,5,12,506,247,15',',247,1,506,5');
/*!40000 ALTER TABLE `group_comments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
