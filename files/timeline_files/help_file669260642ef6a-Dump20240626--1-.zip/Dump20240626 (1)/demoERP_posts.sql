-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_by` int NOT NULL,
  `created_at` datetime NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `post_id` int NOT NULL,
  `share_with` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `files` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (1,396,'2020-04-18 19:18:59','AADC',0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:43:\"timeline_post_file5e9b054bb0bca-Capture.JPG\";s:9:\"file_size\";s:5:\"28358\";}}',0),(2,385,'2020-04-24 13:42:16','test',0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:44:\"timeline_post_file5ea29f608ef5d-Wildlife.mp4\";s:9:\"file_size\";s:8:\"26246026\";}}',0),(3,12,'2020-08-14 06:32:29','test\n',0,'','a:0:{}',0),(4,12,'2020-08-14 06:34:04','test',0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:49:\"timeline_post_file5f36305c9d062-videoplayback.mp4\";s:9:\"file_size\";s:8:\"10976705\";}}',0),(5,999,'2020-09-10 16:17:48','test file ',0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:73:\"timeline_post_file5f5a51aceb55e-peace-and-love-peace-31691930-500-375.jpg\";s:9:\"file_size\";s:5:\"78974\";}}',1),(6,5,'2020-09-12 07:26:41','Testing purpose',0,'','a:0:{}',0),(7,5,'2020-09-12 07:26:57','Testing purpose REPLY',6,'','a:0:{}',0),(8,504,'2020-09-14 18:56:17','test ',0,'','a:0:{}',1),(9,504,'2020-09-14 18:56:59','timing test for the relays in 11.5 kv switchgear \n',0,'','a:0:{}',1),(10,504,'2020-09-18 15:05:53','njnjnniiiuggtdrdeaqwwsdgiop\n',0,'','a:0:{}',1),(11,504,'2020-09-18 15:06:16','tertyiop[]\n',0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:73:\"timeline_post_file5f64cce8dbd3a-peace-and-love-peace-31691930-500-375.jpg\";s:9:\"file_size\";s:5:\"78974\";}}',0),(12,506,'2020-10-24 07:51:47','Gemslab New Project',0,'','a:1:{i:0;a:2:{s:9:\"file_name\";b:0;s:9:\"file_size\";s:6:\"781691\";}}',0),(13,621,'2021-04-01 09:22:48','GEMLABs associated with K.S.R College of Engineering,in department of CSE and conducting a webinar on\"creating a cloud server with RASPBERRY PI\" on 11th-July 2020.\n\n',0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:40:\"timeline_post_file606590e808171-post.JPG\";s:9:\"file_size\";s:5:\"62234\";}}',0),(14,1035,'2021-04-02 10:13:26','GEMLABs associated with K.S.R College of Engineering,in department of CSE and conducting a webinar on\"creating a cloud server with RASPBERRY PI\" on 11th-July 2020. ',0,'','a:0:{}',1),(15,1,'2024-05-28 06:49:47','hi',0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:46:\"timeline_post_file66557e8ba1be5-Untitled-2.odt\";s:9:\"file_size\";s:5:\"26632\";}}',0),(16,1,'2024-05-28 06:50:03','hi',0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:71:\"timeline_post_file66557e9bc6983-Screenshot-from-2024-05-27-16-07-48.png\";s:9:\"file_size\";s:6:\"276038\";}}',0),(17,1,'2024-06-01 09:32:17','hi',0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:71:\"timeline_post_file665aeaa1e827f-Screenshot-from-2024-05-27-12-36-48.png\";s:9:\"file_size\";s:6:\"164129\";}}',0),(18,1,'2024-06-08 11:29:49','Testing',0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:82:\"timeline_post_file666440ad770d3-note_file6655c666f20ae-Gems-Manager-Gemicates.xlsx\";s:9:\"file_size\";s:5:\"14393\";}}',0),(19,1,'2024-06-10 05:40:59','testing',0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:71:\"timeline_post_file666691eb4f685-Screenshot-from-2024-06-05-16-31-59.png\";s:9:\"file_size\";s:5:\"10546\";}}',0),(20,1,'2024-06-21 05:58:48','Testing',0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:58:\"timeline_post_file66751698655db-Adhoc-Form_Application.pdf\";s:9:\"file_size\";s:6:\"463606\";}}',0),(21,1,'2024-06-22 11:42:48','Testing',0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:63:\"timeline_post_file6676b8b869df1-LAMP-Installation-Procedure.txt\";s:9:\"file_size\";s:4:\"5128\";}}',0),(22,1,'2024-06-25 12:18:46','Testing',0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:63:\"timeline_post_file667ab5a680784-LAMP-Installation-Procedure.txt\";s:9:\"file_size\";s:4:\"5128\";}}',0),(23,1,'2024-06-25 12:19:19','TEsting',0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:95:\"timeline_post_file667ab5c76c6ba-Screenshot-2024-05-15-at-11-05-09-Flowchat-1--Thanjavur.pdf.png\";s:9:\"file_size\";s:6:\"284511\";}}',0);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:14
