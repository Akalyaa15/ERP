-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `general_files`
--

DROP TABLE IF EXISTS `general_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `general_files` (
  `id` int NOT NULL AUTO_INCREMENT,
  `file_name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `file_size` double NOT NULL,
  `created_at` datetime NOT NULL,
  `client_id` int NOT NULL DEFAULT '0',
  `user_id` int NOT NULL DEFAULT '0',
  `uploaded_by` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `vendor_id` int NOT NULL DEFAULT '0',
  `company_id` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `general_files`
--

LOCK TABLES `general_files` WRITE;
/*!40000 ALTER TABLE `general_files` DISABLE KEYS */;
INSERT INTO `general_files` VALUES (1,'_file5e97e3a2aca56-training3.jpg','',42183,'2020-04-16 10:18:34',2861,0,12,1,0,'0'),(2,'_file5e9ab02008aca-IMG-20200417-WA0021.jpg','',259906,'2020-04-18 13:15:36',3,0,506,0,0,'0'),(3,'_file5eb8fcac6592c-_Untitled.pdf','',109426,'2020-05-11 12:50:12',9,0,621,0,0,'0'),(4,'_file5eb9240774ce1-Gems-Manager-Gemicates--1-.xlsx','',14777,'2020-05-11 15:38:07',0,621,621,1,0,'0'),(5,'_file5eb9240775b2a-Gems-Manager-Gemicates.xlsx','',13654,'2020-05-11 15:38:07',0,621,621,1,0,'0'),(6,'_file5eb9240776aa6-ScreenRecorderProject1.mkv','',782,'2020-05-11 15:38:07',0,621,621,1,0,'0'),(7,'_file5eb92407776ff-ScreenRecorderProject2.mkv','',782,'2020-05-11 15:38:07',0,621,621,1,0,'0'),(8,'_file5eb9240777bd1-Work-Report.-daily-updation-R.Bargavi.xlsx','',78734,'2020-05-11 15:38:07',0,621,621,1,0,'0'),(9,'_file5eb924077858b-Work-Report.-daily-updation.xlsx','',77933,'2020-05-11 15:38:07',0,621,621,0,0,'0'),(10,'_file5eb9240778a9b-Work-Report.rgh.xlsx','',73278,'2020-05-11 15:38:07',0,621,621,0,0,'0'),(11,'_file5eb92407793db-Work-Report.xlsx.xlsx','',73186,'2020-05-11 15:38:07',0,621,621,0,0,'0'),(12,'_file5eb92548b5708-ScreenRecorderProject1.mkv','',782,'2020-05-11 15:43:28',0,621,621,0,0,'0'),(13,'_file5eb92548b616a-ScreenRecorderProject2.mkv','',782,'2020-05-11 15:43:28',0,621,621,0,0,'0'),(14,'_file5eb9380bec512-GEMICATES-PORTAL-USER-ID.docx','',266861,'2020-05-11 17:03:31',0,621,621,0,0,'0'),(15,'_file5eb9380bed29c-Gemicates.-energy-division.pptx','',4030665,'2020-05-11 17:03:31',0,621,621,0,0,'0'),(16,'_file5eb9380beeb2a-New-suggestion-meeting.docx','',11714,'2020-05-11 17:03:31',0,621,621,0,0,'0'),(17,'_file5eb9380bef9c0-partner-client.pptx','',921313,'2020-05-11 17:03:31',0,621,621,0,0,'0'),(18,'_file5eba4ad1b7e88-0001014610008213579_04022019_04222019.PDF','PO',83242,'2020-05-12 12:35:53',1,0,247,0,0,'0'),(19,'_file5eba67b02436e-10002.rar','',894277,'2020-05-12 14:39:04',0,621,621,0,0,'0'),(20,'_file5eba67b026ac6-ENERGY-DIVISION-WEBSITE.zip','',10599168,'2020-05-12 14:39:04',0,621,621,0,0,'0'),(21,'_file5eba67b033ffb-Gemicates-Attedence-folder.zip','',5289227,'2020-05-12 14:39:04',0,621,621,0,0,'0'),(22,'_file5eba67b03b7b6-Misc-folder.zip','',798441798,'2020-05-12 14:39:04',0,621,621,0,0,'0'),(23,'_file5eba6c748db25-GEMICATES-PORTAL-USER-ID.docx','',736204,'2020-05-12 14:59:24',0,621,621,0,0,'0'),(24,'_file5eba6c748e8b4-Gemicates.-energy-division.pptx','',4030665,'2020-05-12 14:59:24',0,621,621,0,0,'0'),(25,'_file5eba6c748fe89-New-suggestion-meeting.docx','',11654,'2020-05-12 14:59:24',0,621,621,0,0,'0'),(26,'_file5eba6c7490cc0-partner-client.pptx','',921313,'2020-05-12 14:59:24',0,621,621,0,0,'0'),(27,'_file5ebe3e8f7917b-GCT14180467.pdf','PI',337124,'2020-05-15 12:32:39',13,0,247,0,0,'0'),(28,'_file5ebe5cbeb2e82-GCT14180467.pdf','PO',337124,'2020-05-15 14:41:26',0,0,247,0,216,'0'),(29,'_file5f745586cd0cd-Meet-25920.docx','',11251,'2020-09-30 09:53:10',171,0,1,0,0,'0'),(30,'_file5f745a66623b1-Meet-25920.docx','',11251,'2020-09-30 10:13:58',0,0,1,0,226,'0'),(31,'_file5f75b42050052-todays-meeting-.docx','',9665,'2020-10-01 10:49:04',0,0,1,0,227,'0'),(32,'_file5fd34c23b91ca-ajs-data-binding.png','j',320996,'2020-12-11 10:38:27',0,0,1,1,0,'CR002'),(33,'_file6066bca0ee607-Delivery_Note-43.pdf','',94321,'2021-04-02 06:41:36',0,0,621,0,231,'0');
/*!40000 ALTER TABLE `general_files` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:16
