-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `income`
--

DROP TABLE IF EXISTS `income`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `income` (
  `id` int NOT NULL AUTO_INCREMENT,
  `income_date` date NOT NULL,
  `category_id` int NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `amount` double NOT NULL,
  `files` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `project_id` int DEFAULT '0',
  `user_id` int NOT NULL DEFAULT '0',
  `tax_id` int NOT NULL DEFAULT '0',
  `tax_id2` int NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `sgst_tax` double NOT NULL DEFAULT '0',
  `igst_tax` double NOT NULL DEFAULT '0',
  `cgst_tax` double NOT NULL DEFAULT '0',
  `total` double NOT NULL,
  `voucher_no` int NOT NULL DEFAULT '0',
  `with_gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `gst_number` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `with_inclusive_tax` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `hsn_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `gst` double NOT NULL,
  `hsn_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `member_type` varchar(45) CHARACTER SET big5 COLLATE big5_chinese_ci DEFAULT NULL,
  `phone` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `company` int DEFAULT '0',
  `vendor_company` int DEFAULT '0',
  `last_activity` datetime DEFAULT NULL,
  `last_activity_user` int DEFAULT NULL,
  `payment_status` int DEFAULT '0',
  `currency_symbol` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `currency` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `income`
--

LOCK TABLES `income` WRITE;
/*!40000 ALTER TABLE `income` DISABLE KEYS */;
INSERT INTO `income` VALUES (1,'2020-04-17',6,'labs documents &site work',15000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:121:\"income_file5e9a92393b961-Pelikan_Office_Automation_Pvt._Ltd.-Gemicates_Technologies_Private_Limited-Purchase_Orders-1.pdf\";s:9:\"file_size\";s:6:\"101835\";}}','wqd',0,4,0,0,0,0,0,0,15000,0,'no','0','no','-',0,'-','tm','0',0,0,NULL,NULL,0,'',''),(2,'2020-04-17',6,'labs documents &site work',15000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:121:\"income_file5e9d5b8ae7949-Pelikan_Office_Automation_Pvt._Ltd.-Gemicates_Technologies_Private_Limited-Purchase_Orders-1.pdf\";s:9:\"file_size\";s:6:\"101835\";}}','s',0,0,0,0,0,0,0,0,15000,6,'no','0','no','-',0,'-','om','0',0,0,NULL,NULL,0,'',''),(3,'2020-05-11',7,'Payment for installation',28389.830508475,'a:1:{i:0;a:2:{s:9:\"file_name\";s:105:\"income_file5eb947cee76b3-Akasaka_Electronics_Ltd-Gemicates_Technologies_Private_Limited-Work_Orders-5.pdf\";s:9:\"file_size\";s:5:\"98175\";}}','Danway Project',10,959,0,0,0,0,5110.1694915254,0,33500,13,'yes','32AAFRS184A1T0','yes','9987',18,'Services','clients','0',1,0,NULL,NULL,0,'',''),(4,'2020-06-11',1,'text',507.62711864407,'a:1:{i:0;a:2:{s:9:\"file_name\";b:0;s:9:\"file_size\";s:6:\"159770\";}}','text',1,5,0,0,0,45.686440677966,0,45.686440677966,599,0,'yes','33','yes','8504',18,'Power Adapter','tm','0',0,0,NULL,NULL,0,'',''),(5,'2020-04-17',14,'Office renovation- Testing',150000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:93:\"income_file5f6b496c66d8e-Danway-Gemicates_Technologies_Private_Limited-Proforma_Invoice-1.pdf\";s:9:\"file_size\";s:6:\"112325\";}}','a',0,1,0,0,0,0,0,0,150000,8,'no','0','no','-',0,'-','tm','0',0,0,'2020-09-23 13:11:08',247,0,'',''),(6,'2020-04-17',1,'labs documents &site work',15000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:45:\"income_file5f75c99f63c8f-todays-meeting-.docx\";s:9:\"file_size\";s:4:\"9665\";}}','Test the Modules',2,1,0,0,0,0,0,0,15000,6,'no','0','no','-',0,'-','tm','0',0,0,'2020-10-01 12:20:47',1,0,'',''),(7,'2020-09-25',4,'expe',3000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:40:\"income_file5f75c9fc38d4b-Meet-25920.docx\";s:9:\"file_size\";s:5:\"11251\";}}','Event1',2,1,0,0,0,0,0,0,3000,42,'no','0','no','-',0,'-','tm','0',0,0,'2020-10-01 12:22:20',1,0,'',''),(8,'2020-04-17',10,'Advance for materials supply ',10000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:45:\"income_file5f75cf670b565-todays-meeting-.docx\";s:9:\"file_size\";s:4:\"9665\";}}','Test1',0,1,0,0,0,0,0,0,10000,2,'no','0','no','-',0,'-','tm','0',0,0,'2020-10-01 12:45:27',1,0,'','');
/*!40000 ALTER TABLE `income` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:14
