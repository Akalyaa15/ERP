-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clients_po_list`
--

DROP TABLE IF EXISTS `clients_po_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients_po_list` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_date` date DEFAULT NULL,
  `invoice_no` varchar(100) DEFAULT NULL,
  `vendor_id` int DEFAULT NULL,
  `files` mediumtext NOT NULL,
  `description` text,
  `amount` double NOT NULL,
  `cgst_tax` double NOT NULL,
  `sgst_tax` double NOT NULL,
  `igst_tax` double NOT NULL,
  `cheque_no` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `total` double NOT NULL,
  `net_total` double DEFAULT NULL,
  `payment_method_id` int NOT NULL,
  `amount_paid` double NOT NULL,
  `due` double DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `state_tax` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `status` enum('not_paid','paid','partially_paid') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'not_paid',
  `status_id` int NOT NULL,
  `utr_no` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `gstin_number_first_two_digits` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `gst_number` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `purchase_order_id` int NOT NULL,
  `vendor_status` enum('vendor_invoice_created','not_paid') NOT NULL DEFAULT 'vendor_invoice_created',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients_po_list`
--

LOCK TABLES `clients_po_list` WRITE;
/*!40000 ALTER TABLE `clients_po_list` DISABLE KEYS */;
INSERT INTO `clients_po_list` VALUES (1,'2020-06-15','po123',9,'a:1:{i:0;a:2:{s:9:\"file_name\";s:46:\"client_po_file5ee729480f611-Screenshot--2-.png\";s:9:\"file_size\";s:6:\"152376\";}}','s',6000,0,0,700,NULL,6700,NULL,0,0,NULL,1,NULL,'not_paid',0,NULL,NULL,'33',0,'vendor_invoice_created'),(2,'2020-07-04','1',162,'a:1:{i:0;a:2:{s:9:\"file_name\";s:55:\"client_po_file5f00611f78264-logo_GC_horizontal_Name.png\";s:9:\"file_size\";s:5:\"44435\";}}','t1',1000,0,0,5,NULL,1000,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,NULL,'',0,'vendor_invoice_created'),(3,'2020-08-27','1235ghty',1,'a:1:{i:0;a:2:{s:9:\"file_name\";s:114:\"client_po_file5f48aa16e1c8e-A_Rangasamy_Engineers_Pvt_Ltd-Gemicates_Technologies_Private_Limited-Work_Orders-1.pdf\";s:9:\"file_size\";s:6:\"106196\";}}','Service Work',15000,0,0,15,NULL,15015,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,NULL,'33',9,'vendor_invoice_created'),(4,'2020-09-21','123CPO',173,'a:1:{i:0;a:2:{s:9:\"file_name\";s:43:\"client_po_file5f689187e95a3-arivudaimai.png\";s:9:\"file_size\";s:5:\"26086\";}}','test client PO',1000000,0,0,180000,NULL,1180000,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,NULL,'',10,'vendor_invoice_created'),(5,'2020-10-01','5200162168',181,'a:1:{i:0;a:2:{s:9:\"file_name\";s:45:\"client_po_file5f7615db19bfe-PO-5200162168.pdf\";s:9:\"file_size\";s:6:\"114233\";}}','Technician Supply for SE Maintenance Job ',240,0,0,120,NULL,360,NULL,0,0,NULL,1,NULL,'not_paid',0,NULL,NULL,'100024135400003',0,'vendor_invoice_created'),(6,'2020-10-02','5200162168',181,'a:1:{i:0;a:2:{s:9:\"file_name\";s:45:\"client_po_file5f762349a0fbb-PO-5200162168.pdf\";s:9:\"file_size\";s:6:\"114233\";}}','Technician Supply for Maintenance Project',240,0,0,120,NULL,360,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,NULL,'100024135400003',0,'vendor_invoice_created'),(7,'2020-10-13','PO 666',183,'a:1:{i:0;a:2:{s:9:\"file_name\";s:48:\"client_po_file5f85c7c8a68d5-todays-meeting-.docx\";s:9:\"file_size\";s:4:\"9665\";}}','hhh',10000,0,0,444,NULL,10444,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,NULL,'Vat',14,'vendor_invoice_created'),(8,'2020-10-27','0',8,'a:1:{i:0;a:2:{s:9:\"file_name\";b:0;s:9:\"file_size\";s:6:\"112325\";}}','0',0,0,0,0,NULL,0,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,NULL,'',0,'vendor_invoice_created'),(9,'2021-06-24','PO123',181,'a:1:{i:0;a:2:{s:9:\"file_name\";s:36:\"client_po_file60d4ce800bcf8-Logo.png\";s:9:\"file_size\";s:4:\"7713\";}}','Retrofit Project',2200,0,0,0,NULL,2200,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,NULL,'',20,'vendor_invoice_created'),(10,'2021-06-26','POTEST',181,'a:1:{i:0;a:2:{s:9:\"file_name\";s:36:\"client_po_file60d62c317bce3-Logo.png\";s:9:\"file_size\";s:4:\"7713\";}}','AWE',18000,0,0,1000,NULL,19000,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,NULL,'',19,'vendor_invoice_created'),(11,'2024-06-03','7',164,'a:1:{i:0;a:2:{s:9:\"file_name\";s:56:\"client_po_file665d9fa7544f7-bugs-in-ERP-demo-project.odt\";s:9:\"file_size\";s:5:\"27983\";}}','hi',34000,0,0,6,NULL,34006,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,NULL,'7',24,'vendor_invoice_created'),(12,'2024-06-08','123',201,'a:1:{i:0;a:2:{s:9:\"file_name\";s:78:\"client_po_file66641fe5acb94-note_file6655c666f20ae-Gems-Manager-Gemicates.xlsx\";s:9:\"file_size\";s:5:\"14393\";}}','1',1,0,0,1,NULL,2,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,NULL,'1',0,'vendor_invoice_created'),(13,'2024-06-12','11111111111',9,'a:1:{i:0;a:2:{s:9:\"file_name\";s:81:\"client_po_file666939f9dece6-note_file6655c666f20ae-Gems-Manager-Gemicates-2-.xlsx\";s:9:\"file_size\";s:5:\"14393\";}}','1',1,0,0,1,NULL,2,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,NULL,'',30,'vendor_invoice_created'),(14,'2024-06-22','11111',3,'a:1:{i:0;a:2:{s:9:\"file_name\";b:0;s:9:\"file_size\";s:5:\"14641\";}}','1',1,0,0,1,NULL,2,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,NULL,'1',0,'vendor_invoice_created');
/*!40000 ALTER TABLE `clients_po_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
