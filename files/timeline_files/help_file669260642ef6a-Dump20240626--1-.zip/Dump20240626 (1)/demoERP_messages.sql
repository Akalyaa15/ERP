-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'Untitled',
  `message` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `from_user_id` int NOT NULL,
  `to_user_id` int NOT NULL,
  `status` enum('unread','read') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'unread',
  `message_id` int NOT NULL DEFAULT '0',
  `deleted` int NOT NULL DEFAULT '0',
  `files` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `deleted_by_users` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `message_from` (`from_user_id`),
  KEY `message_to` (`to_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (1,'My Task on Gems Portal ','mani','2020-04-17 14:10:20',355,958,'unread',0,0,'a:13:{i:0;a:2:{s:9:\"file_name\";s:48:\"message_file5e996b7462afb-Kishore-worksheet.xlsx\";s:9:\"file_size\";s:4:\"9403\";}i:1;a:2:{s:9:\"file_name\";b:0;s:9:\"file_size\";s:4:\"9403\";}i:2;a:2:{s:9:\"file_name\";s:46:\"message_file5e996b7462f3f-Mani-work-sheet.xlsx\";s:9:\"file_size\";s:4:\"9517\";}i:3;a:2:{s:9:\"file_name\";s:45:\"message_file5e996b746304c-Mani-worksheet.xlsx\";s:9:\"file_size\";s:4:\"9256\";}i:4;a:2:{s:9:\"file_name\";s:56:\"message_file5e996b7463159-Mani-worksheet-16-04-2020.xlsx\";s:9:\"file_size\";s:6:\"104424\";}i:5;a:2:{s:9:\"file_name\";s:52:\"message_file5e996b74632c6-Reference-Work-Report.xlsx\";s:9:\"file_size\";s:6:\"104329\";}i:6;a:2:{s:9:\"file_name\";s:42:\"message_file5e996b7463421-Work-Report.xlsx\";s:9:\"file_size\";s:5:\"76973\";}i:7;a:2:{s:9:\"file_name\";b:0;s:9:\"file_size\";s:4:\"9403\";}i:8;a:2:{s:9:\"file_name\";b:0;s:9:\"file_size\";s:4:\"9517\";}i:9;a:2:{s:9:\"file_name\";b:0;s:9:\"file_size\";s:4:\"9256\";}i:10;a:2:{s:9:\"file_name\";b:0;s:9:\"file_size\";s:6:\"104424\";}i:11;a:2:{s:9:\"file_name\";b:0;s:9:\"file_size\";s:6:\"104329\";}i:12;a:2:{s:9:\"file_name\";b:0;s:9:\"file_size\";s:5:\"76973\";}}',',355'),(2,'hi','kfkfa','2020-04-18 18:55:56',396,504,'read',0,0,'a:0:{}',',504'),(3,'test','Hi delete','2020-04-18 18:55:59',1,504,'read',0,0,'a:0:{}',',504'),(4,'','hihi\n','2020-04-18 18:56:17',504,1,'read',3,0,'a:0:{}',',504'),(5,'','bye\n','2020-04-18 18:56:25',504,1,'read',3,0,'a:0:{}',',504'),(6,'','buuu','2020-04-18 18:56:29',504,1,'read',3,1,'a:0:{}',',504'),(7,'Test','hi','2020-04-24 13:23:31',497,385,'read',0,0,'a:0:{}',',385'),(8,'Training People','Dear Sir,\nAs you said initiated the training\n\n-Hk','2020-04-30 19:37:35',247,356,'unread',0,0,'a:1:{i:0;a:2:{s:9:\"file_name\";s:112:\"message_file5eaadba72f0d0-A_Rangasamy_Engineers_Pvt_Ltd-Gemicates_Technologies_Private_Limited-Work_Orders-1.pdf\";s:9:\"file_size\";s:6:\"106196\";}}',''),(9,'test','hii','2020-05-07 11:46:23',269,5,'read',0,0,'a:0:{}',''),(10,'test','hello','2020-05-07 11:48:34',269,5,'read',0,0,'a:0:{}',''),(11,'test','hiiii','2020-05-07 12:17:09',269,356,'unread',0,0,'a:0:{}',''),(12,'test','hi','2020-05-09 16:49:39',969,385,'read',0,0,'a:0:{}',''),(13,'portal','Pfa','2020-05-11 15:05:33',621,247,'read',0,0,'a:1:{i:0;a:2:{s:9:\"file_name\";s:52:\"message_file5eb91c65794d2-ScreenRecorderProject2.mkv\";s:9:\"file_size\";s:3:\"782\";}}',''),(14,'','ok bro\n','2020-05-23 13:32:13',385,497,'unread',7,0,'a:0:{}',',385'),(15,'','s\n','2020-05-23 13:42:39',385,969,'read',12,0,'a:0:{}',''),(16,'payslip testing','hi mam,\n\nPFA','2020-05-28 11:08:03',621,15,'read',0,0,'a:1:{i:0;a:2:{s:9:\"file_name\";s:48:\"message_file5ecf4e3b1e2f2-Employee_Payslip-8.pdf\";s:9:\"file_size\";s:5:\"91834\";}}',''),(17,'Test','Test','2020-06-15 13:37:25',1,5,'read',0,0,'a:0:{}',''),(18,'How it works','Hi madam,\n\nHow it works? Please help me\n','2020-06-22 00:17:54',1,15,'read',0,0,'a:0:{}',''),(19,'','Hi','2020-06-22 00:21:07',1,5,'read',17,0,'a:0:{}',''),(20,'test','hjhjhjhjhjjhhjj','2020-07-06 10:44:50',957,504,'read',0,0,'a:0:{}',''),(21,'','hhhh','2020-07-06 10:45:12',504,957,'read',20,0,'a:0:{}',''),(22,'','https://tamil.oneindia.com/\n','2020-07-06 10:47:21',957,504,'read',20,0,'a:0:{}',''),(23,'Site engineers Documents','PFA','2020-07-06 18:25:51',506,5,'read',0,0,'a:0:{}',''),(24,'task for next week needed','pfa..','2020-07-07 15:29:50',621,247,'read',0,0,'a:1:{i:0;a:2:{s:9:\"file_name\";s:45:\"message_file5f044796f0508-vendor-details.xlsx\";s:9:\"file_size\";s:5:\"14937\";}}',''),(25,'','need to discuss in tally ','2020-07-11 10:46:59',247,621,'read',24,0,'a:0:{}',''),(26,'','its urgent','2020-07-11 10:47:04',247,621,'read',24,1,'a:0:{}',''),(27,'log in details -10.07.2020','pfa','2020-07-11 12:10:42',621,15,'unread',0,0,'a:1:{i:0;a:2:{s:9:\"file_name\";s:57:\"message_file5f095eea0a188-Gems-Manager-Gemicates--2-.xlsx\";s:9:\"file_size\";s:5:\"25185\";}}',''),(28,'Ex','Hii','2020-07-14 16:23:13',621,15,'read',0,0,'a:0:{}',''),(29,'','nn','2020-08-07 10:40:05',5,506,'read',23,0,'a:0:{}',''),(30,'','nn','2020-08-07 10:40:09',5,506,'read',23,0,'a:0:{}',''),(31,'Latecomers','PFA','2020-08-13 11:39:44',506,495,'unread',0,0,'a:0:{}',''),(32,'Latecomers','PFA','2020-08-13 11:39:44',506,621,'read',0,0,'a:0:{}',''),(33,'Latecomers','PFA','2020-08-13 11:39:44',506,15,'unread',0,0,'a:0:{}',''),(34,'testinhg','Test','2020-08-15 12:32:34',247,15,'unread',0,0,'a:0:{}',''),(35,'testinhg','Test','2020-08-15 12:32:34',247,506,'read',0,0,'a:0:{}',''),(36,'','bugs','2020-08-15 12:55:22',506,247,'read',35,0,'a:0:{}',''),(37,'test','test\n','2020-08-21 12:32:39',504,5,'read',0,0,'a:0:{}',''),(38,'test','test\n','2020-08-21 12:32:39',504,15,'unread',0,0,'a:0:{}',''),(39,'Testing','Checking Message','2020-08-21 12:57:25',247,15,'unread',0,0,'a:0:{}',''),(40,'Testing','Checking Message','2020-08-21 12:57:25',247,506,'read',0,0,'a:0:{}',''),(41,'Testing','Checking Message','2020-08-21 12:57:25',247,1,'read',0,0,'a:0:{}',''),(42,'sa','sa','2020-08-29 07:53:27',1,12,'unread',0,0,'a:0:{}',''),(43,'','cc','2020-08-29 07:57:34',1,12,'unread',42,0,'a:0:{}',''),(44,'','ss','2020-08-29 07:57:50',1,12,'unread',42,0,'a:0:{}',''),(45,'','asa','2020-08-31 04:47:23',1,12,'unread',42,0,'a:0:{}',''),(46,'','sdds','2020-08-31 05:03:15',1,12,'unread',42,0,'a:0:{}',''),(47,'','sa','2020-08-31 05:07:00',1,12,'unread',42,0,'a:0:{}',''),(48,'test 3','test','2020-09-29 09:28:35',1004,1012,'read',0,0,'a:0:{}',''),(49,'test 3','wwww','2020-09-29 09:35:46',1004,1012,'read',0,0,'a:0:{}',''),(50,'','ok','2020-09-29 09:38:45',1012,1004,'unread',49,0,'a:0:{}',''),(51,'','yes','2020-09-29 09:38:57',1012,1004,'unread',48,0,'a:0:{}',''),(52,'test','test','2021-03-22 10:46:55',1,985,'unread',0,0,'a:0:{}',''),(53,'new log in needed','new log in needed','2021-04-01 09:28:09',621,624,'unread',0,0,'a:0:{}',''),(54,'new log in needed','new log in needed','2021-04-01 09:28:09',621,1012,'unread',0,0,'a:0:{}',''),(55,'new log in needed','new log in needed','2021-04-01 09:28:09',621,12,'unread',0,0,'a:0:{}',''),(56,'po discussion','po discussion','2021-04-02 10:02:33',1035,621,'unread',0,0,'a:1:{i:0;a:2:{s:9:\"file_name\";s:40:\"message_file6066ebb98a70d-documents.jpeg\";s:9:\"file_size\";s:5:\"94339\";}}',''),(57,'just checking','hi ','2024-05-28 10:36:22',1,1000,'unread',0,0,'a:0:{}',''),(58,'','hi','2024-05-28 12:43:37',1,247,'unread',41,0,'a:1:{i:0;a:2:{s:9:\"file_name\";s:76:\"message_file6655d1792117a-note_file6655c666f20ae-Gems-Manager-Gemicates.xlsx\";s:9:\"file_size\";s:5:\"14393\";}}',''),(59,'hi','hi','2024-06-01 09:34:54',1,1016,'unread',0,0,'a:1:{i:0;a:2:{s:9:\"file_name\";s:56:\"message_file665aeb3ec4382-Gems-Manager-Gemicates-1-.xlsx\";s:9:\"file_size\";s:5:\"13900\";}}',''),(60,'a','a','2024-06-10 05:42:49',1,985,'unread',0,0,'a:0:{}',''),(61,'','a','2024-06-10 05:43:09',1,247,'unread',41,0,'a:1:{i:0;a:2:{s:9:\"file_name\";s:76:\"message_file6666926d64e2b-note_file6655c666f20ae-Gems-Manager-Gemicates.xlsx\";s:9:\"file_size\";s:5:\"14393\";}}',''),(62,'1','1','2024-06-21 05:13:08',1,995,'unread',0,0,'a:0:{}',''),(63,'Testing','Testing','2024-06-21 06:02:46',1,985,'unread',0,0,'a:0:{}',''),(64,'23','2','2024-06-21 08:39:18',1,5,'unread',0,0,'a:0:{}',''),(65,'123456','12','2024-06-21 10:27:22',1,624,'unread',0,0,'a:0:{}',''),(66,'','testing','2024-06-21 10:27:38',1,985,'unread',63,0,'a:0:{}',''),(67,'Subject Testing','Testing','2024-06-22 06:35:54',1,985,'unread',0,0,'a:0:{}',''),(68,'hi','Testing','2024-06-25 12:19:59',1,624,'unread',0,0,'a:1:{i:0;a:2:{s:9:\"file_name\";s:57:\"message_file667ab5efb70a9-LAMP-Installation-Procedure.txt\";s:9:\"file_size\";s:4:\"5128\";}}',''),(69,'Testing','1234','2024-06-26 06:56:14',1,356,'unread',0,0,'a:1:{i:0;a:2:{s:9:\"file_name\";s:57:\"message_file667bbb8e60dc6-LAMP-Installation-Procedure.txt\";s:9:\"file_size\";s:4:\"5128\";}}','');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:13
