-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `manufacturer`
--

DROP TABLE IF EXISTS `manufacturer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `manufacturer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `address` varchar(500) NOT NULL,
  `website` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `status` enum('active','inactive') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'active',
  `last_activity` datetime DEFAULT NULL,
  `last_activity_user` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manufacturer`
--

LOCK TABLES `manufacturer` WRITE;
/*!40000 ALTER TABLE `manufacturer` DISABLE KEYS */;
INSERT INTO `manufacturer` VALUES (1,'Hkvision','chennai','','',0,'active',NULL,NULL),(2,'Safeguard','Chennai','','CCTV Cameras',0,'active',NULL,NULL),(3,'CP Plus','Bhopal','','Camera.\nDVR\nPOE switch \nCable',0,'active',NULL,NULL),(4,'CP  Plus','Mumbai','','Cable',0,'active','2020-09-05 07:42:59',1),(5,' .','.','','',1,'active','2020-11-05 07:26:46',1),(6,';/.;[','256','','',1,'active','2020-11-05 07:26:40',1),(7,'ACTIVE TOTAL SECURITY SYSTEMS','40, Muthu Mariamman Koil St, Vallalar Colony, \nAnna Nagar, Chennai, Tamil Nadu 600040, India','www.atss.in','Dear Channel Partner, We take this opportunity to introduce ATSS, one of the Pioneer Security Solutions Providing\nDistribution Company with the rich experience of more than 16 years in the industry. We have our own security alarm products. We are the manufacturer of security alarm system and\ncarries good will in this industry. ATSS Authorised Distributor for ESSL, eGlu, Svarochi & Energyly. ATSS Philosophy is not just selling the product, getting to know the need of our partners and to\nprovide complete and perfect solution. We provide full-Security Solutions for Commercial and Residential Segment security product such as\nBurglar Alarm Systems, Alarm Dialer, CCTV HD Camera, IP CCTV Camera, Home Automation, Smart\nLed Lights, Video Door Phone, Smart Lock, Gate Automation, Electric Fence, School Timer, GSM\nCommunicator, Time Attendance, Access Control, Swing Barrier, Flap Barrier, Turnstile, Parking\nBoom Barrier, Hand Held Detector, Door Frame Metal Detector, Guard Tour System, Conventiona',0,'active','2020-11-05 10:39:29',7),(8,'Testing','Testing','web.iitm.ac.in','Testing',0,'active','2024-06-07 09:33:49',1),(9,'Gemicates','18/49-1,RP','web.iitm.ac.in','tESTING',0,'active','2024-06-07 09:35:47',1),(10,'Gemicatesg','18/49-1,RP','web.iitm.ac.in','Testing',0,'active','2024-06-07 09:42:32',1),(11,'Testingd','f','f','f',0,'active','2024-06-07 09:44:16',1),(12,'Testing1234','123,RP','web.iitm.ac.in','Testing',0,'active','2024-06-10 11:54:28',1),(13,'Testing22','2','2','2',0,'active','2024-06-12 05:21:38',1),(14,'2','2','2','2',0,'active','2024-06-12 07:22:54',1);
/*!40000 ALTER TABLE `manufacturer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:16
