-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `companys`
--

DROP TABLE IF EXISTS `companys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companys` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `address` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `city` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `state` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `zip` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `country` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_date` date NOT NULL,
  `website` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `phone` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `currency_symbol` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `starred_by` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `group_ids` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `vat_number` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `currency` varchar(3) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `disable_online_payment` tinyint(1) NOT NULL DEFAULT '0',
  `gstin_number_first_two_digits` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `gst_number` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `partner_id` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `cin` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `panno` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `tan` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `uam` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `iec` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `accountnumber` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `bankname` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `branch` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `ifsc` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `micr` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `swift_code` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `buyer_type` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `company_logo` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `enable_company_logo` tinyint(1) NOT NULL DEFAULT '0',
  `state_mandatory` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `cr_id` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companys`
--

LOCK TABLES `companys` WRITE;
/*!40000 ALTER TABLE `companys` DISABLE KEYS */;
INSERT INTO `companys` VALUES (1,'Gemicates','Chennai','','32','','99','2020-09-24','','','₹','','',1,NULL,'INR',0,'','',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,0,'yes','CR001'),(2,'gems','Old No.84/4, New No. 19/4, Indira Colony,','chennai','','8899','826','0000-00-00','www.gemicates','62728229','$',',:1:','',0,NULL,'USD',0,'33','33',NULL,'122','','','','','','','','','','','','','_file5f842bfbc12f0-companys-logo.png',0,'no','CR002'),(3,'voltamp','test ','Manama','30','','356','2020-09-28','','123456789','₹','','',0,NULL,'INR',0,'','',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,0,'yes','CR003'),(4,'Gemicates Tech','Saidapet, Chennai','chennai','32','','356','2020-09-28','','','₹','','',0,NULL,'INR',0,'','',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,0,'yes','CR004'),(5,'.','','','','','320','2020-11-06','','','','','',0,NULL,'',0,'','',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,0,'no','CR005'),(6,'GEMICATES',NULL,NULL,NULL,NULL,NULL,'0000-00-00',NULL,NULL,NULL,'','',0,NULL,NULL,0,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,0,NULL,'CR006'),(7,'Pixio Technologies',NULL,NULL,NULL,NULL,NULL,'0000-00-00',NULL,NULL,NULL,'','',0,NULL,NULL,0,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,0,NULL,'CR007'),(8,'Automios',NULL,NULL,NULL,NULL,NULL,'0000-00-00',NULL,NULL,NULL,'','',0,NULL,NULL,0,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,0,NULL,'CR008'),(9,'Gems labs','19/4, indira colony','nellore','2','62365','356','2021-04-02','','9884920637','₹','','',0,NULL,'INR',0,'37','37AADPJ6250A1ZE',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2',NULL,0,'yes','CR009');
/*!40000 ALTER TABLE `companys` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:14
