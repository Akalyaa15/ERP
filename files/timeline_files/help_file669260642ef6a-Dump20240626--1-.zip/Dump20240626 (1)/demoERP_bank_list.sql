-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bank_list`
--

DROP TABLE IF EXISTS `bank_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank_list` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `description` varchar(45) NOT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `status` enum('active','inactive') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'active',
  `account_number` text,
  `last_activity` datetime DEFAULT NULL,
  `last_activity_user` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_list`
--

LOCK TABLES `bank_list` WRITE;
/*!40000 ALTER TABLE `bank_list` DISABLE KEYS */;
INSERT INTO `bank_list` VALUES (1,'Indian Bank','collecting bank details',0,'active','6616045021','2020-11-06 11:38:24',1024),(2,'ICICI Bank','',0,'active','189674875,00905066502',NULL,NULL),(3,'State Bank of India','',0,'active',NULL,NULL,NULL),(4,'HDFC Bank','',0,'active','24578153,8751469254,369547212',NULL,NULL),(5,'Bank of Baroda','',0,'active',NULL,NULL,NULL),(6,'Bank of India','',0,'active',NULL,NULL,NULL),(7,'Canara Bank','',0,'active',NULL,NULL,NULL),(8,'Citibank','',0,'active',NULL,NULL,NULL),(9,'Indian Overseas Bank','',0,'active',NULL,NULL,NULL),(10,'Yes Bank','',0,'active',NULL,NULL,NULL),(11,'Axis Bank','',0,'active','',NULL,NULL),(12,'karur Vysya Bank','',0,'active',NULL,NULL,NULL),(13,'Lakshmi Vilas Bank','',0,'active',NULL,NULL,NULL),(14,'IDIB Bank','',0,'active',NULL,NULL,NULL),(15,'Y Bank','',0,'active','',NULL,NULL),(16,'Orientel bank of commerce','Current account',0,'active','582364712453',NULL,NULL),(17,'Yes','',0,'active','','2021-04-01 05:14:28',1),(18,'State Bank','Testing',0,'active','','2024-06-03 06:48:58',1),(19,'hi','Testing',0,'active','','2024-06-07 05:22:44',1),(20,'Testing','12',0,'inactive','','2024-06-22 09:58:02',1);
/*!40000 ALTER TABLE `bank_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:14
