-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `work_orders`
--

DROP TABLE IF EXISTS `work_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vendor_id` int NOT NULL,
  `estimate_request_id` int NOT NULL DEFAULT '0',
  `work_order_date` date NOT NULL,
  `valid_until` date NOT NULL,
  `note` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `status` enum('draft','not_paid') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'draft',
  `last_email_sent_date` date DEFAULT NULL,
  `tax_id` int NOT NULL DEFAULT '0',
  `tax_id2` int NOT NULL DEFAULT '0',
  `project_id` int NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `delivery_note_date` date DEFAULT NULL,
  `supplier_ref` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `other_references` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `terms_of_payment` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `work_order_no` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `work_date` date DEFAULT NULL,
  `dispatch_document_no` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `destination` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `dispatched_through` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `terms_of_delivery` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `freight_amount` double NOT NULL,
  `gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `hsn_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `hsn_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `delivery_address` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `estimate_delivery_address` tinyint NOT NULL DEFAULT '0',
  `delivery_address_company_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `delivery_address_city` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `delivery_address_state` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `delivery_address_zip` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `delivery_address_country` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `without_gst` tinyint NOT NULL DEFAULT '0',
  `lut_number` varchar(45) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `with_gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `with_inclusive_tax` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `freight_tax_amount` double DEFAULT NULL,
  `delivery_address_phone` varchar(45) DEFAULT NULL,
  `work_no` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_orders`
--

LOCK TABLES `work_orders` WRITE;
/*!40000 ALTER TABLE `work_orders` DISABLE KEYS */;
INSERT INTO `work_orders` VALUES (1,164,0,'2020-04-17','2020-05-05','TESTING-order Should be done with in one  week ','not_paid',NULL,0,0,0,0,'2020-04-17','GCT14180472 -Testing-1.0','GCT14180472 ','Cash','','2020-04-17','','','','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'',''),(2,1,0,'2020-04-23','2020-04-24','','not_paid',NULL,0,0,0,1,'2020-04-23','900','','Cash','','2020-04-23','','','','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'',''),(3,214,0,'2020-04-25','2020-04-26','','not_paid',NULL,0,0,0,0,'2020-04-25','Kishore','Gems','Cash','','2020-04-25','','chennai','4','',0,'','','','',1,'gems','chenai','tamilnadu','600018','india',0,'',NULL,NULL,NULL,NULL,'0987653123',''),(4,94,0,'2020-05-02','2020-05-11','','draft',NULL,0,0,0,0,'2020-05-11','','','IMPS','PKN/2020-21/972561','2020-05-11','','','','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'',''),(5,123,0,'2020-05-11','2020-05-31','','not_paid',NULL,0,0,0,0,'2020-05-11','','','Cash','AE/945','2020-05-11','','','','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'',''),(6,94,0,'2020-05-12','2020-06-12','','not_paid',NULL,0,0,0,0,'2020-05-13','GCT 197645-TESTING','','Cheque','asss/2020/01','2020-05-13','','CHENGELPET','2','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'',''),(7,217,0,'2020-06-01','2020-06-10','','not_paid',NULL,0,0,0,0,'2020-06-15','','','Cash','','2020-06-15','','','','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','WORk7'),(8,164,0,'2020-09-19','2020-09-19','','draft',NULL,0,0,0,0,'2020-09-19','','','Cash','','2020-09-19','','','','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','WORK ORDER #8'),(9,164,0,'2020-09-20','2020-09-21','','draft',NULL,0,0,0,0,'2020-09-20','Anparasu','','Cheque','','2020-09-20','','','','',0,'','','','',0,'','','','','',0,'14256',NULL,NULL,NULL,NULL,'','WORK ORDER #9'),(10,3,0,'2020-09-22','2020-09-22','','draft',NULL,0,0,0,0,'2020-09-22','','','Cheque','','2020-09-22','','','','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','WORK ORDER #10'),(11,227,0,'2020-10-01','2020-10-30','','not_paid',NULL,0,0,0,0,'2020-10-01','SUPP REF2','ref4','Cheque','SPI77','2020-10-01','TKT887','chennai','1','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','SERVICE ORDER #11'),(12,228,0,'2020-10-13','2020-10-30','kk','not_paid',NULL,0,0,0,0,'2020-10-13','sup','ref2','Cash','SPI77','2020-10-13','tttt89','chennai','3','nnn',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','SERVICE ORDER #12'),(13,214,0,'2020-10-27','2020-10-28','','not_paid',NULL,0,0,0,0,'2020-10-27','','','Cash','','2020-10-27','','','','',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','SERVICE ORDER #13'),(14,200,0,'2024-06-21','2024-06-21','1','draft',NULL,0,0,0,0,'2024-06-21','123456','123','Cash','1','2024-06-21','1','1','2','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','SERVICE ORDER #14'),(15,94,0,'2024-06-13','2024-06-27','1','draft',NULL,0,0,0,0,'2024-06-21','123456','1','Demand Draft','1','2024-06-21','1','1','3','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','SERVICE ORDER #15'),(16,94,0,'2024-06-22','2024-07-05','1','draft',NULL,0,0,0,0,'2024-06-22','1','1','Demand Draft','1','2024-06-22','1','1','1','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','SERVICE ORDER #16'),(17,94,0,'2024-06-14','2024-06-27','1','draft',NULL,0,0,0,0,'2024-05-29','123456','1','Demand Draft','1','2024-06-22','1','1','3','1',0,'','','','',1,'1','','','','',0,'',NULL,NULL,NULL,NULL,'','SERVICE ORDER #17'),(18,164,0,'2024-06-06','2024-12-27','1','draft',NULL,0,0,0,0,'2024-06-22','1234','1','IMPS','1','2024-06-22','1','1','3','1',0,'','','','',1,'1','','','','',0,'',NULL,NULL,NULL,NULL,'','SERVICE ORDER #18'),(19,164,0,'2024-06-19','2024-06-28','1','draft',NULL,0,0,0,0,'2024-06-26','1','12345','Demand Draft','1','2024-06-26','1','1','1','1',0,'','','','',0,'','','','','',0,'',NULL,NULL,NULL,NULL,'','SERVICE ORDER #19');
/*!40000 ALTER TABLE `work_orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:13
