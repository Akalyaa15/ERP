-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `vendors_invoice_list`
--

DROP TABLE IF EXISTS `vendors_invoice_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vendors_invoice_list` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_date` date DEFAULT NULL,
  `invoice_no` varchar(100) DEFAULT NULL,
  `vendor_id` int DEFAULT NULL,
  `files` mediumtext NOT NULL,
  `description` text,
  `amount` double NOT NULL,
  `cgst_tax` double NOT NULL,
  `sgst_tax` double NOT NULL,
  `igst_tax` double NOT NULL,
  `cheque_no` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `total` double NOT NULL,
  `net_total` double DEFAULT NULL,
  `payment_method_id` int NOT NULL,
  `amount_paid` double NOT NULL,
  `due` double DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `state_tax` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `status` enum('not_paid','paid','partially_paid') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'not_paid',
  `status_id` int NOT NULL,
  `utr_no` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `gstin_number_first_two_digits` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `gst_number` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `purchase_order_id` int NOT NULL,
  `vendor_status` enum('vendor_invoice_created','not_paid') NOT NULL DEFAULT 'vendor_invoice_created',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendors_invoice_list`
--

LOCK TABLES `vendors_invoice_list` WRITE;
/*!40000 ALTER TABLE `vendors_invoice_list` DISABLE KEYS */;
INSERT INTO `vendors_invoice_list` VALUES (1,'2020-04-30','5987481',94,'a:1:{i:0;a:2:{s:9:\"file_name\";s:119:\"note_file5e999e763b1df-Pelikan_Office_Automation_Pvt._Ltd.-Gemicates_Technologies_Private_Limited-Purchase_Orders-1.pdf\";s:9:\"file_size\";s:6:\"101835\";}}','Cameras',1111,11,11,0,NULL,1133,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'33','33',0,'vendor_invoice_created'),(2,'2020-04-17','5987481-',94,'a:1:{i:0;a:2:{s:9:\"file_name\";b:0;s:9:\"file_size\";s:6:\"101835\";}}','DVR',4500,435,435,0,NULL,5370,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'33','33',0,'vendor_invoice_created'),(3,'2020-04-18','784/20/21',55,'a:1:{i:0;a:2:{s:9:\"file_name\";s:119:\"note_file5e9af3f921115-Pelikan_Office_Automation_Pvt._Ltd.-Gemicates_Technologies_Private_Limited-Purchase_Orders-1.pdf\";s:9:\"file_size\";s:6:\"101835\";}}','Camera',10000,900,900,0,NULL,11800,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'33','33',1,'vendor_invoice_created'),(4,'2020-05-11','ARM/2021/5867',207,'a:1:{i:0;a:2:{s:9:\"file_name\";s:119:\"note_file5eb8f6456fcdd-Pelikan_Office_Automation_Pvt._Ltd.-Gemicates_Technologies_Private_Limited-Purchase_Orders-1.pdf\";s:9:\"file_size\";s:6:\"108757\";}}','Purchase for the Guindy Site',43500,4500,4500,0,NULL,52500,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'33','33AACGF234A1Z0',6,'vendor_invoice_created'),(5,'2020-05-13','GCT/2020/01',114,'a:1:{i:0;a:2:{s:9:\"file_name\";s:54:\"note_file5ebbb22751016-Gems-Manager-Gemicates--2-.xlsx\";s:9:\"file_size\";s:5:\"15150\";}}','PURCAHSE OF CAMERA & INSTALLATION',50000,0,0,0,NULL,50000,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'','',0,'vendor_invoice_created'),(6,'2020-06-19','invoice1',124,'a:1:{i:0;a:2:{s:9:\"file_name\";s:41:\"note_file5ee733393b68c-Screenshot--3-.png\";s:9:\"file_size\";s:6:\"152114\";}}','mm',5000,44,44,0,NULL,5088,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'33','33',0,'vendor_invoice_created'),(7,'2020-07-11','23/20-21/08',214,'a:1:{i:0;a:2:{s:9:\"file_name\";s:54:\"note_file5f0979cd3b102-Gems-Manager-Gemicates--1-.xlsx\";s:9:\"file_size\";s:5:\"14394\";}}',' camera selling',520000,0,0,0,NULL,520000,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'','',5,'vendor_invoice_created'),(8,'2020-08-30','6515bhjmhvj',94,'a:1:{i:0;a:2:{s:9:\"file_name\";s:91:\"note_file5f37950fd3c86-Danway-Gemicates_Technologies_Private_Limited-Proforma_Invoice-1.pdf\";s:9:\"file_size\";s:6:\"112325\";}}','camera',52,5456,5456,0,NULL,10964,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'33','33',0,'vendor_invoice_created'),(9,'2020-08-15','35469njgvjhvjhv',124,'a:1:{i:0;a:2:{s:9:\"file_name\";s:109:\"note_file5f37961d73834-A_Rangasamy_Engineers_Pvt_Ltd-Gemicates_Technologies_Private_Limited-Work_Orders-1.pdf\";s:9:\"file_size\";s:6:\"106196\";}}','9+56klbhjb',2000,0,0,1000,NULL,3000,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'11','11',11,'vendor_invoice_created'),(10,'2020-08-28','GCT 124',164,'a:1:{i:0;a:2:{s:9:\"file_name\";s:102:\"note_file5f48ae544f691-Gemicates_Technologies-Gemicates_Technologies_Private_Limited-Invoice-3--1-.pdf\";s:9:\"file_size\";s:6:\"109866\";}}','Purchase of Product',9150,75,75,0,NULL,9300,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'33','33AAAF1567A1ZO',10,'vendor_invoice_created'),(11,'2020-09-12','EMR 124',224,'a:1:{i:0;a:2:{s:9:\"file_name\";s:91:\"note_file5f5c7d2c40adf-Danway-Gemicates_Technologies_Private_Limited-Proforma_Invoice-1.pdf\";s:9:\"file_size\";s:6:\"112325\";}}','vhf',200,0,0,1,NULL,201,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'27','27AAAF1567A1ZO',12,'vendor_invoice_created'),(12,'2020-10-27',' 0',123,'a:1:{i:0;a:2:{s:9:\"file_name\";s:98:\"note_file5f97e197917b2-Gemicates_Technologies-Gemicates_Technologies_Private_Limited-Invoice-3.pdf\";s:9:\"file_size\";s:6:\"113275\";}}',' 0',0,0,0,0,NULL,0,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'','',0,'vendor_invoice_created'),(13,'2020-11-09','3r23',17,'a:1:{i:0;a:2:{s:9:\"file_name\";s:109:\"note_file5fa91b9631071-A_Rangasamy_Engineers_Pvt_Ltd-Gemicates_Technologies_Private_Limited-Work_Orders-1.pdf\";s:9:\"file_size\";s:6:\"106196\";}}','cable',100,0,0,0,NULL,100,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'','',19,'vendor_invoice_created'),(14,'2024-06-03','2',164,'a:1:{i:0;a:2:{s:9:\"file_name\";s:49:\"note_file665da3b05d9fd-Adhoc-Form_Application.pdf\";s:9:\"file_size\";s:6:\"463606\";}}','hu',56,0,0,0,NULL,56,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'','',0,'vendor_invoice_created'),(15,'2024-06-08','1',200,'a:1:{i:0;a:2:{s:9:\"file_name\";s:73:\"note_file66641fb8d0353-note_file6655c666f20ae-Gems-Manager-Gemicates.xlsx\";s:9:\"file_size\";s:5:\"14393\";}}','1',1200,0,0,1,NULL,1201,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'1','14525626',0,'vendor_invoice_created'),(16,'2024-06-12','12345678',232,'a:1:{i:0;a:2:{s:9:\"file_name\";s:73:\"note_file666939b58dd6a-note_file6655c666f20ae-Gems-Manager-Gemicates.xlsx\";s:9:\"file_size\";s:5:\"14393\";}}','1',1,0,0,0,NULL,1,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'','',0,'vendor_invoice_created'),(17,'2024-06-22','1234567811',13,'a:1:{i:0;a:2:{s:9:\"file_name\";s:53:\"note_file66765f3e26e3d-Gems-Manager-Gemicates-6-.xlsx\";s:9:\"file_size\";s:5:\"13886\";}}','1',1,0,0,1,NULL,2,NULL,0,0,NULL,0,NULL,'not_paid',0,NULL,'1','12',0,'vendor_invoice_created');
/*!40000 ALTER TABLE `vendors_invoice_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:14
