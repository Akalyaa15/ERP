-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `invoice_items`
--

DROP TABLE IF EXISTS `invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `quantity` double NOT NULL,
  `unit_type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `rate` double NOT NULL,
  `total` double NOT NULL,
  `sort` int NOT NULL DEFAULT '0',
  `invoice_id` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `category` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `hsn_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `make` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `tax` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `gst` double NOT NULL,
  `tax_amount` double NOT NULL,
  `discount_percentage` double NOT NULL,
  `net_total` double NOT NULL,
  `hsn_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `profit_percentage` double NOT NULL,
  `actual_value` double NOT NULL,
  `MRP` double NOT NULL,
  `associated_with_part_no` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `profit_value` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `with_gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `lut` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `lut_number` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `quantity_total` double NOT NULL,
  `discount_amount` double DEFAULT NULL,
  `with_installation` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `with_installation_gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `installation_hsn_code_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `installation_gst` double DEFAULT NULL,
  `installation_rate` double DEFAULT NULL,
  `installation_hsn_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `installation_total` double DEFAULT NULL,
  `subtotal` double DEFAULT NULL,
  `installation_tax_amount` double DEFAULT NULL,
  `client_profit_margin` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `invoice_type` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_items`
--

LOCK TABLES `invoice_items` WRITE;
/*!40000 ALTER TABLE `invoice_items` DISABLE KEYS */;
INSERT INTO `invoice_items` VALUES (1,'DS-2CE1AD0T-IRPF','Camera',10,'NOS',150,0,0,2,0,'','8525','','',18,0,100,5900,'CCTV camera HSN',0,0,0,'','250','yes',NULL,NULL,1500,1500,'yes','yes','',18,500,'9987',5000,6500,900,'20','0'),(2,'GC-CA-001','Camera Accessories',10,'NOS',30,0,0,2,0,'','8571','','',18,0,100,118,'Camera Accessories',0,0,0,'','0','yes',NULL,NULL,300,300,'yes','yes','Services',18,10,'9987',100,400,18,'','0'),(3,'1lH1SCA3-090B','3+1 cables',10,'Meters',18,0,0,1,0,'','-','','',0,0,100,5200,'-',0,0,0,'','16.363636363636','no',NULL,NULL,180,180,'yes','no','-',0,520,'-',5200,5380,0,'10','0'),(4,'GC-CA-001','Camera Accessories',115,'NOS',30,-862.5,0,3,0,'','8571','','',18,-155.25,125,132.25,'Camera Accessories',0,0,0,'','575','yes',NULL,NULL,3450,4312.5,'yes','yes','',0,10,'',1150,4600,0,'20','0'),(5,'DS-2CE1AD0T-IRPF','Camera',2,'NOS',150,300,0,3,0,'','8525','','',18,54,0,1354,'CCTV camera HSN',0,0,0,'','50','yes',NULL,NULL,300,0,'yes','yes','',0,500,'',1000,1300,0,'20','0'),(6,'DS-7A08HQHI-K1','DVR\n',50,'NOS',6850,342500,0,3,0,'','8521','','',18,61650,0,430150,'DVR/NVR/XVR\n',0,0,0,'','57083.333333333','yes',NULL,NULL,342500,0,'yes','yes','',0,520,'',26000,368500,0,'20','0'),(7,'GC-BNC-001','BNC',500,'',10,5000,0,3,0,'','8571','','',18,900,0,32900,'Camera Accessories',0,0,0,'','833.33333333333','yes',NULL,NULL,5000,0,'yes','yes','',0,54,'',27000,32000,0,'20','0'),(8,'1lH1SCA3-090B','3+1 cables',5,'Meters',18,-45,0,3,0,'','','','',0,0,150,2555,'',0,0,0,'','15','yes',NULL,NULL,90,135,'yes','yes','',0,520,'',2600,2690,0,'20','0'),(9,'DS-2CE1AD0T-IRPF','Camera',1,'NOS',165,156.75,0,4,0,'','','','',0,0,5,656.75,'',0,0,0,'','15','yes',NULL,NULL,165,8.25,'yes','yes','',0,500,'',500,665,0,'10','0'),(10,'DS-2CE1AD0T-IRPF','Camera',100,'NOS',165,15675,0,5,0,'','8525','','',18,2821.5,5,77496.5,'CCTV camera HSN',0,0,0,'','1500','yes',NULL,NULL,16500,825,'yes','yes','Services',18,500,'9987',50000,66500,9000,'10','0'),(11,'DS-7A08HQHI-K1','DVR\n',75,'NOS',7535,565125,0,5,0,'','8521','','',18,101722.5,0,712867.5,'DVR/NVR/XVR\n',0,0,0,'','51375','yes',NULL,NULL,565125,0,'yes','yes','Services',18,520,'9987',39000,604125,7020,'10','0'),(12,'GC-CA-001','Camera Accessories',100,'NOS',33,3300,0,5,0,'','8571','','',18,594,0,5074,'Camera Accessories',0,0,0,'','300','yes',NULL,NULL,3300,0,'yes','yes','Services',18,10,'9987',1000,4300,180,'10','0'),(13,'DS-2CE1AD0T-IRPF','Camera',10,'NOS',150,1425,0,6,0,'0','8525','0','',18,256.5,5,7581.5,'CCTV camera HSN',0,0,0,NULL,NULL,NULL,NULL,NULL,1500,75,'yes','yes','Services',18,500,'9987',5000,NULL,900,'20',NULL),(14,'GC-CA-001','Camera Accessories',1,'NOS',33,33,0,7,0,'','-','','',0,0,0,43,'-',0,0,0,'','3','no',NULL,NULL,33,0,'yes','no','-',0,10,'-',10,43,0,'10','0'),(15,'GC-CA-001','Camera Accessories',25,'NOS',33,825,0,8,0,'','','','',0,0,0,1075,'',0,0,0,'','75','yes',NULL,NULL,825,0,'yes','yes','',0,10,'',250,1075,0,'10','0'),(16,'1lH1SCA3-090B','3+1 cables',25,'Meters',19.8,495,0,8,0,'','','','',0,0,0,13495,'',0,0,0,'','45','yes',NULL,NULL,495,0,'yes','yes','',0,520,'',13000,13495,0,'10','0'),(17,'1lH1SCA3-090B','3+1 cables',25,'Meters',18,450,0,9,0,'','','','',0,0,0,13450,'',0,0,0,'','0','yes',NULL,NULL,450,0,'yes','yes','',0,520,'',13000,13450,0,'','0'),(18,'exampleid123','solar',2,'NOS',10138.38,20276.76,0,10,0,'solaruuu','8544','1','',5,1013.838,0,22975.638,'Solar Water 365',1,0,0,'','200.76','yes',NULL,NULL,20276.76,0,'yes','yes','CCTV camera HSN',18,714,'8525',1428,21704.76,257.04,'','0'),(19,'DS-7A08HQHI-K1','DVR\n',1,'NOS',0,0,0,11,0,'0','8544','0','',5,0,8,0,'Solar Water 365',0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'yes','yes','Solar Water 365',5,520,'8544',520,NULL,0,'20',NULL),(20,'exampleid123','solar',1,'NOS',10138.38,10138.38,0,11,0,'solaruuu','8544','1','',5,506.919,0,11487.819,'Solar Water 365',0,0,0,NULL,NULL,NULL,NULL,NULL,10138.38,0,'yes','yes','CCTV camera HSN',18,714,'8525',714,NULL,128.52,'20',NULL),(21,'GC-BNC-001','BNC',1,'',10,10,0,11,0,'','','','',0,0,0,64,'',0,0,0,'','0','yes',NULL,NULL,10,0,'yes','yes','',0,54,'',54,64,0,'','0'),(22,'exampleid123','solar',1,'NOS',0,0,0,12,0,'solaruuu','-','1','',0,0,2,0,'-',1,0,0,'','0','no',NULL,NULL,0,0,'yes','no','-',0,0,'-',0,0,0,'10','0'),(23,'DS-2CE1AD0T-IRPF','Camera',1,'NOS',150,150,0,13,0,'','','','',0,0,0,650,'',0,0,0,'','0','yes',NULL,NULL,150,0,'yes','yes','',0,500,'',500,650,0,'','0'),(24,'DS-2CE1AD0T-IRPF','Camera',1,'NOS',6,6,0,14,0,'','-','','',0,0,0,10,'-',0,0,0,'','0.54545454545455','no',NULL,NULL,6,0,'yes','no','-',0,4,'-',4,10,0,'10','1'),(25,'Gemicates DS-123456-S','4MP Camera',3,'PCS',4197.5,6296.25,0,20,0,'Bullet Camera','8525','1','',18,1133.325,50,8013.675,'CCTV camera HSN',0,0,0,NULL,NULL,NULL,NULL,NULL,12592.5,6296.25,'yes','yes','-',18,165,'9987',495,NULL,89.1,'0',NULL),(26,'DS-2CE1AC0T-IRP','2MP Dome Camera',55,'NOS',1500,82500,0,21,0,'Camera','8525','','',18,14850,0,133045,'CCTV camera HSN',20,0,0,'','13750','yes',NULL,NULL,82500,0,'yes','yes','',18,550,'9987',30250,112750,5445,'','1'),(27,'1lH1SCA3-090B','3+1 cables',5,'Meters',0.24498,1.2249,0,22,0,'','-','','',0,0,0,36.6109,'-',0,0,0,'','0','no',NULL,NULL,1.2249,0,'yes','no','-',0,7.0772,'-',35.386,36.6109,0,'','1'),(28,'DS-2CE1AD0T-IRPF','Camera',2,'NOS',1.43805,2.8761,0,22,0,'gggg','-','','',0,0,0,12.4631,'-',0,0,0,'','0','no',NULL,NULL,2.8761,0,'yes','no','-',0,4.7935,'-',9.587,12.4631,0,'','1'),(29,'1lH1SCA3-090B','3+1 cables',3,'Meters',18.78264,56.34792,0,24,0,'','-','','',0,0,0,1684.17672,'-',0,0,0,'','0','no',NULL,NULL,56.34792,0,'yes','no','-',0,542.6096,'-',1627.8288,1684.17672,0,'','0'),(30,'exampleid123','solar',77,'NOS',67.375618128,4772.8887881875,0,25,0,'solaruuu','-','1','',0,0,8,4772.8887881875,'-',1,0,0,'','1227.6763394774','no',NULL,NULL,5187.922595856,415.03380766848,'no','no','-',0,0,'-',0,5468.970131856,0,'30','0'),(31,'DS-7A08HQHI-K1','DVR\n',1,'NOS',45.807320000000004,45.80732,0,26,0,'','-','','',0,0,0,48.4822,'-',0,0,0,'','10.57092','no',NULL,NULL,45.80732,0,'yes','no','-',0,2.67488,'-',2.67488,48.4822,0,'30','1'),(32,'exampleid123','solar',2,'NOS',10138.38,20276.76,0,27,0,'solaruuu','8544','1','',5,1013.838,0,22975.638,'Solar Water 365',1,0,0,'','200.76','yes',NULL,NULL,20276.76,0,'yes','yes','CCTV camera HSN',18,714,'8525',1428,21704.76,257.04,'','0'),(33,'Gemicates DS-123456-S','4MP Camera',15,'PCS',4197.5,62962.5,0,30,0,'Bullet Camera','8525','1','',18,11333.25,0,77216.25,'CCTV camera HSN',15,0,0,'','8212.5','yes',NULL,NULL,62962.5,0,'yes','yes','',18,165,'9987',2475,65437.5,445.5,'','0'),(34,'GCT-1201','Screw driver',7,'NOS',120,840,0,31,0,'Site Tools','-','2','',0,0,0,840,NULL,5,0,0,NULL,NULL,'no',NULL,NULL,840,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(35,'DS-2CE1AC0T-IRP','2MP Dome Camera',1,'NOS',9,9,0,32,0,'Camera','-','','',0,0,0,9,NULL,5,0,0,NULL,NULL,'no',NULL,NULL,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(36,'GC-BNC-001','BNC',5,'',3,15,0,32,0,'','-','','',0,0,0,15,NULL,5,0,0,NULL,NULL,'no',NULL,NULL,15,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(37,'GC_SD_0011','Screw driver',2,'NOS',30,60,0,32,0,'Driver tool','-','1','',0,0,0,60,NULL,5,0,0,NULL,NULL,'no',NULL,NULL,60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(38,'1lH1SCA3-090B','3+1 cables',20,'Meters',18,180,0,34,0,'','8471','','',18,32.4,50,12484.4,'Cables',0,0,0,'','83.076923076923','yes',NULL,NULL,360,180,'yes','yes','Services',18,520,'9987',10400,10760,1872,'30','0'),(39,'GCT-2020-001-TESTING','CAMERA TOOLS',1,'NOS',27500,26125,0,33,0,'CAMERA ACCESOIRES','-','','',0,0,5,26146,'-',10,0,0,'','2500','no',NULL,NULL,27500,1375,'yes','no','-',0,21,'-',21,27521,0,'','0'),(40,'GCT-2020-001-TESTING','CAMERA TOOLS',1,'NOS',35750,28600,0,34,0,'CAMERA ACCESOIRES','8571','','',18,5148,20,33769,'Camera Accessories',10,0,0,'','10214.285714286','yes',NULL,NULL,35750,7150,'yes','no','-',0,21,'-',21,35771,0,'30','0'),(41,'GM-1001','Camera accessories\n',15,'PCS',4550,66543.75,0,35,1,'2','8898','3','',28,18632.25,2.5,85176,'camera gst',40,0,0,'','28102.941176471','yes',NULL,NULL,68250,1706.25,'yes','no','-',0,0,'-',0,68250,0,'30','0'),(42,'GM-1001','Camera accessories\n',15,'PCS',4550,66543.75,0,35,0,'2','8898','3','',28,18632.25,2.5,97070.4,'camera gst',40,0,0,'','28102.941176471','yes',NULL,NULL,68250,1706.25,'yes','yes','camera Installation Charges ',18,672,' 995461 ( Camera Installation )',10080,78330,1814.4,'30','0'),(43,'DS-2CE1AD0T-IRPF','Camera',2,'NOS',158.7513,317.5026,0,36,0,'','-','','',0,0,0,317.5026,'-',0,0,0,'','0','no',NULL,NULL,317.5026,0,'no','no','-',0,0,'-',0,1375.8446,0,'','0'),(44,'GC-CA-001','Camera Accessories',1,'NOS',30,30,0,36,0,'','8525','','',18,5.4,0,35.4,'CCTV camera HSN',0,0,0,'','0','yes',NULL,NULL,30,0,'no','no','-',0,0,'-',0,40,0,'','0'),(45,'SID002','SKILLED TECHNICIAN',22,'Days',25,550,0,38,0,'3','-','0','',0,0,0,550,'-',0,0,0,NULL,NULL,NULL,NULL,NULL,550,0,'no','no','-',0,0,'-',0,NULL,0,'30',NULL),(46,'SID003','ENGINEER T&C',22,'Days',75,1650,0,38,0,'3','-','0','',0,0,0,1650,'-',0,0,0,NULL,NULL,NULL,NULL,NULL,1650,0,'no','no','-',0,0,'-',0,NULL,0,'30',NULL),(47,'SID002','SKILLED TECHNICIAN',22,'Days',25,550,0,39,0,'3','-','0','',0,0,0,550,'-',0,0,0,NULL,NULL,NULL,NULL,NULL,550,0,'no','no','-',0,0,'-',0,NULL,0,'30',NULL),(48,'SID003','ENGINEER T&C',22,'Days',75,1650,0,39,0,'3','-','0','',0,0,0,1650,'-',0,0,0,NULL,NULL,NULL,NULL,NULL,1650,0,'no','no','-',0,0,'-',0,NULL,0,'30',NULL),(49,'glo123','jkl',1,'NOS',10,10,0,40,0,'','-','2','',0,0,0,10,NULL,5,0,0,NULL,NULL,'no',NULL,NULL,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(50,'GC_SD_0011','Screw driver',1,'NOS',30,30,0,40,0,'','-','1','',0,0,0,30,NULL,5,0,0,NULL,NULL,'no',NULL,NULL,30,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(51,'GM-1001','Camera accessories\n',2,'PCS',692429.2445,1384858.489,0,37,0,'2','-','3','',0,0,0,1650751.318888,'-',40,0,0,'','395673.854','no',NULL,NULL,1384858.489,0,'yes','no','-',0,132946.414944,'-',265892.829888,1650751.318888,0,'','0');
/*!40000 ALTER TABLE `invoice_items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
