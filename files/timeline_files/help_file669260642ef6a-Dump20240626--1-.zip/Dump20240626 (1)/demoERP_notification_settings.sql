-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notification_settings`
--

DROP TABLE IF EXISTS `notification_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `event` varchar(250) NOT NULL,
  `category` varchar(50) NOT NULL,
  `enable_email` int NOT NULL DEFAULT '0',
  `enable_web` int NOT NULL DEFAULT '0',
  `notify_to_team` text NOT NULL,
  `notify_to_team_members` text NOT NULL,
  `notify_to_terms` text NOT NULL,
  `sort` int NOT NULL,
  `deleted` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `event` (`event`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_settings`
--

LOCK TABLES `notification_settings` WRITE;
/*!40000 ALTER TABLE `notification_settings` DISABLE KEYS */;
INSERT INTO `notification_settings` VALUES (1,'project_created','project',0,1,'','','',1,0),(2,'project_deleted','project',0,1,'','','',2,0),(3,'project_task_created','project',0,1,'','','project_members,task_assignee',3,0),(4,'project_task_updated','project',0,1,'','','task_assignee',4,0),(5,'project_task_assigned','project',0,1,'','','task_assignee',5,0),(7,'project_task_started','project',0,0,'','','',7,0),(8,'project_task_finished','project',0,0,'','','',8,0),(9,'project_task_reopened','project',0,0,'','','',9,0),(10,'project_task_deleted','project',0,1,'','','task_assignee',10,0),(11,'project_task_commented','project',0,1,'','','task_assignee',11,0),(12,'project_member_added','project',0,1,'','','project_members',12,0),(13,'project_member_deleted','project',0,1,'','','project_members',13,0),(14,'project_file_added','project',0,1,'','','project_members',14,0),(15,'project_file_deleted','project',0,1,'','','project_members',15,0),(16,'project_file_commented','project',0,1,'','','project_members',16,0),(17,'project_comment_added','project',0,1,'','','project_members',17,0),(18,'project_comment_replied','project',0,1,'','','project_members,comment_creator',18,0),(19,'project_customer_feedback_added','project',0,1,'','','project_members',19,0),(20,'project_customer_feedback_replied','project',0,1,'','','project_members,comment_creator',20,0),(21,'client_signup','client',0,0,'','','',21,0),(22,'invoice_online_payment_received','invoice',0,0,'','','',22,0),(23,'leave_application_submitted','leave',0,1,'','','leave_manager',23,0),(24,'leave_approved','leave',0,1,'','','leave_applicant,leave_manager',24,0),(25,'leave_assigned','leave',0,1,'','','leave_applicant',25,0),(26,'leave_rejected','leave',0,1,'','','leave_applicant,leave_manager',26,0),(27,'leave_canceled','leave',0,1,'','','',27,0),(28,'ticket_created','ticket',0,0,'','','',28,0),(29,'ticket_commented','ticket',0,1,'','','client_primary_contact,ticket_creator',29,0),(30,'ticket_closed','ticket',0,1,'','','client_primary_contact,ticket_creator',30,0),(31,'ticket_reopened','ticket',0,1,'','','client_primary_contact,ticket_creator',31,0),(32,'estimate_request_received','estimate',0,0,'','','',32,0),(33,'estimate_sent','estimate',0,0,'','','',33,0),(34,'estimate_accepted','estimate',0,0,'','','',34,0),(35,'estimate_rejected','estimate',0,0,'','','',35,0),(36,'new_message_sent','message',0,1,'','','recipient',36,0),(37,'message_reply_sent','message',0,1,'','','recipient',37,0),(38,'invoice_payment_confirmation','invoice',0,0,'','','',22,0),(39,'new_event_added_in_calendar','event',0,1,'','','recipient',39,0),(40,'recurring_invoice_created_vai_cron_job','invoice',0,0,'','','',22,0),(41,'new_announcement_created','announcement',0,1,'','','recipient',41,0),(42,'invoice_due_reminder_before_due_date','invoice',0,0,'','','',22,0),(43,'invoice_overdue_reminder','invoice',0,0,'','','',22,0),(44,'recurring_invoice_creation_reminder','invoice',0,0,'','','',22,0),(45,'generate_employee_payslip','payslip',0,1,'','','employee_payslip_applicant',45,0),(46,'voucher_application_submitted','voucher',1,1,'','','line_manager',46,0),(47,'delivery_chellan_submitted','delivery_chellan',0,1,'','1','',47,0),(48,'purchase_order_due_reminder_before_due_date','purchase_order',0,1,'','15,247','',48,0),(49,'purchase_order_overdue_reminder','purchase_order',0,1,'','15,247','',49,0),(50,'voucher_application_approved_by_manager','voucher',0,1,'','','voucher_application_approved_by_manager,account_department',50,0),(51,'voucher_application_approved_by_accounts','voucher',0,1,'','','voucher_application_approved_by_accounts,voucher_creater,line_manager',51,0),(52,'voucher_application_rejected_by_manager','voucher',0,1,'','','voucher_application_rejected_by_manager',52,0),(53,'voucher_application_rejected_by_accounts','voucher',0,1,'','','voucher_application_rejected_by_accounts,line_manager',53,0),(54,'voucher_application_payment_done','voucher',0,1,'','','line_manager,voucher_creater,account_department',54,0),(55,'voucher_application_resubmitted','voucher',0,1,'','','line_manager',55,0),(56,'voucher_application_payment_in_progress','voucher',0,1,'','','voucher_creater,line_manager,account_department',56,0),(57,'voucher_application_payment_hold','voucher',0,1,'','','voucher_creater,line_manager,account_department',57,0),(58,'voucher_application_payment_received','voucher',0,1,'','','voucher_creater,line_manager,account_department',58,0),(59,'voucher_application_closed','voucher',0,1,'','','voucher_creater,line_manager,account_department',59,0),(60,'group_comment_added','group',0,1,'','','group_members',60,0),(61,'group_comment_replied','group',0,1,'','','group_members,group_comment_creator',61,0),(62,'event_started','event',0,1,'','','recipient',62,0),(63,'leave_approved_by_manager','leave',0,1,'','','leave_applicant,hr_department,admin',63,0),(64,'leave_alternate','leave',0,1,'','','leave_alternate',64,0);
/*!40000 ALTER TABLE `notification_settings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:13
