-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `work_order_items`
--

DROP TABLE IF EXISTS `work_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `quantity` double NOT NULL,
  `unit_type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '',
  `rate` double NOT NULL,
  `total` double NOT NULL,
  `work_order_id` int NOT NULL,
  `category` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `hsn_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `make` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `tax` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `gst` double NOT NULL,
  `tax_amount` double NOT NULL,
  `discount_percentage` double NOT NULL,
  `net_total` double NOT NULL,
  `hsn_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `with_gst` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `quantity_total` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_order_items`
--

LOCK TABLES `work_order_items` WRITE;
/*!40000 ALTER TABLE `work_order_items` DISABLE KEYS */;
INSERT INTO `work_order_items` VALUES (1,'850515- I- testing','Work done',52,'Meters',15000,585000,1,'OFFICE ACCESSORIES','8504','','',18,105300,25,690300,'Power Adapter',0,'yes',780000),(2,'850515- I- testing','Work done',10,'Meters',15000,150000,3,'OFFICE ACCESSORIES','8504','','',18,27000,0,177000,'Power Adapter',0,'yes',150000),(3,'GCT-CF-20/21-045','Fixing the camera for ponamalle site',10,'NOS',250,2500,5,'Camera Fixing','9987','','',18,450,0,2950,'Packing',0,'yes',2500),(4,'GCT-CF-20/21-047','Camera Pole Fixing',4,'NOS',500,1800,5,'Pole Fixing','9987','','',18,324,10,2124,'Services',0,'yes',2000),(5,'850515- I- testing','Work done',52,'Meters',15000,780000,6,'OFFICE ACCESSORIES','8504','','',18,140400,0,920400,'Power Adapter',0,'yes',780000),(6,'850515- I- testing','Work done',1,'Meters',15000,15000,7,'OFFICE ACCESSORIES','8504','','',18,2700,0,17700,'Power Adapter',0,'yes',15000),(7,'GCT-2020-001-TESTING','camera accesoiries',80,'Meters',25,1840,11,'CAMERA ACCESOIRES','8541','','',5,92,8,1932,'solar street light',0,'yes',2000),(8,'GCT-CF-20/21-047','Camera Pole Fixing',89,'NOS',500,40495,11,'Pole Fixing','9987','','',18,7289.1,9,47784.1,'Services',0,'yes',44500),(9,'GCT-2020-001-TESTING','camera accesoiries',150,'Meters',0.127975,19.19625,12,'CAMERA ACCESOIRES','-','','',0,0,0,19.19625,'-',0,'no',19.19625),(10,'GCT-2020-001-TESTING','camera accesoiries',100,'Meters',25,2500,13,'CAMERA ACCESOIRES','8541','','',5,125,0,2625,'solar street light',0,'yes',2500);
/*!40000 ALTER TABLE `work_order_items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
