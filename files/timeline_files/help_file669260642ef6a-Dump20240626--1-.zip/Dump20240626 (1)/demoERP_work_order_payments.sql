-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `work_order_payments`
--

DROP TABLE IF EXISTS `work_order_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_order_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount` double NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method_id` int NOT NULL,
  `note` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `transaction_id` tinytext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `created_by` int DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `work_order_id` int NOT NULL,
  `reference_number` varchar(50) NOT NULL,
  `files` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_order_payments`
--

LOCK TABLES `work_order_payments` WRITE;
/*!40000 ALTER TABLE `work_order_payments` DISABLE KEYS */;
INSERT INTO `work_order_payments` VALUES (1,690300,'2020-04-17',1,'fully Paid',0,NULL,621,'2020-04-17 15:09:07',1,'',''),(2,4500,'2020-05-13',7,'Advance Payment',0,NULL,247,'2020-05-11 17:48:51',5,'',''),(3,574,'2020-05-15',5,'Remaining Payment',0,NULL,247,'2020-05-11 17:49:35',5,'',''),(4,800000,'2020-05-30',7,'partial payment',0,NULL,621,'2020-05-13 14:23:37',6,'',''),(5,50,'2020-06-15',1,'test',0,NULL,1,'2020-06-15 14:11:32',7,'2123','a:1:{i:0;a:2:{s:9:\"file_name\";s:55:\"work_order_payment_file5ee7343c3196f-Screenshot--1-.png\";s:9:\"file_size\";s:6:\"159770\";}}'),(6,49716,'2020-10-01',8,'OK',0,NULL,1,'2020-10-01 08:36:32',11,'yyy','a:1:{i:0;a:2:{s:9:\"file_name\";s:52:\"work_order_payment_file5f759510b4509-Meet-25920.docx\";s:9:\"file_size\";s:5:\"11251\";}}'),(7,0,'2020-10-13',1,'fff',0,NULL,1,'2020-10-13 15:18:46',12,'yyy','a:1:{i:0;a:2:{s:9:\"file_name\";s:57:\"work_order_payment_file5f85c556f1ef1-todays-meeting-.docx\";s:9:\"file_size\";s:4:\"9665\";}}');
/*!40000 ALTER TABLE `work_order_payments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
