-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `created_by` int NOT NULL,
  `location` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `client_id` int NOT NULL DEFAULT '0',
  `labels` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `share_with` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `deleted` int NOT NULL DEFAULT '0',
  `color` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `recurring` int NOT NULL DEFAULT '0',
  `repeat_every` int NOT NULL DEFAULT '0',
  `repeat_type` enum('days','weeks','months','years') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `no_of_cycles` int NOT NULL DEFAULT '0',
  `last_start_date` date DEFAULT NULL,
  `recurring_dates` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `partner_id` int NOT NULL DEFAULT '0',
  `confirmed_by` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `vendor_id` int NOT NULL DEFAULT '0',
  `rejected_by` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `official_leave` int DEFAULT '0',
  `total_days` decimal(5,2) DEFAULT NULL,
  `country` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `branch` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `country_permission` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `company_id` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'Testing','Testing Gems Portal','2020-04-19','2020-04-19','07:30:00','23:00:00',355,'Arni',0,'Mani','',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',1,0.00,NULL,NULL,NULL,'0'),(2,'Gems manager Testing review meeting','about','2020-04-24','2020-04-24','15:55:00','16:00:00',385,'',0,'Kishore technologies','all_clients',0,'#29c2c2',0,1,'months',0,'0000-00-00','',0,'0,962',0,'0',0,0.00,NULL,NULL,NULL,'0'),(3,'Gems manager Testing review meeting','About vendor portal','2020-04-25','2020-04-25','11:00:00','17:00:00',385,'',0,'','all_partners',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0,964,962',0,'0',0,0.00,NULL,NULL,NULL,'0'),(4,'kishore client','a','2020-05-03','2020-05-04','03:00:00','06:00:00',1,'chennai',5,'','contact:962',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,NULL,NULL,NULL,'0'),(5,'kishore events','s','2020-05-03','2020-05-04','02:00:00','21:00:00',1,'chennai',5,'','contact:962',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,NULL,NULL,NULL,'0'),(6,'vendor','s','2020-05-03','2020-05-04','02:00:00','21:00:00',1,'chennaai',0,'','vendor_contact:964',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',214,'0',0,0.00,NULL,NULL,NULL,'0'),(7,'meeting review','sales review','2020-05-10','2020-05-11','00:00:00','00:00:00',621,'coimbatore',9,'','all',0,'#2d9cdb',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,NULL,NULL,NULL,'0'),(8,'Demo Training','Training of product','2020-05-13','2020-05-13','13:00:00','15:30:00',247,'Chennai',1,'Training','',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,NULL,NULL,NULL,'0'),(9,'Demo','Demo','2020-05-15','2020-05-15','14:00:00','14:25:00',247,'Chennai',0,'','',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',216,'0',0,0.00,NULL,NULL,NULL,'0'),(10,'Gems manager Testing review meeting','module testing details','2020-05-19','2020-05-19','12:00:00','02:00:00',385,'chennai',0,'Mani,kishore','all',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,NULL,NULL,NULL,'0'),(11,'example','n','2020-06-15','2020-06-15','00:00:00','23:00:00',1,'',0,'','',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,NULL,NULL,NULL,'0'),(12,'public holiday','public holiday','2020-07-05','2020-07-05','12:00:00','00:00:00',957,'',0,'','all',0,'#d43480',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,NULL,NULL,NULL,'0'),(13,'Testing -dates','to check events','2020-07-07','2020-07-08','10:40:00','19:00:00',621,'',0,'','all',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,NULL,NULL,NULL,'0'),(14,'sample','n','2020-08-07','2020-08-07','00:00:00','00:00:00',5,'',0,'','all',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',1,1.00,'356','01','specific','0'),(15,'test',' g','2020-08-07','2020-08-07','00:00:00','00:00:00',5,'',0,'','vendor_contact:990',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',2,'0',0,0.00,NULL,NULL,NULL,'0'),(16,'testing','testing\n','2020-08-15','2020-08-15','10:45:00','11:00:00',247,'chennai',48,'testing','contact:994',0,'#29c2c2',0,1,'months',0,'0000-00-00','',0,'0,994',0,'0',0,0.00,NULL,NULL,NULL,'0'),(17,'official holidays  Testing','test','2020-07-02','2020-07-02','00:00:00','00:00:00',1,'',0,'','all',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',1,1.00,'','','all','0'),(18,'oficial testing','test','2020-07-05','2020-07-05','00:00:00','00:00:00',1,'',0,'','all',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',1,0.00,'356','01','specific','0'),(19,'ofiicial leave ','test','2020-04-03','2020-04-03','00:00:00','00:00:00',1,'',0,'','all',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',1,1.00,'','','all','0'),(20,'Weekly Meeting ','Weekly follow up meeting','2020-08-04','2020-08-04','01:45:00','03:00:00',999,'Online Meeting',0,'Weekly followup Meeting','member:998,member:957,member:504',0,'#e74c3c',1,1,'weeks',4,'2020-09-01','2020-08-11,2020-08-18,2020-08-25,2020-09-01,',0,'0,504,957',0,'0',0,0.00,'','','','0'),(21,'Training Program on Technology Information Forecasting and assessment Council (TIFAC)','sa','2020-05-08','2020-09-02','10:00:00','13:00:00',1,'d',0,'df','all',0,'#29c2c2',0,1,'months',0,'0000-00-00','',0,'0,504',0,'0',0,0.00,'','','','0'),(22,'Training Program on Technology Information Forecasting and assessment Council (TIFAC)','grrg','2020-09-02','2020-09-02','10:05:00','13:00:00',1,'cxc',0,'','all',0,'#ad159e',1,1,'months',0,'2030-09-02','2020-10-02,2020-11-02,2020-12-02,2021-01-02,2021-02-02,2021-03-02,2021-04-02,2021-05-02,2021-06-02,2021-07-02,2021-08-02,2021-09-02,2021-10-02,2021-11-02,2021-12-02,2022-01-02,2022-02-02,2022-03-02,2022-04-02,2022-05-02,2022-06-02,2022-07-02,2022-08-02,2022-09-02,2022-10-02,2022-11-02,2022-12-02,2023-01-02,2023-02-02,2023-03-02,2023-04-02,2023-05-02,2023-06-02,2023-07-02,2023-08-02,2023-09-02,2023-10-02,2023-11-02,2023-12-02,2024-01-02,2024-02-02,2024-03-02,2024-04-02,2024-05-02,2024-06-02,2024-07-02,2024-08-02,2024-09-02,2024-10-02,2024-11-02,2024-12-02,2025-01-02,2025-02-02,2025-03-02,2025-04-02,2025-05-02,2025-06-02,2025-07-02,2025-08-02,2025-09-02,2025-10-02,2025-11-02,2025-12-02,2026-01-02,2026-02-02,2026-03-02,2026-04-02,2026-05-02,2026-06-02,2026-07-02,2026-08-02,2026-09-02,2026-10-02,2026-11-02,2026-12-02,2027-01-02,2027-02-02,2027-03-02,2027-04-02,2027-05-02,2027-06-02,2027-07-02,2027-08-02,2027-09-02,2027-10-02,2027-11-02,2027-12-02,2028-01-02,2028-02-02,2028-03-02,2028-04-02,2028-05-02,2028-06-02,2028-07-02,2028-08-02,2028-09-02,2028-10-02,2028-11-02,2028-12-02,2029-01-02,2029-02-02,2029-03-02,2029-04-02,2029-05-02,2029-06-02,2029-07-02,2029-08-02,2029-09-02,2029-10-02,2029-11-02,2029-12-02,2030-01-02,2030-02-02,2030-03-02,2030-04-02,2030-05-02,2030-06-02,2030-07-02,2030-08-02,2030-09-02,',0,'0,504,1022,506',0,'0',0,0.00,'','','','0'),(23,'check','check','2020-09-06','2020-09-06','00:00:00','00:00:00',1,'',0,'','member:5',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,'','','','0'),(24,'text','text','2020-09-06','2020-09-06','00:00:00','00:00:00',1,'',0,'','member:5',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,'','','','0'),(25,'Discussion ','description','2020-09-12','2020-09-12','00:00:00','00:00:00',247,'',174,'','contact:1002',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,'','','','0'),(26,'Annual Meet','Annual Meet','2020-09-05','2020-09-07','00:00:00','00:00:00',247,'',0,'','vendor_contact:1003',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',224,'0',0,0.00,'','','','0'),(27,'Glitches ','Software tests','2020-09-14','2020-09-15','11:45:00','16:00:00',1,'',0,'','',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,'','','','0'),(28,'Glitches2','Software test2','2020-09-14','2020-09-15','10:00:00','21:00:00',1,'',0,'','',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,'','','','0'),(29,'Event1','event 1','2020-09-29','2020-09-30','11:00:00','11:00:00',1004,'chennai',0,'testing','',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,'','','','0'),(30,'Actionable points','actions','2020-09-30','2020-09-30','05:00:00','00:00:00',1,'',171,'','',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,'','','','0'),(31,'Event Teting','Test master Data','2020-10-01','2020-10-01','09:00:00','18:00:00',1,'chennai',0,'','all',0,'#83c340',1,1,'months',0,'2030-10-01','2020-11-01,2020-12-01,2021-01-01,2021-02-01,2021-03-01,2021-04-01,2021-05-01,2021-06-01,2021-07-01,2021-08-01,2021-09-01,2021-10-01,2021-11-01,2021-12-01,2022-01-01,2022-02-01,2022-03-01,2022-04-01,2022-05-01,2022-06-01,2022-07-01,2022-08-01,2022-09-01,2022-10-01,2022-11-01,2022-12-01,2023-01-01,2023-02-01,2023-03-01,2023-04-01,2023-05-01,2023-06-01,2023-07-01,2023-08-01,2023-09-01,2023-10-01,2023-11-01,2023-12-01,2024-01-01,2024-02-01,2024-03-01,2024-04-01,2024-05-01,2024-06-01,2024-07-01,2024-08-01,2024-09-01,2024-10-01,2024-11-01,2024-12-01,2025-01-01,2025-02-01,2025-03-01,2025-04-01,2025-05-01,2025-06-01,2025-07-01,2025-08-01,2025-09-01,2025-10-01,2025-11-01,2025-12-01,2026-01-01,2026-02-01,2026-03-01,2026-04-01,2026-05-01,2026-06-01,2026-07-01,2026-08-01,2026-09-01,2026-10-01,2026-11-01,2026-12-01,2027-01-01,2027-02-01,2027-03-01,2027-04-01,2027-05-01,2027-06-01,2027-07-01,2027-08-01,2027-09-01,2027-10-01,2027-11-01,2027-12-01,2028-01-01,2028-02-01,2028-03-01,2028-04-01,2028-05-01,2028-06-01,2028-07-01,2028-08-01,2028-09-01,2028-10-01,2028-11-01,2028-12-01,2029-01-01,2029-02-01,2029-03-01,2029-04-01,2029-05-01,2029-06-01,2029-07-01,2029-08-01,2029-09-01,2029-10-01,2029-11-01,2029-12-01,2030-01-01,2030-02-01,2030-03-01,2030-04-01,2030-05-01,2030-06-01,2030-07-01,2030-08-01,2030-09-01,2030-10-01,',0,'0,506,1024',227,'0',0,0.00,'','','','0'),(32,'Follow up Meeting ','Follow Up ','2020-10-01','2020-10-01','20:00:00','21:00:00',504,'Gems Meeting Room-01',1,'Gems Meeting Room-01','contact:959',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,'','','','0'),(33,'website development','website','2020-10-20','2020-10-25','13:10:00','13:15:00',1022,'',0,'website','all',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0,506',0,'0',0,0.00,'','','','0'),(34,'purchase ','tools','2020-10-20','2020-10-31','10:00:00','17:00:00',1022,'sriperumbudur',0,'','all',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0,506',0,'0',0,0.00,'','','','0'),(35,'Meetings','Meetings- general timings','2020-12-22','2020-12-22','13:00:00','15:00:00',621,'',0,'','',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,'','','','0'),(36,'mou signing','mou signed @college\n','2021-04-03','2021-04-03','01:20:00','08:00:00',621,'',0,'website','',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,'','','','0'),(37,'trainig program','event','2021-07-30','2021-07-30','00:00:00','00:00:00',1035,'',0,'','',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,'','','','0'),(38,'po discussion','po discussion','2021-04-01','2021-04-01','09:00:00','12:00:00',621,'Saidapet',0,'','all',0,'#e74c3c',1,1,'months',2,'2021-06-01','2021-05-01,2021-06-01,',0,'0',231,'0,957',0,0.00,'','','','0'),(39,'po disussion','po discussion','2021-04-01','2021-04-02','10:00:00','12:00:00',1035,'saidapet',0,'','',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,'','','','0'),(40,'hi','hii','0000-00-00','0000-00-00','10:17:00','16:09:00',1,'chennai',0,'gh','',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',1,3.00,'','','all','0'),(41,'Testing','hij','2024-05-23','2024-05-30','01:00:00','01:00:00',1,'chennai',0,'Training','',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',1,7.00,'','','all','0'),(42,'Testing','hi','2024-06-08','2024-06-15','00:00:00','00:00:00',1,'chennai',0,'Mani','',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',1,7.00,'','','all','0'),(43,'Akalyaa','Testing','2024-06-08','2024-06-21','02:00:00','01:05:00',1,'1',0,'Kishore technologies','all_partners',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',1,12.00,'356','CR00901','specific','0'),(44,'Testing','1','2024-06-05','2024-06-25','14:00:00','00:50:00',1,'chennai',0,'Kishore technologies','',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',1,18.00,'','','all','0'),(45,'Akalyaa','TEsting','2024-03-25','2024-08-22','00:00:00','00:00:00',1,'chennai',0,'Gems Meeting Room-01','all_partners',0,'#83c340',0,1,'months',0,'0000-00-00','',0,'0',0,'0',0,0.00,'','','','0');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:16
