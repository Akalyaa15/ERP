-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cheque_handler`
--

DROP TABLE IF EXISTS `cheque_handler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cheque_handler` (
  `id` int NOT NULL AUTO_INCREMENT,
  `member_type` varchar(45) DEFAULT NULL,
  `member_id` int DEFAULT NULL,
  `bank_name` varchar(100) NOT NULL,
  `account_number` varchar(45) DEFAULT NULL,
  `cheque_number` varchar(45) DEFAULT NULL,
  `cheque_category_id` int DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `files` mediumtext NOT NULL,
  `issue_date` date NOT NULL,
  `drawn_on` varchar(45) DEFAULT NULL,
  `valid_upto` varchar(45) DEFAULT NULL,
  `status_id` varchar(45) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `payment_mode` varchar(45) NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_activity_user` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cheque_handler`
--

LOCK TABLES `cheque_handler` WRITE;
/*!40000 ALTER TABLE `cheque_handler` DISABLE KEYS */;
INSERT INTO `cheque_handler` VALUES (1,'tm',247,'2','4333df','444',1,6000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:56:\"note_file5e9a901df30b4-Background-Screen-Elcot-P-VII.jpg\";s:9:\"file_size\";s:7:\"1318302\";}}','2020-04-17','2020-04-17','2020-07-15','3','bb',0,NULL,NULL,'cheque',NULL,NULL),(2,'tm',621,'2','02320asdaq1004574','0009scsc60',1,12025,'a:1:{i:0;a:2:{s:9:\"file_name\";s:119:\"note_file5e9a908e6b0fa-Pelikan_Office_Automation_Pvt._Ltd.-Gemicates_Technologies_Private_Limited-Purchase_Orders-1.pdf\";s:9:\"file_size\";s:6:\"101835\";}}','2020-04-18','2020-04-19','','1','wef',0,NULL,NULL,'cheque',NULL,NULL),(3,'tm',356,'15','635874125201','235147',3,18000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:57:\"note_file5eb94f3832c83-Bank-statement-ICICI-2018-2019.pdf\";s:9:\"file_size\";s:6:\"252468\";}}','2020-05-10','2020-05-11','2020-08-09','2','Site income',0,NULL,NULL,'cheque',NULL,NULL),(4,'tm',537,'15','25552055','2506',3,25000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:103:\"note_file5ebd0fae855d8-Black_T_Electrotech-Gemicates_Technologies_Private_Limited-Purchase_Orders-7.pdf\";s:9:\"file_size\";s:6:\"101182\";}}','2020-05-14','2020-05-21','2020-08-19','2','testing',0,NULL,NULL,'cheque',NULL,NULL),(5,'tm',418,'11','345','555',1,7000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:41:\"note_file5ee736566e183-Screenshot--2-.png\";s:9:\"file_size\";s:6:\"152376\";}}','2020-06-15','','','2','n',0,NULL,NULL,'cheque',NULL,NULL),(6,'tm',985,'14','-1','123',1,3000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:43:\"note_file5f75d1d7a037a-todays-meeting-.docx\";s:9:\"file_size\";s:4:\"9665\";}}','2020-10-01','2020-10-01','2020-12-30','1','uu',0,NULL,NULL,'cheque','2020-10-01 12:55:51',1),(7,'others',0,'2','35325','4353212',1,2355433,'a:1:{i:0;a:2:{s:9:\"file_name\";s:91:\"note_file5f93c88811790-Danway-Gemicates_Technologies_Private_Limited-Proforma_Invoice-1.pdf\";s:9:\"file_size\";s:6:\"112325\";}}','2020-10-24','','','1','cgdf',0,'mr','r','cheque','2020-10-24 06:24:08',247),(8,'tm',418,'4','66459962','545454',1,200000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:47:\"note_file5fa4ea9850a83-Form_DPT-3-Gemicates.pdf\";s:9:\"file_size\";s:6:\"310337\";}}','2020-11-06','2020-11-07','2021-02-05','1','testing',0,NULL,NULL,'cheque','2020-11-06 06:18:00',1024),(9,'om',966,'11','434556829087676','1234567890',1,90000,'a:1:{i:0;a:2:{s:9:\"file_name\";s:53:\"note_file665aac17a06a3-Gems-Manager-Gemicates-1-.xlsx\";s:9:\"file_size\";s:5:\"13900\";}}','2024-06-01','2024-06-02','2024-08-31','3','Akalyaa',0,NULL,NULL,'dd','2024-06-01 05:05:27',1);
/*!40000 ALTER TABLE `cheque_handler` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
