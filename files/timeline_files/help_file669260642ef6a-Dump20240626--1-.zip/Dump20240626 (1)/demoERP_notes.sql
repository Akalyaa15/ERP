-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_by` int NOT NULL,
  `created_at` datetime NOT NULL,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `project_id` int NOT NULL DEFAULT '0',
  `client_id` int NOT NULL DEFAULT '0',
  `user_id` int NOT NULL DEFAULT '0',
  `labels` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `files` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `vendor_id` int NOT NULL DEFAULT '0',
  `company_id` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` VALUES (1,1,'2020-05-02 17:05:04','hikvision','b',3,0,0,'','a:2:{i:0;a:2:{s:9:\"file_name\";s:50:\"note_file6655c666f20ae-Gems-Manager-Gemicates.xlsx\";s:9:\"file_size\";s:5:\"14393\";}i:1;a:2:{s:9:\"file_name\";s:37:\"note_file6655b241b4455-Untitled-2.odt\";s:9:\"file_size\";s:5:\"27832\";}}',0,0,'0'),(2,269,'2020-05-07 11:42:14','testing','hiii',0,0,0,'','a:0:{}',0,0,'0'),(3,247,'2020-05-12 12:35:11','Trading Details','Trading want to start after the invoices',0,1,0,'Important,required','a:0:{}',0,0,'0'),(4,247,'2020-05-15 14:42:08','Pricing','1TB HD - 1758',0,0,0,'Pricing','a:0:{}',0,216,'0'),(5,15,'2020-05-19 12:40:55','date','fd',0,14,0,'','a:0:{}',0,0,'0'),(6,957,'2020-07-06 10:42:16','gggf','bbbmmbmbmmm',0,0,0,'','a:0:{}',0,0,'0'),(7,621,'2020-07-07 15:23:29','notes -imp','Facebook\nSocial Network social@gemicates.com socialnetworks Social Network http://www.facebook.com/gemicates \n2019-07-23 14:57:00 Twitter social@gemicates.com socialnetworks Social Network  \n2019-07-23 14:57:00 linkedin social@gemicates.com socialnetworks Social Network  \n2019-07-23 14:57:00 Google Gmail\nLogin Credential gemicates@gmail.com Gemicates@2014 Mail Account https://mail.google.com/ \n2019-07-23 14:57:00 Instagram gemicates socialnetworks Social Network  \n2019-07-23 14:57:00 Pinterest Gemicates socialnetworks Social Network',0,0,0,'','a:0:{}',0,0,'0'),(8,621,'2020-07-07 15:27:27','notes  i','Instagram gemicates socialnetworks Social Network  \n2019-07-23 14:57:00 Pinterest Gemicates socialnetworks Social Network  \n2019-07-23 14:57:00 Flickr gemicates ultron182015 Social Network  \n2019-07-23 14:57:00 Youtube gemicates@gmail.com ultron182015 Social Network ',0,0,0,'case sensitive','a:1:{i:0;a:2:{s:9:\"file_name\";s:86:\"note_file5f044dda512d4-VENDOR-DETAILS-NEWLY-UPDATED--T--SHIRTS-&SAFETY-EQUIPMENTS.xlsx\";s:9:\"file_size\";s:5:\"25407\";}}',0,0,'0'),(9,621,'2020-07-07 15:53:32','passwords','Instagram gemicates socialnetworks Social Network  \n2019-07-23 14:57:00 Pinterest Gemicates socialnetworks Social Network  \n2019-07-23 14:57:00 Flickr gemicates ultron182015 Social Network  \n2019-07-23 14:57:00 Youtube gemicates@gmail.com ultron182015 Social Network ',0,0,0,'case sensitive','a:0:{}',0,0,'0'),(10,621,'2020-07-07 15:55:21','Vendor follow up for seal & Stamp','vendor details',0,0,0,'Important,very important file','a:1:{i:0;a:2:{s:9:\"file_name\";s:42:\"note_file5f044d914a9a7-vendor-details.xlsx\";s:9:\"file_size\";s:5:\"14937\";}}',0,0,'0'),(11,1004,'2020-09-29 09:21:57','Test the Modules','testing done',0,0,0,'Proof test1','a:0:{}',0,0,'0'),(12,1,'2020-09-30 09:52:29','Note1','noted',0,171,0,'Important','a:0:{}',0,0,'0'),(13,1,'2020-09-30 10:13:13','test vendor note','tested',0,0,0,'Important','a:1:{i:0;a:2:{s:9:\"file_name\";s:43:\"note_file5f745a3980e82-todays-meeting-.docx\";s:9:\"file_size\";s:4:\"9665\";}}',0,226,'0'),(14,1,'2020-10-01 10:47:39','Test1','Test notes is important',0,0,0,'Important','a:1:{i:0;a:2:{s:9:\"file_name\";s:38:\"note_file5f75b3cb297f8-Meet-25920.docx\";s:9:\"file_size\";s:5:\"11251\";}}',0,227,'0'),(15,1,'2020-10-13 16:01:00','Testnote','yyyyy',0,183,0,'Important','a:1:{i:0;a:2:{s:9:\"file_name\";s:43:\"note_file5f85cf3cb4a2c-todays-meeting-.docx\";s:9:\"file_size\";s:4:\"9665\";}}',0,0,'0'),(16,1024,'2020-11-06 09:11:50','audit','ACTING\n',0,0,0,'COMMERICAL','a:0:{}',0,0,'0'),(17,1,'2020-12-11 11:20:25','gems company','hai',0,0,0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:34:\"note_file5fd355f999a4f-example.png\";s:9:\"file_size\";s:6:\"352132\";}}',1,0,'CR002'),(18,621,'2020-12-23 06:30:45','notes-examplr','purchase@admin  passwords\nLynk\nImportant Cargo purchase@gemicates.com lynkpurchase Materials Delivery - - - \n2019-11-05 16:50:20 Zoho Mail Login\nZoho Mail Credential purchase@gemicates.com purchase@admin Zoho Mail Credential https://www.zoho.com/mail/ - - \n2019-11-16 18:26:14 Hik Partner\nLogin Credential purchase@gemicates.com purchase@Admin2020 HikPartner Mobile Application HikPartner - - \n1-3 / 3 (81)',0,0,0,'very important file,case sensitive','a:0:{}',0,0,'0'),(19,621,'2020-12-25 11:54:47','important','',0,0,0,'','a:0:{}',0,0,'0'),(20,621,'2021-04-02 06:26:17','Website Development','Gems Manager URL:\nhttps://play.google.com/store/apps/details?id=com.gemicates.com.gem_portal&hl=en\n\n',0,0,0,'case sensitive','a:1:{i:0;a:2:{s:9:\"file_name\";s:59:\"note_file6066b90942c6d-TIME-SHEET_SE---CT-GCT-TS-SE-013.pdf\";s:9:\"file_size\";s:6:\"522119\";}}',0,0,'0'),(21,1035,'2021-04-02 07:17:33','gemicates','',0,0,0,'','a:0:{}',1,0,'0'),(22,1,'2024-05-29 05:02:10','Testing','hi',0,0,0,'Important','a:0:{}',0,0,'0'),(23,1,'2024-05-30 09:15:21','hi','Testing',0,0,0,'Important','a:1:{i:0;a:2:{s:9:\"file_name\";s:39:\"note_file665843a984d40-Adhoc-Form-1.pdf\";s:9:\"file_size\";s:6:\"377626\";}}',0,0,'0'),(24,1,'2024-06-01 09:34:20','Testing','hi',0,0,0,'','a:1:{i:0;a:2:{s:9:\"file_name\";s:53:\"note_file665aeb1cdfcb8-Gems-Manager-Gemicates-1-.xlsx\";s:9:\"file_size\";s:5:\"13900\";}}',0,0,'0'),(25,1,'2024-06-01 12:15:04','Testing','hi',0,0,0,'Important','a:1:{i:0;a:2:{s:9:\"file_name\";s:53:\"note_file665b10c80e192-Gems-Manager-Gemicates-1-.xlsx\";s:9:\"file_size\";s:5:\"13900\";}}',0,0,'0'),(26,1,'2024-06-01 12:43:38','IITM GROUP','HI',0,0,0,'Important','a:0:{}',0,0,'0'),(27,1,'2024-06-08 10:12:38','2','2',0,0,0,'','a:0:{}',0,0,'0'),(28,1,'2024-06-10 05:42:01','Testingdddddd','w',0,0,0,'Important','a:1:{i:0;a:2:{s:9:\"file_name\";s:73:\"note_file6666922908b03-note_file6655c666f20ae-Gems-Manager-Gemicates.xlsx\";s:9:\"file_size\";s:5:\"14393\";}}',0,0,'0'),(29,1,'2024-06-15 04:41:46','Testing','hi',0,0,0,'Important','a:0:{}',0,0,'0'),(30,1,'2024-06-21 05:10:50','Testing','1',0,0,0,'Important','a:0:{}',0,0,'0'),(31,1,'2024-06-21 06:02:28','Testing','Testing',0,0,0,'Important','a:0:{}',0,0,'0'),(32,1,'2024-06-21 08:39:07','Testing','1234',0,0,0,'','a:0:{}',0,0,'0'),(33,1,'2024-06-21 10:27:07','Testing','12',0,0,0,'Important','a:1:{i:0;a:2:{s:9:\"file_name\";s:53:\"note_file6675557b9adf8-Gems-Manager-Gemicates-7-.xlsx\";s:9:\"file_size\";s:5:\"14641\";}}',0,0,'0'),(34,1,'2024-06-22 06:16:33','Testing','1',0,0,0,'','a:0:{}',0,0,'0'),(35,1,'2024-06-25 12:19:41','Testing','1234',0,0,0,'Important','a:1:{i:0;a:2:{s:9:\"file_name\";s:54:\"note_file667ab5ddd7f3a-LAMP-Installation-Procedure.txt\";s:9:\"file_size\";s:4:\"5128\";}}',0,0,'0'),(36,1,'2024-06-26 06:55:56','Testing','testing',0,0,0,'Important','a:1:{i:0;a:2:{s:9:\"file_name\";s:54:\"note_file667bbb7cd1381-LAMP-Installation-Procedure.txt\";s:9:\"file_size\";s:4:\"5128\";}}',0,0,'0');
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
