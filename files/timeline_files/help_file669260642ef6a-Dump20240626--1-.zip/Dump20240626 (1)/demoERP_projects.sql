-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `start_date` date DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `client_id` int NOT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` int NOT NULL DEFAULT '0',
  `status` enum('open','completed','hold','canceled') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'open',
  `labels` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `price` double NOT NULL DEFAULT '0',
  `starred_by` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `estimate_id` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `clone_project_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (1,'Bug clearance project','','2020-04-18','2020-04-30',3,'2020-04-18',506,'open','',0,'',0,0,0),(2,'Android app development','','2020-04-22','2020-04-30',5,'2020-04-22',962,'open','App',60000,'',0,0,0),(3,'Web  site Research','about Testing','2020-04-25','2020-04-26',6,'2020-04-25',385,'open','',12000,'',0,0,0),(4,'Web  site Research','about Testing','2020-04-25','2020-04-26',6,'2020-05-02',1,'open','',12000,',:1:',0,0,0),(5,'Training the Gems Manager portal','Project Module \nTask Module','2020-09-29','2020-10-09',3,'2020-05-07',247,'open','quote',30000,'',0,0,0),(6,'Checking bugs in gems Portal','','2019-09-07','2020-05-20',3,'2020-05-09',15,'open','',0,'',0,0,0),(7,'Energy','testing procedure \n\\','2020-05-09','2020-05-16',8,'2020-05-09',1,'open','',0,'',0,0,0),(8,'hello development','asd','2020-05-09','2020-05-16',8,'2020-05-09',1,'open','',0,',:506:',0,0,0),(9,'Software development','asd','2020-05-09','2020-05-16',2,'2020-05-09',1,'open','',0,'',0,0,0),(10,'CAmera fixing-testing','to fix poles & camera','2020-05-11','2020-05-30',9,'2020-05-11',621,'open','',50000,'',0,0,0),(11,'Supply of Test Kit CMC356 on Rental -testing','test kits','2020-05-11','2020-05-20',10,'2020-05-11',621,'open','',52000,'',0,0,0),(12,'hello app','testing module','2020-05-18','2020-05-23',10,'2020-05-18',385,'open','App',12000,'',0,0,0),(13,'task date checking','need to check the dates the task assigned','2020-05-18','2020-05-20',3,'2020-05-19',621,'open','',0,'',0,0,0),(14,'example project','n','2020-06-15','2020-06-15',158,'2020-06-15',1,'open','',0,'',0,0,0),(15,'US NAVY','','2020-07-01','2020-07-01',163,'2020-07-01',247,'open','',0,'',0,0,0),(16,'test pro','qwe','2020-07-04','2020-07-05',162,'2020-07-04',1,'open','',1200,'',0,0,0),(17,'Website development','','2020-07-04','2020-07-09',8,'2020-07-04',506,'open','website',0,'',0,0,0),(18,'Energy Project','T&C','2020-07-07','2020-07-14',3,'2020-07-07',1,'open','',0,'',0,0,0),(19,'Software development','asd','2020-05-09','2020-05-16',163,'2020-07-07',1,'open','',0,'',0,0,0),(20,'Software development','asd','2020-05-09','2020-05-16',7,'2020-07-07',1,'open','',0,'',0,0,0),(21,'Website development','','2020-07-04','2020-07-09',8,'2020-07-10',506,'open','',0,'',0,0,0),(22,'BUGS CHECKING IN DEMO PORTAL','TO CHECKS BUGS','2020-07-10','2020-07-11',4,'2020-07-11',621,'open','',0,'',0,0,0),(23,'Testing','Testing','2020-07-14','2020-07-14',4,'2020-07-14',621,'open','',0,'',0,0,0),(24,'Bug clearance project clone','','2020-04-18','2020-04-30',168,'2020-07-24',5,'open','',0,'',0,0,0),(25,'value for money','','2020-07-24','2020-07-25',10,'2020-07-24',1,'open','',0,'',0,0,0),(26,'Website development clone','','2020-07-04','2020-07-09',5,'2020-08-07',5,'open','website',0,'',0,0,17),(27,'Website development','','2020-07-04','2020-07-09',8,'2020-08-13',506,'open','website',0,'',0,0,17),(28,'commissioning','protection relay','2020-08-14','2020-08-30',165,'2020-08-14',504,'open','switchgear',120000,'',0,0,0),(29,'Website development 123','','2020-07-04','2020-07-09',8,'2020-08-15',247,'open','website',0,'',0,0,17),(30,'Website development','ddf','2020-07-04','2020-07-09',8,'2020-08-18',12,'open','website',0,'',0,0,17),(31,'Website development testing','','2020-07-04','2020-07-09',170,'2020-08-21',247,'open','website',0,'',0,0,17),(32,'Chennai','',NULL,NULL,12,'2020-09-03',1,'open','',0,'',0,0,0),(33,'Chennai test','sdd','2020-09-03','2020-09-03',156,'2020-09-03',12,'open','App',0,'',0,0,0),(34,'Website development','','2020-07-04','2020-07-09',8,'2020-09-04',1,'open','website',0,'',0,0,17),(35,'Quotation Creation','','2020-09-11','2020-09-11',173,'2020-09-11',247,'open','quote',0,'',0,0,0),(36,'Invoice Creation','','2020-09-12','2020-09-12',173,'2020-09-11',247,'open','',0,'',0,0,0),(37,'Posts upload ','',NULL,NULL,174,'2020-09-12',247,'open','',0,'',0,0,0),(38,'Quotation Creation','',NULL,NULL,173,'2020-09-12',247,'open','',0,'',0,0,0),(39,'Gems manager Testing','Office on the Cloud Software development','2020-09-12','2020-09-19',3,'2020-09-13',1,'open','testing',14000,'',0,0,0),(40,'testing','testing','2020-09-14','2020-09-15',165,'2020-09-14',504,'open','testing',10000,'',0,0,0),(41,'SE','T&C','2020-07-07','2020-07-14',3,'2020-09-14',504,'open','',0,'',0,0,18),(42,'Relay retrofit ','Relay retrofit man power supply for ABB','2020-09-15','2021-09-30',163,'2020-09-14',504,'open','Relay Retrofit',10000000,'',0,0,0),(43,'Templates','prog','2020-09-28','2020-10-09',2,'2020-09-28',1,'open','',0,'',0,0,0),(44,'Electrical I&C','Electrical Maintenance','2020-09-28','2020-09-30',1,'2020-09-28',1,'open','switchgear',14000,'',0,0,0),(45,'Pro11','sss','2020-09-29','2020-10-09',178,'2020-09-29',1,'open','',0,'',0,0,0),(46,'REtrofit Job','JD','2020-10-11','2020-10-18',12,'2020-10-10',1,'open','switchgear',100000,'',0,0,0),(47,'Test14','aaa','2020-10-13','2020-11-08',2,'2020-10-13',1,'open','Relay Retrofit',30000,'',0,0,0),(48,'Test Project','Des','2020-10-13','2020-10-23',183,'2020-10-13',1,'open','testing',30000,'',0,0,0),(49,'TESTING NOTE','TESTING','2020-10-15','2020-10-30',181,'2020-10-15',504,'open','testing',150,'',0,0,0),(50,'website development','','2020-10-20','2020-10-31',8,'2020-10-20',969,'open','',0,'',0,0,0),(51,'website devolopment','website','2020-10-20','2020-10-31',8,'2020-10-20',969,'open','',0,',:969:',0,0,0),(52,'Secretarial Work','To guide the Work Flow to the New Joinee\n','2020-11-28','2020-11-28',191,'2020-11-28',1028,'open','',0,'',0,0,0),(53,'Example projects','projectes,testing ,adding task','2020-12-19','2020-12-31',3,'2020-12-19',621,'open','',0,'',0,0,0),(54,'To learn and make a documentation about gems manager','to prepare gems manager broucher, PPT, promotion documents and marketing materials','2021-03-25','2021-03-31',3,'2021-03-25',1,'open','',2350,'',0,0,0),(55,'bug clearance project','clearance of bug','2021-05-19','2021-05-28',3,'2021-05-19',1,'open','testing',150000,'',0,0,0),(56,'Sr.Testing & Commissioning Engineer Suppy','','2021-06-24','2021-07-01',181,'2021-06-24',1,'open','Relay Retrofit',14000,'',20,0,0),(57,'Retro Solutions','','2021-06-25','2021-07-02',1,'2021-06-25',1,'open','',0,'',21,0,0),(58,'hi','GHI','2024-06-01','2024-06-20',164,'2024-06-01',1,'open','App',78999,'',0,0,0),(59,'Testing','Testing','2024-06-06','2024-06-13',164,'2024-06-07',1,'open','website',121,'',0,0,0),(60,'Akalyaa','Testing','2024-06-07','2024-06-07',164,'2024-06-07',1,'open','quote',1200,'',0,0,0),(61,'Testing','Testing','2024-06-07','2024-06-07',164,'2024-06-07',1,'open','quote',12000,'',0,0,0),(62,'TESTING','','2024-06-14','2024-06-21',160,'2024-06-07',1,'open','quote',1200,'',0,0,0),(63,'IITM GROUP','2','2024-06-21','2024-06-28',164,'2024-06-07',1,'open','',2,'',0,0,0),(64,'Testing','124','2024-06-13','2024-06-19',164,'2024-06-07',1,'open','quote',12000,'',0,0,0),(65,'Akalyaa','12345','2024-06-07','2024-06-07',164,'2024-06-07',1,'open','quote',12000,'',0,0,0),(66,'Testing','hii','2024-06-14','2024-06-21',164,'2024-06-07',1,'open','quote',12000,'',0,0,0),(67,'Testing','Testing','2024-06-07','2024-06-07',164,'2024-06-07',1,'open','quote',12000,'',0,0,0),(68,'Testing','11','2024-06-28','2024-07-04',10,'2024-06-21',1,'open','testing',121,'',0,0,0),(69,'Testing','1234','2024-06-21','2024-07-05',164,'2024-06-21',1,'open','quote',1235,'',0,0,0),(70,'Testing','12345','2024-06-22','2024-06-28',164,'2024-06-21',1,'open','',121,'',0,0,0),(71,'Testing','1','2024-06-20','2024-06-27',164,'2024-06-21',1,'open','',1243,'',0,0,0),(72,'Testing','1234','2024-06-13','2024-06-27',9,'2024-06-21',1,'open','',3,'',0,0,0),(73,'Testing','1','2024-06-11','2024-07-03',164,'2024-06-22',1,'open','',12000,'',0,0,0),(74,'12345','1','2024-06-22','2024-06-22',164,'2024-06-22',1,'open','testing',12000,'',0,0,0),(75,'Akalyaa','1','2024-06-03','2024-06-27',10,'2024-06-22',1,'open','1',121,'',0,0,0);
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:16
