-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `leave_applications`
--

DROP TABLE IF EXISTS `leave_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_applications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `leave_type_id` int NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `total_hours` decimal(7,2) NOT NULL,
  `total_days` decimal(5,2) NOT NULL,
  `applicant_id` int NOT NULL,
  `reason` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `status` enum('pending','approved','rejected','canceled','approve_by_manager') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL,
  `created_by` int NOT NULL,
  `checked_at` datetime DEFAULT NULL,
  `checked_by` int NOT NULL DEFAULT '0',
  `deleted` int NOT NULL DEFAULT '0',
  `line_manager` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `manager_remarks` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `hr_remarks` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `alternate_id` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `leave_type_id` (`leave_type_id`),
  KEY `user_id` (`applicant_id`),
  KEY `checked_by` (`checked_by`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_applications`
--

LOCK TABLES `leave_applications` WRITE;
/*!40000 ALTER TABLE `leave_applications` DISABLE KEYS */;
INSERT INTO `leave_applications` VALUES (1,5,'2020-04-15','2020-04-15',9.00,1.00,621,'TESTING','approved','2020-04-16 14:49:48',0,'2020-07-11 13:26:59',621,0,'0','','',0),(2,2,'2020-04-01','2020-04-01',9.00,1.00,247,'Due to Fever','approved','2020-05-15 15:30:53',0,'2020-05-15 15:32:27',247,0,'0','','',0),(3,4,'2020-04-10','2020-04-15',54.00,6.00,247,'Sister Marriage function','approved','2020-05-15 15:31:36',0,'2020-05-15 15:32:55',247,0,'0','','',0),(4,3,'2020-04-28','2020-04-28',3.00,0.33,247,'Want to go to hospital for checkup','rejected','2020-05-15 15:32:11',0,'2020-05-15 15:32:36',247,0,'0','','',0),(5,1,'2020-04-28','2020-04-28',9.00,1.00,268,'personal work','approved','2020-05-15 15:33:48',247,'2020-05-15 15:33:48',247,0,'0','','',0),(6,1,'2020-05-19','2020-05-19',9.00,1.00,15,'PL','canceled','2020-05-19 13:09:34',0,'2020-05-19 13:10:21',15,0,'0','','',0),(7,4,'2020-05-19','2020-05-25',63.00,7.00,15,'pl','rejected','2020-05-19 13:12:25',0,'2020-09-10 16:08:38',504,0,'0','','',0),(8,5,'2020-05-19','2020-05-19',2.00,0.22,15,'pl','approved','2020-05-19 13:12:51',0,'2020-05-19 13:24:38',15,0,'0','','',0),(9,3,'2020-05-19','2020-05-19',9.00,1.00,15,'pl','rejected','2020-05-19 13:13:19',0,'2020-05-19 13:24:45',15,0,'0','','',0),(10,2,'2020-05-19','2020-05-22',36.00,4.00,15,'sl','pending','2020-05-19 13:13:49',0,'2020-05-19 13:24:45',0,0,'0','','',0),(11,1,'2020-05-19','2020-05-19',9.00,1.00,15,'gh','approved','2020-05-19 13:45:03',15,'2020-05-19 13:45:03',15,0,'0','','',0),(12,3,'2020-05-19','2020-05-19',9.00,1.00,15,'dd','approved','2020-05-19 13:46:20',15,'2020-05-19 13:46:20',15,0,'0','','',0),(13,1,'2020-04-07','2020-05-06',270.00,30.00,5,'text','approved','2020-06-15 13:42:04',1,'2020-06-15 13:42:04',1,0,'0','','',0),(14,1,'2020-07-09','2020-07-09',9.00,1.00,506,'Personal','approved','2020-07-04 19:36:02',0,'2020-08-21 11:31:56',504,0,'0','','',0),(15,5,'2020-07-01','2020-07-01',3.00,0.33,621,'permission','canceled','2020-07-06 16:00:11',0,'2020-07-06 16:00:18',621,0,'0','','',0),(16,1,'2020-07-22','2020-07-22',9.00,1.00,12,'sa','approved','2020-07-22 11:22:09',1,'2020-07-22 11:22:09',1,0,'0','','',0),(17,1,'2020-07-01','2020-07-17',153.00,17.00,504,'Personal','pending','2020-08-22 11:53:15',0,'2020-05-19 13:24:45',0,1,'0','','',0),(18,3,'2020-07-01','2020-07-17',153.00,17.00,999,'Personal Leave','approved','2020-08-22 11:54:57',0,'2020-08-22 11:56:06',504,0,'0','','',0),(19,3,'2020-09-03','2020-09-03',9.00,1.00,999,'personal work ','approved','2020-09-02 16:37:26',0,'2020-09-10 16:08:54',504,0,'0','','',0),(20,4,'2020-09-03','2020-09-03',9.00,1.00,504,'test\n','rejected','2020-09-03 17:15:53',0,'2020-09-03 17:16:40',504,0,'0','','',0),(21,1,'2020-09-11','2020-09-11',9.00,1.00,999,'testing','pending','2020-09-10 16:05:39',0,'2020-05-19 13:24:45',0,1,'0','','',0),(22,1,'2020-09-10','2020-09-10',9.00,1.00,12,'ggh','pending','2020-09-11 13:25:06',0,'2020-05-19 13:24:45',0,0,'1','','',0),(23,5,'2020-09-05','2020-09-05',9.00,1.00,12,'dgzd dds df ','pending','2020-09-11 13:29:21',0,'2020-05-19 13:24:45',0,0,'1','','',0),(24,5,'2020-09-11','2020-09-11',9.00,1.00,12,'dvd','','2020-09-11 13:31:55',0,'2020-05-19 13:24:45',5,0,'5','fsfg cscrr','',269),(25,5,'2020-09-11','2020-09-11',9.00,1.00,12,'fd fg fd ffgfgfgfg','','2020-09-11 13:37:09',0,'2020-05-19 13:24:45',5,0,'5','vddg  gd dgd gs  gfgf gf','',269),(26,4,'2020-09-11','2020-09-11',9.00,1.00,12,'dfdd','','2020-09-11 13:49:44',0,'2020-05-19 13:24:45',5,0,'5','asassa','',624),(27,1,'2020-09-11','2020-09-11',9.00,1.00,12,'fff fd fsfv fsfs fgg sgfgff ','approve_by_manager','2020-09-11 13:53:25',0,'2020-05-19 13:24:45',5,0,'5','c df sd fdfsggf gfgfgff','',269),(28,1,'2020-09-12','2020-09-12',9.00,1.00,957,'REASON TRIP','approve_by_manager','2020-09-11 17:01:56',0,'2020-05-19 13:24:45',504,0,'504','you will be appointed during Santhoush vacation for his pending jobs ','',999),(29,4,'2020-09-12','2020-09-12',9.00,1.00,999,'Annual Leave ','approved','2020-09-12 05:42:38',0,'2020-09-12 05:47:21',504,0,'504','assigned for this day ','',957),(30,1,'2020-07-21','2020-07-21',9.00,1.00,12,'xz','approved','2020-09-12 07:48:10',0,'2020-09-12 07:51:14',1,0,'5','sd dfs ds','',269),(31,1,'2020-09-12','2020-09-12',9.00,1.00,1,'vs','pending','2020-09-12 14:13:51',0,'2020-05-19 13:24:45',0,0,'247','','',0),(32,1,'2020-09-12','2020-09-12',9.00,1.00,12,'awe','rejected','2020-09-12 14:15:36',0,'2020-09-12 14:22:11',1,0,'5','assd','',625),(33,1,'2020-09-14','2020-09-14',9.00,1.00,5,'hj  h j kjg jkhj gj  jhhuu','pending','2020-09-14 05:26:59',0,'2020-05-19 13:24:45',0,0,'12','','',0),(34,1,'2020-09-30','2020-09-30',9.00,1.00,1012,'casual','pending','2020-09-29 08:35:26',0,'0000-00-00 00:00:00',0,0,'1004','','',0),(35,3,'2020-10-02','2020-10-02',9.00,1.00,1,'kk','pending','2020-10-02 06:25:41',0,'0000-00-00 00:00:00',0,0,'247','','',0),(36,1,'2020-11-07','2020-11-07',9.00,1.00,1,'rwgr','pending','2020-11-07 13:08:17',0,'0000-00-00 00:00:00',0,0,'247','','',0),(37,1,'2020-11-27','2020-11-27',9.00,1.00,1,'dd','pending','2020-11-27 07:59:58',0,'0000-00-00 00:00:00',0,0,'12','','',0),(38,3,'2021-04-11','2021-04-11',9.00,1.00,1035,'going to temple','pending','2021-04-02 09:54:02',0,'0000-00-00 00:00:00',0,0,'621','','',0),(39,1,'2024-06-02','2024-06-02',9.00,1.00,1,'SICK','pending','2024-06-01 09:44:09',0,'0000-00-00 00:00:00',0,0,'12','','',0),(40,4,'2024-06-21','2024-06-21',9.00,1.00,418,'1','approved','2024-06-21 05:13:52',1,'2024-06-21 05:13:52',1,0,'','','',0);
/*!40000 ALTER TABLE `leave_applications` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:16
