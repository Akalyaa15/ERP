-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `languages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(50) NOT NULL,
  `languageId` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'English','en'),(2,'German','de'),(3,'French','fr'),(4,'Dutch','nl'),(5,'Italian','it'),(6,'Spanish','es'),(7,'Polish','pl'),(8,'Russian','ru'),(9,'Japanese','ja'),(10,'Portuguese','pt'),(11,'Swedish','sv'),(12,'Chinese','zh'),(13,'Catalan','ca'),(14,'Ukrainian','uk'),(15,'Norwegian (BokmÃ¥l)','no'),(16,'Finnish','fi'),(17,'Vietnamese','vi'),(18,'Czech','cs'),(19,'Hungarian','hu'),(20,'Korean','ko'),(21,'Indonesian','id'),(22,'Turkish','tr'),(23,'Romanian','ro'),(24,'Persian','fa'),(25,'Arabic','ar'),(26,'Danish','da'),(27,'Esperanto','eo'),(28,'Serbian','sr'),(29,'Lithuanian','lt'),(30,'Slovak','sk'),(31,'Malay','ms'),(32,'Hebrew','he'),(33,'Bulgarian','bg'),(34,'Slovenian','sl'),(35,'VolapÃ¼k','vo'),(36,'Kazakh','kk'),(37,'Waray-Waray','war'),(38,'Basque','eu'),(39,'Croatian','hr'),(40,'Hindi','hi'),(41,'Estonian','et'),(42,'Azerbaijani','az'),(43,'Galician','gl'),(44,'Simple English','simple'),(45,'Norwegian (Nynorsk)','nn'),(46,'Thai','th'),(47,'Newar / Nepal Bhasa','new'),(48,'Greek','el'),(49,'Aromanian','roa-rup'),(50,'Latin','la'),(51,'Occitan','oc'),(52,'Tagalog','tl'),(53,'Haitian','ht'),(54,'Macedonian','mk'),(55,'Georgian','ka'),(56,'Serbo-Croatian','sh'),(57,'Telugu','te'),(58,'Piedmontese','pms'),(59,'Cebuano','ceb'),(60,'Tamil','ta'),(61,'Belarusian (TaraÅ¡kievica)','be-x-old'),(62,'Breton','br'),(63,'Latvian','lv'),(64,'Javanese','jv'),(65,'Albanian','sq'),(66,'Belarusian','be'),(67,'Marathi','mr'),(68,'Welsh','cy'),(69,'Luxembourgish','lb'),(70,'Icelandic','is'),(71,'Bosnian','bs'),(72,'Yoruba','yo'),(73,'Malagasy','mg'),(74,'Aragonese','an'),(75,'Bishnupriya Manipuri','bpy'),(76,'Lombard','lmo'),(77,'West Frisian','fy'),(78,'Bengali','bn'),(79,'Ido','io'),(80,'Swahili','sw'),(81,'Gujarati','gu'),(82,'Malayalam','ml'),(83,'Western Panjabi','pnb'),(84,'Afrikaans','af'),(85,'Low Saxon','nds'),(86,'Sicilian','scn'),(87,'Urdu','ur'),(88,'Kurdish','ku'),(89,'Cantonese','zh-yue'),(90,'Armenian','hy'),(91,'Quechua','qu'),(92,'Sundanese','su'),(93,'Nepali','ne'),(94,'Zazaki','diq'),(95,'Asturian','ast'),(96,'Tatar','tt'),(97,'Neapolitan','nap'),(98,'Irish','ga'),(99,'Chuvash','cv'),(100,'Samogitian','bat-smg'),(101,'Walloon','wa'),(102,'Amharic','am'),(103,'Kannada','kn'),(104,'Alemannic','als'),(105,'Buginese','bug'),(106,'Burmese','my'),(107,'Interlingua','ia'),(108,'Others','xxxx');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:16
