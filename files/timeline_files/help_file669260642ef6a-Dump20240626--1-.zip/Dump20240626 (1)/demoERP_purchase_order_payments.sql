-- MySQL dump 10.13  Distrib 8.0.37, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: demoERP
-- ------------------------------------------------------
-- Server version	8.0.37-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `purchase_order_payments`
--

DROP TABLE IF EXISTS `purchase_order_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_order_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount` double NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method_id` int NOT NULL,
  `note` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `purchase_order_id` int NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `transaction_id` tinytext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `created_by` int DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `work_order_id` int NOT NULL,
  `reference_number` varchar(50) NOT NULL,
  `files` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_payments`
--

LOCK TABLES `purchase_order_payments` WRITE;
/*!40000 ALTER TABLE `purchase_order_payments` DISABLE KEYS */;
INSERT INTO `purchase_order_payments` VALUES (1,1500,'2020-04-28',7,'',1,0,NULL,247,'2020-04-17 16:44:12',0,'',''),(2,15000,'2020-05-09',4,'Advance Payment',6,0,NULL,247,'2020-05-11 12:08:24',0,'',''),(3,18453,'2020-05-11',4,'Full Payment\n',6,0,NULL,247,'2020-05-11 12:09:18',0,'',''),(4,5859,'2020-06-12',1,'',7,0,NULL,621,'2020-05-13 13:49:10',0,'',''),(5,8899,'2020-06-15',1,'nn',8,0,NULL,1,'2020-06-15 14:05:33',0,'66','a:1:{i:0;a:2:{s:9:\"file_name\";s:53:\"purchase_payment_file5ee732957826f-Screenshot--3-.png\";s:9:\"file_size\";s:6:\"152114\";}}'),(6,1500,'2020-08-14',1,'62+knjvu',11,0,NULL,247,'2020-08-15 07:59:16',0,'165461','a:1:{i:0;a:2:{s:9:\"file_name\";s:121:\"purchase_payment_file5f3795d4c9da3-A_Rangasamy_Engineers_Pvt_Ltd-Gemicates_Technologies_Private_Limited-Work_Orders-1.pdf\";s:9:\"file_size\";s:6:\"106196\";}}'),(7,8000,'2020-08-28',4,'Advance Payment',10,0,NULL,247,'2020-08-28 07:09:48',0,'165461','a:1:{i:0;a:2:{s:9:\"file_name\";s:121:\"purchase_payment_file5f48adbc38612-A_Rangasamy_Engineers_Pvt_Ltd-Gemicates_Technologies_Private_Limited-Work_Orders-1.pdf\";s:9:\"file_size\";s:6:\"106196\";}}'),(8,50,'2020-09-12',1,'Advance',12,0,NULL,247,'2020-09-12 07:38:04',0,'FEEFE6521541','a:1:{i:0;a:2:{s:9:\"file_name\";s:110:\"purchase_payment_file5f5c7adc70021-Gemicates_Technologies-Gemicates_Technologies_Private_Limited-Invoice-3.pdf\";s:9:\"file_size\";s:6:\"113275\";}}'),(9,33,'2020-09-30',1,'paid',14,0,NULL,1,'2020-09-30 10:08:18',0,'ee','a:1:{i:0;a:2:{s:9:\"file_name\";s:55:\"purchase_payment_file5f745912914bc-todays-meeting-.docx\";s:9:\"file_size\";s:4:\"9665\";}}'),(10,3859824,'2020-10-01',7,'PAID',15,0,NULL,1,'2020-10-01 08:21:12',0,'REFTESTPAY1','a:1:{i:0;a:2:{s:9:\"file_name\";s:50:\"purchase_payment_file5f75905d07ad1-Meet-25920.docx\";s:9:\"file_size\";s:5:\"11251\";}}'),(11,0,'2020-10-13',1,'ok',17,0,NULL,1,'2020-10-13 15:10:23',0,'yyy','a:1:{i:0;a:2:{s:9:\"file_name\";s:55:\"purchase_payment_file5f85c35f2ecaf-todays-meeting-.docx\";s:9:\"file_size\";s:4:\"9665\";}}'),(12,150,'2020-11-08',8,'dfgdfr',19,0,NULL,247,'2020-11-09 10:34:01',0,'16546154','a:1:{i:0;a:2:{s:9:\"file_name\";s:105:\"purchase_payment_file5fa91b19a282e-Emirates-Gemicates_Technologies_Private_Limited-Purchase_Orders-12.pdf\";s:9:\"file_size\";s:5:\"98341\";}}');
/*!40000 ALTER TABLE `purchase_order_payments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-26 15:51:15
